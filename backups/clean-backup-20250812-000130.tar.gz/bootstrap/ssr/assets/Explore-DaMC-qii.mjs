import { ref, computed, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, useSSRContext, reactive, watch, resolveDynamicComponent, createBlock, createCommentVNode, withModifiers, withDirectives, vModelText, openBlock, Fragment, renderList, vModelSelect } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderComponent, ssrIncludeBooleanAttr, ssrRenderVNode, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { usePage, Link, router, Head } from "@inertiajs/vue3";
import { debounce } from "lodash";
import { _ as _sfc_main$2 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$3 } from "./GuestLayout-CLH3C9b2.mjs";
import { _ as _sfc_main$5 } from "./Breadcrumb-BsPLZkqL.mjs";
import { ClockIcon, UsersIcon, BookOpenIcon, PlayIcon, HeartIcon, AcademicCapIcon, MagnifyingGlassIcon } from "@heroicons/vue/24/outline";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import { _ as _sfc_main$4 } from "./Pagination-BcteoMDy.mjs";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./Footer-DT6KV5L9.mjs";
import "./SwitchDarkMode-qMtWjm8v.mjs";
const _sfc_main$1 = {
  __name: "CourseCard",
  __ssrInlineRender: true,
  props: {
    course: { type: Object, required: true }
  },
  emits: ["enroll"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const page = usePage();
    const enrolling = ref(false);
    computed(() => {
      return page.props.auth && page.props.auth.user;
    });
    const courseImage = computed(() => {
      if (props.course.image) return props.course.image;
      return `https://picsum.photos/seed/${props.course.id}/400/300`;
    });
    const priceText = computed(() => {
      if (props.course.price === 0 || !props.course.price) return content.value.free;
      return `$${props.course.price}`;
    });
    const priceClasses = computed(() => {
      const isFree = props.course.price === 0 || !props.course.price;
      return isFree ? "bg-green-500/90 text-white" : "bg-blue-500/90 text-white";
    });
    const wishlistClasses = computed(() => {
      return props.course.is_wishlisted ? "bg-red-100 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-800/50 text-red-600 dark:text-red-400" : "bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-400";
    });
    const content = computed(() => ({
      free: "FREE",
      students: "students",
      lessons: "lessons",
      enroll: "Enroll Now",
      enrolling: "Enrolling...",
      continue: "Continue Learning",
      details: "View Details"
    }));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-lg transition-all duration-300 group" }, _attrs))} data-v-eeadbf7d><div class="relative overflow-hidden" data-v-eeadbf7d><img${ssrRenderAttr("src", courseImage.value)}${ssrRenderAttr("alt", __props.course.title)} class="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" data-v-eeadbf7d><div class="absolute top-3 right-3" data-v-eeadbf7d><span class="${ssrRenderClass([priceClasses.value, "px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm"])}" data-v-eeadbf7d>${ssrInterpolate(priceText.value)}</span></div>`);
      if (__props.course.category) {
        _push(`<div class="absolute top-3 left-3" data-v-eeadbf7d><span class="bg-black/50 text-white px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm" data-v-eeadbf7d>${ssrInterpolate(__props.course.category.name)}</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="p-6" data-v-eeadbf7d><h3 class="text-lg font-bold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" data-v-eeadbf7d>${ssrInterpolate(__props.course.title)}</h3><p class="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2" data-v-eeadbf7d>${ssrInterpolate(__props.course.description)}</p><div class="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400 mb-4" data-v-eeadbf7d><div class="flex items-center gap-1" data-v-eeadbf7d>`);
      _push(ssrRenderComponent(unref(ClockIcon), { class: "h-4 w-4" }, null, _parent));
      _push(`<span data-v-eeadbf7d>${ssrInterpolate(__props.course.duration || "2h 30m")}</span></div><div class="flex items-center gap-1" data-v-eeadbf7d>`);
      _push(ssrRenderComponent(unref(UsersIcon), { class: "h-4 w-4" }, null, _parent));
      _push(`<span data-v-eeadbf7d>${ssrInterpolate(__props.course.enrollments_count || 0)} ${ssrInterpolate(content.value.students)}</span></div><div class="flex items-center gap-1" data-v-eeadbf7d>`);
      _push(ssrRenderComponent(unref(BookOpenIcon), { class: "h-4 w-4" }, null, _parent));
      _push(`<span data-v-eeadbf7d>${ssrInterpolate(__props.course.lessons_count || 0)} ${ssrInterpolate(content.value.lessons)}</span></div></div><div class="space-y-2" data-v-eeadbf7d>`);
      if (!__props.course.user_enrolled) {
        _push(`<button${ssrIncludeBooleanAttr(enrolling.value) ? " disabled" : ""} class="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-2" data-v-eeadbf7d>`);
        if (enrolling.value) {
          _push(`<span class="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" data-v-eeadbf7d></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(` ${ssrInterpolate(enrolling.value ? content.value.enrolling : content.value.enroll)}</button>`);
      } else {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("courses.learn", { courseId: __props.course.id, courseSlug: __props.course.slug }),
          class: "w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2.5 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(PlayIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(content.value.continue)}`);
            } else {
              return [
                createVNode(unref(PlayIcon), { class: "h-4 w-4" }),
                createTextVNode(" " + toDisplayString(content.value.continue), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      }
      _push(`<div class="flex gap-2" data-v-eeadbf7d>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("courses.details", { id: __props.course.id, courseSlug: __props.course.slug }),
        class: "flex-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-medium py-2 px-4 rounded-lg transition-colors text-center text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(content.value.details)}`);
          } else {
            return [
              createTextVNode(toDisplayString(content.value.details), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button class="${ssrRenderClass([wishlistClasses.value, "px-3 py-2 rounded-lg transition-colors"])}" data-v-eeadbf7d>`);
      _push(ssrRenderComponent(unref(HeartIcon), {
        class: [__props.course.is_wishlisted ? "fill-current" : "", "h-4 w-4"]
      }, null, _parent));
      _push(`</button></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CourseCard = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-eeadbf7d"]]);
const _sfc_main = {
  __name: "Explore",
  __ssrInlineRender: true,
  props: {
    courses: { type: Object, required: true },
    categories: { type: Array, default: () => [] },
    filters: { type: Object, default: () => ({}) },
    stats: { type: Object, default: () => ({}) }
  },
  setup(__props) {
    const props = __props;
    const page = usePage();
    const isAuthenticated = computed(() => {
      return page.props.auth && page.props.auth.user;
    });
    const filters = reactive({
      search: props.filters.search || "",
      category: props.filters.category || "",
      price: props.filters.price || "",
      sort: props.filters.sort || "latest"
    });
    const pageTitle = computed(() => content.value.pageTitle);
    const breadcrumbs = computed(() => [
      { name: content.value.breadcrumbs.home, href: route("dashboard") },
      { name: content.value.breadcrumbs.courses }
    ]);
    const content = computed(() => ({
      pageTitle: "Explore Courses",
      hero: {
        title: "Discover Amazing Courses",
        subtitle: "Expand your knowledge with our comprehensive course library"
      },
      stats: {
        courses: "Courses",
        students: "Students",
        instructors: "Instructors"
      },
      search: {
        placeholder: "Search courses...",
        button: "Search"
      },
      filters: {
        allCategories: "All Categories",
        allPrices: "All Prices",
        free: "Free",
        paid: "Paid"
      },
      results: {
        title: "Available Courses",
        showing: "Showing",
        of: "of",
        courses: "courses"
      },
      sort: {
        latest: "Latest",
        popular: "Most Popular",
        title: "Title A-Z",
        priceLow: "Price: Low to High",
        priceHigh: "Price: High to Low"
      },
      empty: {
        title: "No courses found",
        message: "Try adjusting your search criteria or browse all courses"
      },
      breadcrumbs: {
        home: "Dashboard",
        courses: "Explore Courses"
      }
    }));
    const performSearch = debounce(() => {
      router.get(route("courses.explore"), filters, {
        preserveState: true,
        preserveScroll: true
      });
    }, 300);
    const enrollCourse = (courseId) => {
      router.post(route("courses.enroll", courseId), {}, {
        preserveScroll: true,
        onSuccess: () => {
        }
      });
    };
    watch(() => [filters.category, filters.price, filters.sort], () => {
      performSearch();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: pageTitle.value }, null, _parent));
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(isAuthenticated.value ? _sfc_main$2 : _sfc_main$3), null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$5, {
              title: pageTitle.value,
              breadcrumbs: breadcrumbs.value
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$5, {
                title: pageTitle.value,
                breadcrumbs: breadcrumbs.value
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-8"${_scopeId}><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"${_scopeId}><div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 mb-8 text-white"${_scopeId}><div class="max-w-3xl"${_scopeId}><h1 class="text-4xl font-bold mb-4"${_scopeId}>${ssrInterpolate(content.value.hero.title)}</h1><p class="text-xl opacity-90 mb-6"${_scopeId}>${ssrInterpolate(content.value.hero.subtitle)}</p><div class="flex items-center gap-6 text-sm"${_scopeId}><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(BookOpenIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(`<span${_scopeId}>${ssrInterpolate(__props.stats.totalCourses)}+ ${ssrInterpolate(content.value.stats.courses)}</span></div><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(UsersIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(`<span${_scopeId}>${ssrInterpolate(__props.stats.totalStudents)}+ ${ssrInterpolate(content.value.stats.students)}</span></div><div class="flex items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(AcademicCapIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(`<span${_scopeId}>${ssrInterpolate(__props.stats.totalInstructors)}+ ${ssrInterpolate(content.value.stats.instructors)}</span></div></div></div></div><div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-8"${_scopeId}><form class="space-y-4"${_scopeId}><div class="flex flex-col md:flex-row gap-4"${_scopeId}><div class="flex-1"${_scopeId}><div class="relative"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(MagnifyingGlassIcon), { class: "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(`<input${ssrRenderAttr("value", filters.search)} type="text"${ssrRenderAttr("placeholder", content.value.search.placeholder)} class="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white transition-colors"${_scopeId}></div></div><select class="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white min-w-[200px]"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(filters.category) ? ssrLooseContain(filters.category, "") : ssrLooseEqual(filters.category, "")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.filters.allCategories)}</option><!--[-->`);
            ssrRenderList(__props.categories, (category) => {
              _push2(`<option${ssrRenderAttr("value", category.id)}${ssrIncludeBooleanAttr(Array.isArray(filters.category) ? ssrLooseContain(filters.category, category.id) : ssrLooseEqual(filters.category, category.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
            });
            _push2(`<!--]--></select><select class="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white min-w-[150px]"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(filters.price) ? ssrLooseContain(filters.price, "") : ssrLooseEqual(filters.price, "")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.filters.allPrices)}</option><option value="free"${ssrIncludeBooleanAttr(Array.isArray(filters.price) ? ssrLooseContain(filters.price, "free") : ssrLooseEqual(filters.price, "free")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.filters.free)}</option><option value="paid"${ssrIncludeBooleanAttr(Array.isArray(filters.price) ? ssrLooseContain(filters.price, "paid") : ssrLooseEqual(filters.price, "paid")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.filters.paid)}</option></select><button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors flex items-center gap-2 font-medium"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(MagnifyingGlassIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(` ${ssrInterpolate(content.value.search.button)}</button></div></form></div><div class="flex items-center justify-between mb-6"${_scopeId}><div${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(content.value.results.title)}</h2><p class="text-gray-600 dark:text-gray-400 mt-1"${_scopeId}>${ssrInterpolate(content.value.results.showing)} ${ssrInterpolate(__props.courses.data.length)} ${ssrInterpolate(content.value.results.of)} ${ssrInterpolate(__props.courses.total)} ${ssrInterpolate(content.value.results.courses)}</p></div><select class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"${_scopeId}><option value="latest"${ssrIncludeBooleanAttr(Array.isArray(filters.sort) ? ssrLooseContain(filters.sort, "latest") : ssrLooseEqual(filters.sort, "latest")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.sort.latest)}</option><option value="popular"${ssrIncludeBooleanAttr(Array.isArray(filters.sort) ? ssrLooseContain(filters.sort, "popular") : ssrLooseEqual(filters.sort, "popular")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.sort.popular)}</option><option value="title"${ssrIncludeBooleanAttr(Array.isArray(filters.sort) ? ssrLooseContain(filters.sort, "title") : ssrLooseEqual(filters.sort, "title")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.sort.title)}</option><option value="price_low"${ssrIncludeBooleanAttr(Array.isArray(filters.sort) ? ssrLooseContain(filters.sort, "price_low") : ssrLooseEqual(filters.sort, "price_low")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.sort.priceLow)}</option><option value="price_high"${ssrIncludeBooleanAttr(Array.isArray(filters.sort) ? ssrLooseContain(filters.sort, "price_high") : ssrLooseEqual(filters.sort, "price_high")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(content.value.sort.priceHigh)}</option></select></div>`);
            if (__props.courses.data.length === 0) {
              _push2(`<div class="text-center py-16"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(BookOpenIcon), { class: "h-16 w-16 mx-auto text-gray-400 mb-4" }, null, _parent2, _scopeId));
              _push2(`<h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2"${_scopeId}>${ssrInterpolate(content.value.empty.title)}</h3><p class="text-gray-600 dark:text-gray-400"${_scopeId}>${ssrInterpolate(content.value.empty.message)}</p></div>`);
            } else {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8"${_scopeId}><!--[-->`);
              ssrRenderList(__props.courses.data, (course) => {
                _push2(ssrRenderComponent(CourseCard, {
                  key: course.id,
                  course,
                  onEnroll: enrollCourse
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            }
            if (__props.courses.last_page > 1) {
              _push2(`<div class="flex justify-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$4, {
                links: __props.courses,
                filters
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-8" }, [
                createVNode("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 mb-8 text-white" }, [
                    createVNode("div", { class: "max-w-3xl" }, [
                      createVNode("h1", { class: "text-4xl font-bold mb-4" }, toDisplayString(content.value.hero.title), 1),
                      createVNode("p", { class: "text-xl opacity-90 mb-6" }, toDisplayString(content.value.hero.subtitle), 1),
                      createVNode("div", { class: "flex items-center gap-6 text-sm" }, [
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          createVNode(unref(BookOpenIcon), { class: "h-5 w-5" }),
                          createVNode("span", null, toDisplayString(__props.stats.totalCourses) + "+ " + toDisplayString(content.value.stats.courses), 1)
                        ]),
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          createVNode(unref(UsersIcon), { class: "h-5 w-5" }),
                          createVNode("span", null, toDisplayString(__props.stats.totalStudents) + "+ " + toDisplayString(content.value.stats.students), 1)
                        ]),
                        createVNode("div", { class: "flex items-center gap-2" }, [
                          createVNode(unref(AcademicCapIcon), { class: "h-5 w-5" }),
                          createVNode("span", null, toDisplayString(__props.stats.totalInstructors) + "+ " + toDisplayString(content.value.stats.instructors), 1)
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-8" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(unref(performSearch), ["prevent"]),
                      class: "space-y-4"
                    }, [
                      createVNode("div", { class: "flex flex-col md:flex-row gap-4" }, [
                        createVNode("div", { class: "flex-1" }, [
                          createVNode("div", { class: "relative" }, [
                            createVNode(unref(MagnifyingGlassIcon), { class: "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" }),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => filters.search = $event,
                              type: "text",
                              placeholder: content.value.search.placeholder,
                              class: "w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white transition-colors"
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, filters.search]
                            ])
                          ])
                        ]),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => filters.category = $event,
                          class: "px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white min-w-[200px]"
                        }, [
                          createVNode("option", { value: "" }, toDisplayString(content.value.filters.allCategories), 1),
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                            return openBlock(), createBlock("option", {
                              key: category.id,
                              value: category.id
                            }, toDisplayString(category.name), 9, ["value"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, filters.category]
                        ]),
                        withDirectives(createVNode("select", {
                          "onUpdate:modelValue": ($event) => filters.price = $event,
                          class: "px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white min-w-[150px]"
                        }, [
                          createVNode("option", { value: "" }, toDisplayString(content.value.filters.allPrices), 1),
                          createVNode("option", { value: "free" }, toDisplayString(content.value.filters.free), 1),
                          createVNode("option", { value: "paid" }, toDisplayString(content.value.filters.paid), 1)
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, filters.price]
                        ]),
                        createVNode("button", {
                          type: "submit",
                          class: "bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors flex items-center gap-2 font-medium"
                        }, [
                          createVNode(unref(MagnifyingGlassIcon), { class: "h-5 w-5" }),
                          createTextVNode(" " + toDisplayString(content.value.search.button), 1)
                        ])
                      ])
                    ], 40, ["onSubmit"])
                  ]),
                  createVNode("div", { class: "flex items-center justify-between mb-6" }, [
                    createVNode("div", null, [
                      createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, toDisplayString(content.value.results.title), 1),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-400 mt-1" }, toDisplayString(content.value.results.showing) + " " + toDisplayString(__props.courses.data.length) + " " + toDisplayString(content.value.results.of) + " " + toDisplayString(__props.courses.total) + " " + toDisplayString(content.value.results.courses), 1)
                    ]),
                    withDirectives(createVNode("select", {
                      "onUpdate:modelValue": ($event) => filters.sort = $event,
                      onChange: unref(performSearch),
                      class: "px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    }, [
                      createVNode("option", { value: "latest" }, toDisplayString(content.value.sort.latest), 1),
                      createVNode("option", { value: "popular" }, toDisplayString(content.value.sort.popular), 1),
                      createVNode("option", { value: "title" }, toDisplayString(content.value.sort.title), 1),
                      createVNode("option", { value: "price_low" }, toDisplayString(content.value.sort.priceLow), 1),
                      createVNode("option", { value: "price_high" }, toDisplayString(content.value.sort.priceHigh), 1)
                    ], 40, ["onUpdate:modelValue", "onChange"]), [
                      [vModelSelect, filters.sort]
                    ])
                  ]),
                  __props.courses.data.length === 0 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-center py-16"
                  }, [
                    createVNode(unref(BookOpenIcon), { class: "h-16 w-16 mx-auto text-gray-400 mb-4" }),
                    createVNode("h3", { class: "text-xl font-semibold text-gray-900 dark:text-white mb-2" }, toDisplayString(content.value.empty.title), 1),
                    createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, toDisplayString(content.value.empty.message), 1)
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8"
                  }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.courses.data, (course) => {
                      return openBlock(), createBlock(CourseCard, {
                        key: course.id,
                        course,
                        onEnroll: enrollCourse
                      }, null, 8, ["course"]);
                    }), 128))
                  ])),
                  __props.courses.last_page > 1 ? (openBlock(), createBlock("div", {
                    key: 2,
                    class: "flex justify-center"
                  }, [
                    createVNode(_sfc_main$4, {
                      links: __props.courses,
                      filters
                    }, null, 8, ["links", "filters"])
                  ])) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }), _parent);
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Courses/Explore.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
