import { ref, unref, withCtx, createTextVNode, createVNode, withModifiers, createBlock, openBlock, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$5 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$3 } from "./PrimaryButton-Be3Csrwm.mjs";
import "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$4 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$2 } from "./InputError-C7WpniWA.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
const _sfc_main = {
  __name: "QuizImport",
  __ssrInlineRender: true,
  props: {
    quizId: {
      type: Number,
      required: true
    },
    quiz: {
      type: Object,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      file: null,
      questions: []
    });
    const jsonInput = ref("");
    const jsonError = ref("");
    const fileInput = ref(null);
    function importQuestions() {
      form.post(route("quizzes.import-questions", props.quizId), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {
          if (fileInput.value) {
            fileInput.value.value = "";
          }
          form.reset("file");
        }
      });
    }
    function importQuestionsFromJson() {
      try {
        const questions = JSON.parse(jsonInput.value);
        if (!Array.isArray(questions)) {
          throw new Error("JSON must be an array of questions");
        }
        form.questions = questions;
        form.post(route("quizzes.import-questions-json", props.quizId), {
          preserveState: true,
          preserveScroll: true,
          onSuccess: () => {
            jsonInput.value = "";
            jsonError.value = "";
          },
          onError: (errors) => {
            jsonError.value = errors.questions || "An error occurred while importing questions";
          }
        });
      } catch (error) {
        jsonError.value = "Invalid JSON format: " + error.message;
      }
    }
    function handleFileChange(event) {
      form.file = event.target.files[0];
    }
    function showJsonExample() {
      const example = [
        {
          question_title: "What is the capital of France?",
          question_type_id: 1,
          correct_answers_required: 1,
          answers: [
            { answer: "Paris", is_correct: true },
            { answer: "London", is_correct: false },
            { answer: "Berlin", is_correct: false },
            { answer: "Madrid", is_correct: false }
          ]
        }
      ];
      alert(JSON.stringify(example, null, 2));
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Import Questions - ${__props.quiz.title}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$5, {
              title: `Import Questions - ${__props.quiz.title}`,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$5, {
                title: `Import Questions - ${__props.quiz.title}`,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="mb-8"${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}> Import Questions from Excel </h3><form enctype="multipart/form-data"${_scopeId}><div class="flex flex-col sm:flex-row items-center gap-4"${_scopeId}><div class="w-full sm:w-2/3"${_scopeId}><label for="file-upload" class="flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 cursor-pointer transition-colors"${_scopeId}>`);
            if (!unref(form).file) {
              _push2(`<span${_scopeId}>Choose Excel file</span>`);
            } else {
              _push2(`<span${_scopeId}>${ssrInterpolate(unref(form).file.name)}</span>`);
            }
            _push2(`<input id="file-upload" type="file" accept=".xlsx,.xls" class="sr-only"${_scopeId}></label>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              message: unref(form).errors.file,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "submit",
              class: "w-full sm:w-1/3",
              disabled: !unref(form).file
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Import Questions `);
                } else {
                  return [
                    createTextVNode(" Import Questions ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form><p class="text-sm text-gray-600 dark:text-gray-400 mt-4"${_scopeId}> Please upload an Excel file (.xlsx or .xls) containing your questions. <a${ssrRenderAttr("href", _ctx.route("quizzes.template.download"))} class="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300"${_scopeId}> Download template </a></p></div><div${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}> Import Questions from JSON </h3><form${_scopeId}><div class="mb-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              modelValue: jsonInput.value,
              "onUpdate:modelValue": ($event) => jsonInput.value = $event,
              type: "textarea",
              class: "w-full h-40",
              placeholder: "Paste your JSON here..."
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              message: jsonError.value,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              type: "submit",
              class: "bg-purple-600 hover:bg-purple-700",
              disabled: !jsonInput.value
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Import Questions from JSON `);
                } else {
                  return [
                    createTextVNode(" Import Questions from JSON ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<button type="button" class="text-sm text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300"${_scopeId}> See example format </button></div></form></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-4" }, " Import Questions from Excel "),
                        createVNode("form", {
                          onSubmit: withModifiers(importQuestions, ["prevent"]),
                          enctype: "multipart/form-data"
                        }, [
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center gap-4" }, [
                            createVNode("div", { class: "w-full sm:w-2/3" }, [
                              createVNode("label", {
                                for: "file-upload",
                                class: "flex items-center justify-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 cursor-pointer transition-colors"
                              }, [
                                !unref(form).file ? (openBlock(), createBlock("span", { key: 0 }, "Choose Excel file")) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(unref(form).file.name), 1)),
                                createVNode("input", {
                                  id: "file-upload",
                                  type: "file",
                                  ref_key: "fileInput",
                                  ref: fileInput,
                                  accept: ".xlsx,.xls",
                                  class: "sr-only",
                                  onChange: handleFileChange
                                }, null, 544)
                              ]),
                              createVNode(_sfc_main$2, {
                                message: unref(form).errors.file,
                                class: "mt-2"
                              }, null, 8, ["message"])
                            ]),
                            createVNode(_sfc_main$3, {
                              type: "submit",
                              class: "w-full sm:w-1/3",
                              disabled: !unref(form).file
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Import Questions ")
                              ]),
                              _: 1
                            }, 8, ["disabled"])
                          ])
                        ], 32),
                        createVNode("p", { class: "text-sm text-gray-600 dark:text-gray-400 mt-4" }, [
                          createTextVNode(" Please upload an Excel file (.xlsx or .xls) containing your questions. "),
                          createVNode("a", {
                            href: _ctx.route("quizzes.template.download"),
                            class: "text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300"
                          }, " Download template ", 8, ["href"])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-4" }, " Import Questions from JSON "),
                        createVNode("form", {
                          onSubmit: withModifiers(importQuestionsFromJson, ["prevent"])
                        }, [
                          createVNode("div", { class: "mb-4" }, [
                            createVNode(_sfc_main$4, {
                              modelValue: jsonInput.value,
                              "onUpdate:modelValue": ($event) => jsonInput.value = $event,
                              type: "textarea",
                              class: "w-full h-40",
                              placeholder: "Paste your JSON here..."
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$2, {
                              message: jsonError.value,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", { class: "flex justify-between items-center" }, [
                            createVNode(_sfc_main$3, {
                              type: "submit",
                              class: "bg-purple-600 hover:bg-purple-700",
                              disabled: !jsonInput.value
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Import Questions from JSON ")
                              ]),
                              _: 1
                            }, 8, ["disabled"]),
                            createVNode("button", {
                              type: "button",
                              onClick: showJsonExample,
                              class: "text-sm text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300"
                            }, " See example format ")
                          ])
                        ], 32)
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/QuizImport.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
