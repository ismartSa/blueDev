import { mergeProps, unref, useSSRContext, computed, ref, createVNode, resolveDynamicComponent, shallowRef, reactive, onMounted, nextTick, onUnmounted, withCtx, Transition, createBlock, createCommentVNode, openBlock, toDisplayString, withMemo, Fragment, renderList, withModifiers, isMemoSame, withDirectives, createTextVNode, vShow } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderComponent, ssrRenderVNode, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderStyle } from "vue/server-renderer";
import { usePage, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$a } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { DocumentIcon, XMarkIcon, CloudArrowUpIcon, PencilIcon, ArrowPathIcon, CheckIcon, CircleStackIcon, PlusIcon, CheckCircleIcon, ChevronRightIcon, CogIcon, EyeIcon, ShareIcon, PhoneIcon, BuildingOfficeIcon } from "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
const COMMON_CLASSES = {
  input: "block w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition-colors duration-200 text-sm",
  container: "relative",
  label: "text-sm font-medium text-gray-700 dark:text-gray-300",
  description: "text-xs text-gray-500 dark:text-gray-400"
};
const formatLabel = (key) => {
  const customLabels = {
    maintenance_mode: "Maintenance Mode",
    user_registration: "Allow User Registration",
    email_verification: "Email Verification Required",
    two_factor_auth: "Two-Factor Authentication",
    app_name: "Application Name",
    app_tagline: "Application Tagline",
    app_description: "Application Description",
    primary_color: "Primary Color",
    secondary_color: "Secondary Color",
    contact_email: "Contact Email",
    contact_phone: "Contact Phone",
    contact_address: "Contact Address",
    session_lifetime: "Session Lifetime",
    max_file_size: "Maximum File Size",
    pagination_limit: "Pagination Limit",
    cache_ttl: "Cache TTL"
  };
  return customLabels[key] || key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
};
const PLACEHOLDERS = {
  app_name: "Enter your application name",
  app_tagline: "A brief description of your app",
  app_description: "Detailed description of your application",
  primary_color: "#3B82F6",
  secondary_color: "#10B981",
  contact_email: "contact@example.com",
  contact_phone: "+1 (555) 123-4567",
  contact_address: "123 Main St, City, State 12345",
  session_lifetime: "120",
  max_file_size: "10",
  pagination_limit: "20",
  cache_ttl: "3600"
};
const INTEGER_CONFIG = {
  mins: {
    session_lifetime: 1,
    max_file_size: 1,
    pagination_limit: 5,
    cache_ttl: 60
  },
  maxs: {
    session_lifetime: 43200,
    // 30 days in minutes
    max_file_size: 100,
    // 100MB
    pagination_limit: 100,
    cache_ttl: 86400
    // 24 hours in seconds
  },
  steps: {
    session_lifetime: 15,
    max_file_size: 1,
    pagination_limit: 5,
    cache_ttl: 60
  },
  units: {
    session_lifetime: "min",
    max_file_size: "MB",
    pagination_limit: "items",
    cache_ttl: "sec"
  }
};
const FILE_CONFIG = {
  acceptedTypes: {
    logo: "image/*,.svg",
    favicon: "image/*,.ico",
    banner: "image/*",
    avatar: "image/*"
  },
  descriptions: {
    logo: "PNG, JPG, SVG up to 10MB",
    favicon: "ICO, PNG up to 10MB",
    banner: "PNG, JPG up to 10MB",
    avatar: "PNG, JPG up to 10MB"
  }
};
const isImage = (url) => {
  return url && /\.(jpg|jpeg|png|gif|svg|webp)$/i.test(url);
};
const getPlaceholder = (key) => {
  return PLACEHOLDERS[key] || `Enter ${key.replace(/_/g, " ")}`;
};
const getIntegerConfig = (key, type) => {
  var _a;
  return ((_a = INTEGER_CONFIG[type]) == null ? void 0 : _a[key]) || (type === "mins" ? 0 : type === "maxs" ? 999999 : 1);
};
const getFileConfig = (key, type) => {
  var _a;
  return ((_a = FILE_CONFIG[type]) == null ? void 0 : _a[key]) || (type === "acceptedTypes" ? "image/*,.ico" : "Images up to 10MB");
};
const _sfc_main$9 = {
  __name: "StringInput",
  __ssrInlineRender: true,
  props: {
    setting: Object,
    modelValue: [String, Number]
  },
  emits: ["update:modelValue"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<input${ssrRenderAttrs(mergeProps({
        id: __props.setting.key,
        value: __props.modelValue,
        type: "text",
        placeholder: unref(getPlaceholder)(__props.setting.key),
        class: unref(COMMON_CLASSES).input
      }, _attrs))}>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/StringInput.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const toggleBaseClasses = "relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2";
const switchBaseClasses = "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out";
const _sfc_main$8 = {
  __name: "BooleanInput",
  __ssrInlineRender: true,
  props: {
    setting: Object,
    modelValue: Boolean
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const toggleClasses = computed(
      () => props.modelValue ? "bg-indigo-600" : "bg-gray-200 dark:bg-gray-600"
    );
    const switchClasses = computed(
      () => props.modelValue ? "translate-x-5" : "translate-x-0"
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg" }, _attrs))}><label${ssrRenderAttr("for", __props.setting.key)} class="${ssrRenderClass(unref(COMMON_CLASSES).label)}">${ssrInterpolate(unref(formatLabel)(__props.setting.key))}</label><button type="button"${ssrRenderAttr("id", __props.setting.key)} class="${ssrRenderClass([toggleBaseClasses, toggleClasses.value])}" role="switch"${ssrRenderAttr("aria-checked", __props.modelValue)}><span class="${ssrRenderClass([switchBaseClasses, switchClasses.value])}"></span></button></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/BooleanInput.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "IntegerInput",
  __ssrInlineRender: true,
  props: {
    setting: Object,
    modelValue: [Number, String]
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: unref(COMMON_CLASSES).container
      }, _attrs))}><input${ssrRenderAttr("id", __props.setting.key)}${ssrRenderAttr("value", __props.modelValue)} type="number"${ssrRenderAttr("min", unref(getIntegerConfig)(__props.setting.key, "mins"))}${ssrRenderAttr("max", unref(getIntegerConfig)(__props.setting.key, "maxs"))}${ssrRenderAttr("step", unref(getIntegerConfig)(__props.setting.key, "steps"))}${ssrRenderAttr("placeholder", unref(getPlaceholder)(__props.setting.key))} class="${ssrRenderClass(`${unref(COMMON_CLASSES).input} pr-12`)}"><div class="absolute inset-y-0 right-0 flex items-center pr-3"><span class="text-xs text-gray-500 dark:text-gray-400">${ssrInterpolate(unref(getIntegerConfig)(__props.setting.key, "units"))}</span></div></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/IntegerInput.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const dropzoneBaseClasses = "relative border-2 border-dashed rounded-lg p-6 text-center hover:border-indigo-400 transition-colors duration-200 cursor-pointer";
const _sfc_main$6 = {
  __name: "FileInput",
  __ssrInlineRender: true,
  props: {
    setting: Object,
    modelValue: [String, File]
  },
  emits: ["update:modelValue", "file-upload"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isDragging = ref(false);
    const dropzoneClasses = computed(
      () => isDragging.value ? "border-indigo-400 bg-indigo-50 dark:bg-indigo-900/20" : "border-gray-300 dark:border-gray-600"
    );
    const getFileName = () => {
      var _a;
      if (typeof props.modelValue === "string") {
        return props.modelValue.split("/").pop() || "Current file";
      }
      return ((_a = props.modelValue) == null ? void 0 : _a.name) || "Current file";
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-3" }, _attrs))}>`);
      if (__props.modelValue) {
        _push(`<div class="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"><div class="flex-shrink-0">`);
        if (unref(isImage)(__props.modelValue)) {
          _push(`<img${ssrRenderAttr("src", __props.modelValue)}${ssrRenderAttr("alt", __props.setting.key)} class="w-12 h-12 object-cover rounded-lg border border-gray-200 dark:border-gray-600">`);
        } else {
          _push(`<div class="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-lg flex items-center justify-center">`);
          _push(ssrRenderComponent(unref(DocumentIcon), { class: "w-6 h-6 text-gray-400" }, null, _parent));
          _push(`</div>`);
        }
        _push(`</div><div class="flex-1 min-w-0"><p class="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">${ssrInterpolate(getFileName())}</p><p class="${ssrRenderClass(unref(COMMON_CLASSES).description)}"> Current ${ssrInterpolate(unref(formatLabel)(__props.setting.key))}</p></div><button type="button" class="flex-shrink-0 p-1 text-red-400 hover:text-red-600 transition-colors duration-200">`);
        _push(ssrRenderComponent(unref(XMarkIcon), { class: "w-4 h-4" }, null, _parent));
        _push(`</button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([dropzoneBaseClasses, dropzoneClasses.value])}"><input${ssrRenderAttr("id", __props.setting.key)} type="file"${ssrRenderAttr("accept", unref(getFileConfig)(__props.setting.key, "acceptedTypes"))} class="sr-only"><div class="space-y-2"><div class="mx-auto w-12 h-12 text-gray-400">`);
      _push(ssrRenderComponent(unref(CloudArrowUpIcon), { class: "w-full h-full" }, null, _parent));
      _push(`</div><div class="text-sm"><span class="font-medium text-indigo-600 dark:text-indigo-400"> Click to upload </span><span class="text-gray-500 dark:text-gray-400"> or drag and drop </span></div><p class="${ssrRenderClass(unref(COMMON_CLASSES).description)}">${ssrInterpolate(unref(getFileConfig)(__props.setting.key, "descriptions"))}</p></div></div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/FileInput.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const baseClasses = "inline-flex items-center px-3 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed";
const _sfc_main$5 = {
  __name: "ActionButton",
  __ssrInlineRender: true,
  props: {
    variant: {
      type: String,
      default: "primary",
      validator: (value) => ["primary", "secondary", "danger"].includes(value)
    },
    icon: {
      type: [Object, Function],
      required: true
    },
    text: {
      type: String,
      required: true
    },
    loading: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const variantClasses = {
      primary: "border border-transparent text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500",
      secondary: "border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:ring-indigo-500",
      danger: "border border-transparent text-white bg-red-600 hover:bg-red-700 focus:ring-red-500"
    };
    const buttonClasses = computed(() => {
      return `${baseClasses} ${variantClasses[props.variant]}`;
    });
    const iconClasses = computed(() => {
      return `w-4 h-4 mr-2 ${props.loading ? "animate-spin" : ""}`;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        disabled: __props.disabled || __props.loading,
        class: buttonClasses.value
      }, _ctx.$attrs, _attrs))}>`);
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(__props.icon), { class: iconClasses.value }, null), _parent);
      _push(` ${ssrInterpolate(__props.text)}</button>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/ActionButton.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const StatusIndicator = {
  props: ["active"],
  template: `
        <div :class="[
            'w-3 h-3 rounded-full transition-colors duration-200',
            active ? 'bg-green-500 shadow-green-500/50 shadow-sm' : 'bg-red-500 shadow-red-500/50 shadow-sm'
        ]"></div>
    `
};
const ConnectionInfo = {
  props: ["name", "driver"],
  template: `
        <div>
            <h4 class="font-medium text-gray-900 dark:text-white">{{ name }}</h4>
            <p class="text-sm text-gray-500 dark:text-gray-400">{{ driver.toUpperCase() }}</p>
        </div>
    `
};
const StatusBadge = {
  props: ["active", "responseTime"],
  template: `
        <div class="text-right">
            <span :class="[
                'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium transition-colors duration-200',
                active 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
            ]">
                {{ active ? 'Connected' : 'Disconnected' }}
            </span>
            <div v-if="responseTime" class="text-xs text-gray-500 mt-1 font-mono">
                {{ responseTime }}ms
            </div>
        </div>
    `
};
const EditButton = {
  components: { PencilIcon },
  template: `
        <button 
            @click="$emit('click')"
            class="p-2 text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-md transition-all duration-200"
            title="Edit Connection"
        >
            <PencilIcon class="w-4 h-4" />
        </button>
    `,
  emits: ["click"]
};
const ConnectionDetails = {
  props: ["host", "database"],
  template: `
        <div class="mt-3 grid grid-cols-2 gap-4 text-sm">
            <DetailItem label="Host" :value="host" />
            <DetailItem label="Database" :value="database" />
        </div>
    `,
  components: {
    DetailItem: {
      props: ["label", "value"],
      template: `
                <div>
                    <span class="text-gray-500 dark:text-gray-400">{{ label }}:</span>
                    <span class="ml-1 text-gray-900 dark:text-white font-mono text-xs">{{ value }}</span>
                </div>
            `
    }
  }
};
const ErrorMessage = {
  props: ["message"],
  template: `
        <div class="mt-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
            <p class="text-sm text-red-700 dark:text-red-300">{{ message }}</p>
        </div>
    `
};
const __default__ = {
  components: {
    StatusIndicator,
    ConnectionInfo,
    StatusBadge,
    EditButton,
    ConnectionDetails,
    ErrorMessage
  }
};
const _sfc_main$4 = /* @__PURE__ */ Object.assign(__default__, {
  __name: "ConnectionCard",
  __ssrInlineRender: true,
  props: {
    connection: {
      type: Object,
      required: true
    }
  },
  emits: ["edit"],
  setup(__props) {
    const cardClasses = computed(() => {
      return "bg-white dark:bg-gray-700 p-4 rounded-lg border border-gray-200 dark:border-gray-600 shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5";
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: cardClasses.value }, _attrs))}><div class="flex items-center justify-between"><div class="flex items-center space-x-3">`);
      _push(ssrRenderComponent(StatusIndicator, {
        active: __props.connection.active
      }, null, _parent));
      _push(ssrRenderComponent(ConnectionInfo, {
        name: __props.connection.name,
        driver: __props.connection.driver
      }, null, _parent));
      _push(`</div><div class="flex items-center space-x-3">`);
      _push(ssrRenderComponent(StatusBadge, {
        active: __props.connection.active,
        "response-time": __props.connection.response_time
      }, null, _parent));
      _push(ssrRenderComponent(EditButton, {
        onClick: ($event) => _ctx.$emit("edit", __props.connection)
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(ConnectionDetails, {
        host: __props.connection.host,
        database: __props.connection.database
      }, null, _parent));
      if (!__props.connection.active && __props.connection.message) {
        _push(ssrRenderComponent(ErrorMessage, {
          message: __props.connection.message
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/ConnectionCard.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "ConnectionModal",
  __ssrInlineRender: true,
  props: {
    editing: {
      type: Object,
      default: null
    },
    form: {
      type: Object,
      required: true
    },
    drivers: {
      type: Array,
      required: true
    },
    isSubmitting: {
      type: Boolean,
      default: false
    }
  },
  emits: ["close", "save", "update:form"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center p-4" }, _attrs))}><div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6"><div class="flex items-center justify-between mb-6"><h3 class="text-lg font-medium text-gray-900 dark:text-white">${ssrInterpolate(__props.editing ? "Edit Connection" : "Add New Connection")}</h3><button class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 p-1 rounded-md transition-colors duration-200">`);
      _push(ssrRenderComponent(unref(XMarkIcon), { class: "w-5 h-5" }, null, _parent));
      _push(`</button></div><form class="space-y-4"><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Name</label><input type="text"${ssrRenderAttr("value", __props.form.name)} placeholder="Connection name" required class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Driver</label><select${ssrRenderAttr("value", __props.form.driver)} required class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"><option value="">Select driver</option><!--[-->`);
      ssrRenderList(__props.drivers, (driver) => {
        _push(`<option${ssrRenderAttr("value", driver)}>${ssrInterpolate(driver.toUpperCase())}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Host</label><input type="text"${ssrRenderAttr("value", __props.form.host)} placeholder="localhost" required class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Port</label><input type="number"${ssrRenderAttr("value", __props.form.port)} placeholder="3306" class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div></div><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Database</label><input type="text"${ssrRenderAttr("value", __props.form.database)} placeholder="Database name" required class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div><div class="grid grid-cols-2 gap-4"><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Username</label><input type="text"${ssrRenderAttr("value", __props.form.username)} placeholder="Username" class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label><input type="password"${ssrRenderAttr("value", __props.form.password)} placeholder="Password" class="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white sm:text-sm transition-colors duration-200"></div></div><div class="flex items-center"><input type="checkbox"${ssrIncludeBooleanAttr(__props.form.active) ? " checked" : ""} class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 dark:border-gray-600 rounded transition-colors duration-200"><label class="ml-2 text-sm text-gray-700 dark:text-gray-300"> Set as active connection </label></div><div class="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-600"><button type="button" class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(__props.isSubmitting) ? " disabled" : ""} class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 transition-colors duration-200">`);
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(__props.isSubmitting ? unref(ArrowPathIcon) : unref(CheckIcon)), {
        class: ["w-4 h-4 mr-2", { "animate-spin": __props.isSubmitting }]
      }, null), _parent);
      _push(` ${ssrInterpolate(__props.isSubmitting ? "Saving..." : "Save Connection")}</button></div></form></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/ConnectionModal.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "EmptyState",
  __ssrInlineRender: true,
  props: {
    isAdmin: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-center py-12" }, _attrs))}><div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-700 mb-4">`);
      _push(ssrRenderComponent(unref(CircleStackIcon), { class: "h-8 w-8 text-gray-400" }, null, _parent));
      _push(`</div><h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">${ssrInterpolate(__props.isAdmin ? "No database connections available" : "Database Status")}</h3><p class="text-sm text-gray-500 dark:text-gray-400 max-w-sm mx-auto">`);
      if (__props.isAdmin) {
        _push(`<!--[--> Database connections are loaded from your Laravel configuration. <br>Add connections using the &quot;Add Connection&quot; button above. <!--]-->`);
      } else {
        _push(`<!--[--> Please <a href="/login" class="text-blue-600 dark:text-blue-400 hover:underline">log in</a> as an administrator to view and manage database connection status. <br><br><span class="text-xs text-gray-400">Database monitoring requires admin privileges for security.</span><!--]-->`);
      }
      _push(`</p></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/EmptyState.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "DatabaseStatus",
  __ssrInlineRender: true,
  props: {
    initialConnections: {
      type: Array,
      default: () => []
    },
    isAdmin: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    var _a;
    const props = __props;
    const DRIVERS = Object.freeze(["mysql", "pgsql", "sqlite", "sqlsrv"]);
    const mockConnections = [
      {
        name: "SQLite",
        driver: "sqlite",
        host: "N/A",
        database: "/Users/ismartsa/Sites/Laravel-Brive/database/database.sqlite",
        active: true,
        message: "Connected successfully",
        response_time: 3.45,
        databases: ["database.sqlite"]
      },
      {
        name: "MySQL",
        driver: "mysql",
        host: "127.0.0.1",
        database: "laravel_brive",
        active: false,
        message: "Connection failed: SQLSTATE[HY000] [2002] Connection refused",
        response_time: null,
        databases: []
      },
      {
        name: "PostgreSQL",
        driver: "pgsql",
        host: "127.0.0.1",
        database: "laravel_brive",
        active: false,
        message: "Connection failed: SQLSTATE[08006] [7] connection to server failed",
        response_time: null,
        databases: []
      }
    ];
    const connections = shallowRef([...((_a = props.initialConnections) == null ? void 0 : _a.length) > 0 ? props.initialConnections : mockConnections]);
    computed(() => connections.value.length > 0);
    const isRefreshing = ref(false);
    const isVisible = ref(false);
    const refreshController = ref(null);
    const showAddForm = ref(false);
    const editingConnection = ref(null);
    const isSubmitting = ref(false);
    const form = reactive({
      name: "",
      driver: "",
      host: "",
      port: "",
      database: "",
      username: "",
      password: "",
      active: false
    });
    const resetForm = () => {
      Object.assign(form, {
        name: "",
        driver: "",
        host: "",
        port: "",
        database: "",
        username: "",
        password: "",
        active: false
      });
    };
    const closeForm = () => {
      showAddForm.value = false;
      editingConnection.value = null;
      resetForm();
    };
    const saveConnection = async () => {
      var _a2;
      if (isSubmitting.value) return;
      isSubmitting.value = true;
      try {
        const endpoint = editingConnection.value ? route("admin.settings.database.update", editingConnection.value.id) : route("admin.settings.database.store");
        const method = editingConnection.value ? "PUT" : "POST";
        const response = await fetch(endpoint, {
          method,
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "X-CSRF-TOKEN": (_a2 = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : _a2.getAttribute("content")
          },
          body: JSON.stringify(form)
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        if (editingConnection.value) {
          const index = connections.value.findIndex((c) => c.id === editingConnection.value.id);
          if (index !== -1) {
            connections.value[index] = { ...connections.value[index], ...data.connection };
          }
        } else {
          connections.value = [...connections.value, data.connection];
        }
        closeForm();
        await refreshStatus();
      } catch (error) {
        console.error("Failed to save connection:", error);
      } finally {
        isSubmitting.value = false;
      }
    };
    let refreshTimeout = null;
    const debouncedRefresh = () => {
      if (refreshTimeout) clearTimeout(refreshTimeout);
      refreshTimeout = setTimeout(refreshStatus, 300);
    };
    const refreshStatus = async () => {
      if (isRefreshing.value) return;
      if (refreshController.value) {
        refreshController.value.abort();
      }
      isRefreshing.value = true;
      refreshController.value = new AbortController();
      try {
        const response = await fetch(route("admin.settings.database.status"), {
          signal: refreshController.value.signal,
          headers: {
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest"
          }
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        connections.value = data.connections || [];
      } catch (error) {
        if (error.name !== "AbortError") {
          console.error("Failed to refresh database status:", error);
        }
      } finally {
        isRefreshing.value = false;
        refreshController.value = null;
      }
    };
    let refreshInterval = null;
    let observer = null;
    const startAutoRefresh = () => {
      if (refreshInterval) return;
      refreshInterval = setInterval(() => {
        if (isVisible.value && document.visibilityState === "visible") {
          debouncedRefresh();
        }
      }, 6e4);
    };
    const stopAutoRefresh = () => {
      if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
      }
    };
    onMounted(async () => {
      await nextTick();
      if ("IntersectionObserver" in window) {
        observer = new IntersectionObserver(
          (entries) => {
            isVisible.value = entries[0].isIntersecting;
            if (isVisible.value) {
              startAutoRefresh();
            } else {
              stopAutoRefresh();
            }
          },
          { threshold: 0.1 }
        );
        const element = document.querySelector("[data-database-status]");
        if (element) observer.observe(element);
      } else {
        isVisible.value = true;
        startAutoRefresh();
      }
    });
    onUnmounted(() => {
      stopAutoRefresh();
      if (observer) {
        observer.disconnect();
      }
      if (refreshController.value) {
        refreshController.value.abort();
      }
      if (refreshTimeout) {
        clearTimeout(refreshTimeout);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "space-y-4",
        "data-database-status": ""
      }, _attrs))}><header class="flex items-center justify-between mb-6"><div><h3 class="text-lg font-semibold text-gray-900 dark:text-white">Database Connections</h3><p class="text-sm text-gray-600 dark:text-gray-400">Monitor database connection status and performance</p></div>`);
      if (__props.isAdmin) {
        _push(`<div class="flex items-center space-x-3">`);
        _push(ssrRenderComponent(_sfc_main$5, {
          onClick: ($event) => showAddForm.value = true,
          variant: "primary",
          icon: unref(PlusIcon),
          text: "Add Connection"
        }, null, _parent));
        _push(ssrRenderComponent(_sfc_main$5, {
          onClick: refreshStatus,
          disabled: isRefreshing.value,
          variant: "secondary",
          icon: unref(ArrowPathIcon),
          text: isRefreshing.value ? "Refreshing..." : "Refresh",
          loading: isRefreshing.value
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</header><div class="grid gap-4"><!--[-->`);
      ssrRenderList(connections.value, (connection) => {
        _push(`<div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6"><div class="flex items-center justify-between mb-4"><div class="flex items-center space-x-3"><div class="${ssrRenderClass([
          "w-3 h-3 rounded-full",
          connection.active ? "bg-green-500" : "bg-red-500"
        ])}"></div><div><h4 class="text-lg font-semibold text-gray-900 dark:text-white">${ssrInterpolate(connection.name)}</h4><p class="text-sm text-gray-600 dark:text-gray-400">${ssrInterpolate(connection.driver)} • ${ssrInterpolate(connection.host)}</p></div></div><div class="text-right"><div class="${ssrRenderClass([connection.active ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400", "text-sm font-medium"])}">${ssrInterpolate(connection.active ? "Connected" : "Disconnected")}</div>`);
        if (connection.response_time) {
          _push(`<div class="text-xs text-gray-500 dark:text-gray-400">${ssrInterpolate(connection.response_time)}ms </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div><div class="${ssrRenderClass([connection.active ? "bg-green-50 dark:bg-green-900/20" : "bg-red-50 dark:bg-red-900/20", "mb-4 p-3 rounded-md"])}"><p class="${ssrRenderClass([connection.active ? "text-green-800 dark:text-green-200" : "text-red-800 dark:text-red-200", "text-sm"])}">${ssrInterpolate(connection.message)}</p></div>`);
        if (connection.active && connection.databases && connection.databases.length > 0) {
          _push(`<div><h5 class="text-sm font-medium text-gray-900 dark:text-white mb-2">Available Databases (${ssrInterpolate(connection.databases.length)})</h5><div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2"><!--[-->`);
          ssrRenderList(connection.databases, (database) => {
            _push(`<div class="px-3 py-2 bg-gray-50 dark:bg-gray-700 rounded-md text-sm text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600"><div class="flex items-center space-x-2"><div class="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div><span class="truncate">${ssrInterpolate(database)}</span></div></div>`);
          });
          _push(`<!--]--></div></div>`);
        } else if (connection.active && (!connection.databases || connection.databases.length === 0)) {
          _push(`<div class="text-sm text-gray-500 dark:text-gray-400 italic"> No databases found or unable to list databases </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div>`);
      if (connections.value.length === 0) {
        _push(ssrRenderComponent(_sfc_main$2, { "is-admin": __props.isAdmin }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (showAddForm.value || editingConnection.value) {
        _push(ssrRenderComponent(_sfc_main$3, {
          editing: editingConnection.value,
          form,
          drivers: unref(DRIVERS),
          "is-submitting": isSubmitting.value,
          onClose: closeForm,
          onSave: saveConnection,
          "onUpdate:form": ($event) => form = $event
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Settings/DatabaseStatus.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Settings",
  __ssrInlineRender: true,
  props: {
    settings: Object,
    groups: Object,
    databaseConnections: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    if ("serviceWorker" in navigator && true) {
      navigator.serviceWorker.register("/sw.js").catch(console.error);
    }
    const props = __props;
    const UI = {
      // Layout classes
      HEADER: "bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700",
      CONTAINER: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
      MAIN: "min-h-screen bg-gray-50 dark:bg-gray-900 py-6",
      GRID: "lg:grid lg:grid-cols-12 gap-6",
      CARD: "bg-white dark:bg-gray-800 shadow-sm rounded-2xl p-6 mt-6",
      // Header components
      HEADER_CONTENT: "flex items-center justify-between h-16",
      HEADER_LEFT: "flex items-center space-x-4",
      HEADER_RIGHT: "flex items-center space-x-2",
      HEADER_ICON: "w-8 h-8 text-gray-600 dark:text-gray-400",
      HEADER_TITLE: "text-2xl font-semibold text-gray-900 dark:text-white",
      HEADER_SUBTITLE: "text-sm text-gray-500 dark:text-gray-400",
      // Flash messages
      FLASH_CONTAINER: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6",
      FLASH_SUCCESS: "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200 px-4 py-3 rounded-xl flex items-center",
      FLASH_ICON: "w-5 h-5 mr-3 flex-shrink-0",
      // Sidebar navigation
      SIDEBAR: "bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-2 space-y-1",
      SIDEBAR_ITEM_BASE: "group flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 w-full text-left",
      SIDEBAR_ITEM_ACTIVE: "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 shadow-sm",
      SIDEBAR_ITEM_INACTIVE: "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/50",
      SIDEBAR_ICON: "w-5 h-5 mr-3 flex-shrink-0",
      SIDEBAR_CHEVRON: "w-4 h-4 ml-auto text-blue-600 dark:text-blue-400",
      // Content sections
      CONTENT_CARD: "bg-white dark:bg-gray-800 shadow-sm rounded-2xl overflow-hidden",
      CONTENT_HEADER: "px-6 py-4 border-b border-gray-200 dark:border-gray-700",
      CONTENT_TITLE: "text-lg font-semibold text-gray-900 dark:text-white flex items-center",
      CONTENT_BODY: "p-6",
      CONTENT_GRID: "grid grid-cols-1 gap-6",
      // Setting items
      SETTING_ITEM: "bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4",
      SETTING_LABEL: "block text-sm font-semibold text-gray-900 dark:text-white mb-1",
      SETTING_DESC: "text-sm text-gray-600 dark:text-gray-400",
      // Buttons
      BUTTON_BASE: "inline-flex items-center justify-center font-medium rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200",
      BUTTON_ICON: "w-4 h-4 mr-2",
      // Transitions
      TRANSITION: {
        "enter-active-class": "transition ease-out duration-300",
        "enter-from-class": "opacity-0 transform scale-95",
        "enter-to-class": "opacity-100 transform scale-100",
        "leave-active-class": "transition ease-in duration-200",
        "leave-from-class": "opacity-100 transform scale-100",
        "leave-to-class": "opacity-0 transform scale-95"
      }
    };
    const ICONS = Object.freeze({
      branding: BuildingOfficeIcon,
      contact: PhoneIcon,
      social: ShareIcon,
      system: CogIcon,
      database: CircleStackIcon
    });
    const COMPONENTS = Object.freeze({
      string: _sfc_main$9,
      boolean: _sfc_main$8,
      integer: _sfc_main$7,
      file: _sfc_main$6
    });
    const page = usePage();
    const isAdmin = computed(
      () => {
        var _a, _b, _c;
        return ((_a = page.props.auth.can) == null ? void 0 : _a["manage courses"]) || ((_c = (_b = page.props.auth.user) == null ? void 0 : _b.roles) == null ? void 0 : _c.some((role) => role.name === "admin"));
      }
    );
    const activeTab = ref(Object.keys(props.groups || {})[0] || "");
    const originalSettings = shallowRef({});
    const fileUploads = shallowRef({});
    const form = useForm({ settings: {} });
    const isInitialized = ref(false);
    const message = ref({ type: "", text: "", show: false });
    const hasValidData = computed(
      () => props.settings && props.groups && Object.keys(props.settings).length > 0 && Object.keys(props.groups).length > 0
    );
    const initializeSettings = async () => {
      performance.now();
      await nextTick();
      if (!props.settings || Object.keys(props.settings).length === 0) {
        isInitialized.value = true;
        return;
      }
      const allSettings = Object.values(props.settings).flat();
      const settings = {};
      const original = {};
      allSettings.forEach((setting) => {
        if (setting && setting.key !== void 0) {
          settings[setting.key] = setting.value;
          original[setting.key] = setting.value;
        }
      });
      form.settings = settings;
      originalSettings.value = original;
      isInitialized.value = true;
      const settingsMap = /* @__PURE__ */ new Map();
      allSettings.forEach((setting) => {
        if (setting && setting.key !== void 0) {
          settingsMap.set(setting.key, setting);
        }
      });
      window.__settingsCache = settingsMap;
    };
    const preloadResources = () => {
      if ("requestIdleCallback" in window) {
        requestIdleCallback(() => {
          if (isAdmin.value) {
            const link = document.createElement("link");
            link.rel = "prefetch";
            link.href = route("admin.settings.database.status");
            document.head.appendChild(link);
          }
        });
      }
    };
    onMounted(async () => {
      await initializeSettings();
      preloadResources();
    });
    const hasChanges = computed(
      () => Object.keys(form.settings).some((key) => form.settings[key] !== originalSettings.value[key])
    );
    const saveStatus = computed(() => {
      const states = {
        processing: { color: "bg-yellow-400", text: "Saving..." },
        success: { color: "bg-green-400", text: "Saved" },
        changed: { color: "bg-orange-400", text: "Unsaved changes" },
        default: { color: "bg-gray-400", text: "Up to date" }
      };
      return form.processing ? states.processing : form.recentlySuccessful ? states.success : hasChanges.value ? states.changed : states.default;
    });
    const allTabs = computed(() => ({
      ...props.groups,
      database: "Database Status"
    }));
    const sidebarClasses = computed(() => {
      const classes = {};
      const tabs = allTabs.value;
      const active = activeTab.value;
      Object.keys(tabs).forEach((key) => {
        classes[key] = key === active ? `${UI.SIDEBAR_ITEM_BASE} ${UI.SIDEBAR_ITEM_ACTIVE}` : `${UI.SIDEBAR_ITEM_BASE} ${UI.SIDEBAR_ITEM_INACTIVE}`;
      });
      return classes;
    });
    const tabIcons = computed(() => ICONS);
    const inputComponents = computed(() => COMPONENTS);
    const settingLabels = computed(() => {
      if (!isInitialized.value) return {};
      const labels = {};
      const allSettings = Object.values(props.settings).flat();
      allSettings.forEach((setting) => {
        const key = setting.key;
        labels[key] = key.split("_").map(
          (word) => word.charAt(0).toUpperCase() + word.slice(1)
        ).join(" ");
      });
      return labels;
    });
    const setActiveTab = (tabKey) => {
      if (activeTab.value !== tabKey) {
        activeTab.value = tabKey;
      }
    };
    const updateSetting = (key, value) => {
      if (form.settings[key] !== value) {
        form.settings[key] = value;
      }
    };
    const getButtonClass = (type) => {
      const baseClasses2 = `${UI.BUTTON_BASE} px-6 py-2.5 text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-sm`;
      const variants = {
        reset: `${baseClasses2} text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/30 focus:ring-red-500`,
        preview: `${baseClasses2} text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600 focus:ring-blue-500`,
        save: `${baseClasses2} text-white bg-blue-600 hover:bg-blue-700 focus:ring-blue-500`
      };
      return variants[type] || variants.preview;
    };
    const updateSettings = () => {
      const formData = new FormData();
      const allSettings = Object.values(props.settings).flat();
      const settingsMap = new Map(allSettings.map((s) => [s.key, s]));
      const settingsArray = Object.entries(form.settings).map(([key, value]) => {
        const setting = settingsMap.get(key);
        return setting ? { key, value, type: setting.type } : null;
      }).filter(Boolean);
      formData.append("settings", JSON.stringify(settingsArray));
      Object.entries(fileUploads.value).forEach(([key, file]) => {
        file && formData.append(`file_${key}`, file);
      });
      form.post(route("admin.settings.update"), {
        data: formData,
        forceFormData: true,
        onSuccess: () => {
          Object.assign(originalSettings.value, form.settings);
          fileUploads.value = {};
          showMessage("success", "Settings updated successfully!");
        },
        onError: (errors) => {
          const errorMsg = Object.values(errors).flat().join(", ") || "Failed to update settings";
          showMessage("error", errorMsg);
        }
      });
    };
    const handleFileUpload = (event, key) => {
      var _a;
      const file = (_a = event.target.files) == null ? void 0 : _a[0];
      if (!file) return;
      fileUploads.value[key] = file;
      const reader = new FileReader();
      reader.onload = (e) => updateSetting(key, e.target.result);
      reader.readAsDataURL(file);
    };
    const resetSettings = () => {
      confirm("Are you sure you want to reset all settings to default values?") && form.post(route("admin.settings.reset"), {
        onSuccess: () => {
          showMessage("success", "Settings reset to default values successfully!");
          setTimeout(() => location.reload(), 1500);
        },
        onError: (errors) => {
          const errorMsg = Object.values(errors).flat().join(", ") || "Failed to reset settings";
          showMessage("error", errorMsg);
        }
      });
    };
    const showMessage = (type, text) => {
      message.value = { type, text, show: true };
      setTimeout(() => {
        message.value.show = false;
      }, 5e3);
    };
    const previewChanges = () => window.open("/", "_blank");
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$a, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass(UI.HEADER)}"${_scopeId}><div class="${ssrRenderClass(UI.CONTAINER)}"${_scopeId}><div class="${ssrRenderClass(UI.HEADER_CONTENT)}"${_scopeId}><div class="${ssrRenderClass(UI.HEADER_LEFT)}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(CogIcon), {
              class: UI.HEADER_ICON
            }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><h1 class="${ssrRenderClass(UI.HEADER_TITLE)}"${_scopeId}>Settings</h1><p class="${ssrRenderClass(UI.HEADER_SUBTITLE)}"${_scopeId}>Manage your application preferences</p></div></div><div class="${ssrRenderClass(UI.HEADER_RIGHT)}"${_scopeId}><div class="${ssrRenderClass([saveStatus.value.color, "w-2 h-2 rounded-full"])}"${_scopeId}></div><span class="${ssrRenderClass(UI.HEADER_SUBTITLE)}"${_scopeId}>${ssrInterpolate(saveStatus.value.text)}</span></div></div></div></div>`);
          } else {
            return [
              withMemo([saveStatus.value], () => (openBlock(), createBlock("div", {
                class: UI.HEADER
              }, [
                createVNode("div", {
                  class: UI.CONTAINER
                }, [
                  createVNode("div", {
                    class: UI.HEADER_CONTENT
                  }, [
                    createVNode("div", {
                      class: UI.HEADER_LEFT
                    }, [
                      createVNode(unref(CogIcon), {
                        class: UI.HEADER_ICON
                      }, null, 8, ["class"]),
                      createVNode("div", null, [
                        createVNode("h1", {
                          class: UI.HEADER_TITLE
                        }, "Settings", 2),
                        createVNode("p", {
                          class: UI.HEADER_SUBTITLE
                        }, "Manage your application preferences", 2)
                      ])
                    ], 2),
                    createVNode("div", {
                      class: UI.HEADER_RIGHT
                    }, [
                      createVNode("div", {
                        class: ["w-2 h-2 rounded-full", saveStatus.value.color]
                      }, null, 2),
                      createVNode("span", {
                        class: UI.HEADER_SUBTITLE
                      }, toDisplayString(saveStatus.value.text), 3)
                    ], 2)
                  ], 2)
                ], 2)
              ], 2)), _cache, 0)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass(UI.MAIN)}"${_scopeId}>`);
            if (_ctx.$page.props.flash.success) {
              _push2(`<div class="${ssrRenderClass(UI.FLASH_CONTAINER)}"${_scopeId}><div class="${ssrRenderClass(UI.FLASH_SUCCESS)}"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(CheckCircleIcon), {
                class: UI.FLASH_ICON
              }, null, _parent2, _scopeId));
              _push2(`<span class="font-medium"${_scopeId}>${ssrInterpolate(_ctx.$page.props.flash.success)}</span></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="${ssrRenderClass(UI.CONTAINER)}"${_scopeId}><div class="${ssrRenderClass(UI.GRID)}"${_scopeId}><div class="lg:col-span-3"${_scopeId}><nav class="${ssrRenderClass(UI.SIDEBAR)}"${_scopeId}><!--[-->`);
            ssrRenderList(allTabs.value, (groupName, groupKey) => {
              _push2(`<button class="${ssrRenderClass(sidebarClasses.value[groupKey])}"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(tabIcons.value[groupKey]), {
                class: UI.SIDEBAR_ICON
              }, null), _parent2, _scopeId);
              _push2(`<span class="truncate"${_scopeId}>${ssrInterpolate(groupName)}</span>`);
              if (activeTab.value === groupKey) {
                _push2(ssrRenderComponent(unref(ChevronRightIcon), {
                  class: UI.SIDEBAR_CHEVRON
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</button>`);
            });
            _push2(`<!--]--></nav></div><div class="lg:col-span-9"${_scopeId}>`);
            if (!isInitialized.value) {
              _push2(`<div class="${ssrRenderClass(UI.CONTENT_CARD)}"${_scopeId}><div class="flex items-center justify-center"${_scopeId}><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"${_scopeId}></div><span class="ml-3 text-gray-600 dark:text-gray-400"${_scopeId}>Loading settings...</span></div></div>`);
            } else if (!hasValidData.value) {
              _push2(`<div class="${ssrRenderClass(UI.CONTENT_CARD)}"${_scopeId}><div class="flex flex-col items-center justify-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(CogIcon), { class: "w-12 h-12 text-gray-400 mb-4" }, null, _parent2, _scopeId));
              _push2(`<h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2"${_scopeId}>No Settings Available</h3><p class="text-gray-600 dark:text-gray-400 text-center"${_scopeId}>There are no settings configured for this application.</p></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (message.value.show) {
              _push2(`<div class="${ssrRenderClass([
                "fixed top-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg transition-all duration-300",
                message.value.type === "success" ? "bg-green-50 border border-green-200 text-green-800" : "bg-red-50 border border-red-200 text-red-800"
              ])}"${_scopeId}><div class="flex items-center gap-3"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(message.value.type === "success" ? "CheckCircleIcon" : "ExclamationTriangleIcon"), {
                class: [
                  "h-5 w-5",
                  message.value.type === "success" ? "text-green-600" : "text-red-600"
                ]
              }, null), _parent2, _scopeId);
              _push2(`<p class="text-sm font-medium"${_scopeId}>${ssrInterpolate(message.value.text)}</p><button class="ml-auto text-gray-400 hover:text-gray-600"${_scopeId}><span class="sr-only"${_scopeId}>Close</span><svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"${_scopeId}></path></svg></button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<form class="space-y-8"${_scopeId}><!--[-->`);
            ssrRenderList(__props.settings, (groupSettings, groupKey) => {
              _push2(`<div style="${ssrRenderStyle(activeTab.value === groupKey ? null : { display: "none" })}"${_scopeId}><div class="${ssrRenderClass(UI.CONTENT_CARD)}"${_scopeId}><div class="${ssrRenderClass(UI.CONTENT_HEADER)}"${_scopeId}><h3 class="${ssrRenderClass(UI.CONTENT_TITLE)}"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(tabIcons.value[groupKey]), { class: "w-5 h-5 mr-2" }, null), _parent2, _scopeId);
              _push2(` ${ssrInterpolate(__props.groups[groupKey])}</h3></div><div class="${ssrRenderClass(UI.CONTENT_BODY)}"${_scopeId}><div class="${ssrRenderClass(UI.CONTENT_GRID)}"${_scopeId}><!--[-->`);
              ssrRenderList(groupSettings, (setting) => {
                _push2(`<div class="${ssrRenderClass(UI.SETTING_ITEM)}"${_scopeId}><div${_scopeId}><label${ssrRenderAttr("for", setting.key)} class="${ssrRenderClass(UI.SETTING_LABEL)}"${_scopeId}>${ssrInterpolate(settingLabels.value[setting.key])}</label>`);
                if (setting.description) {
                  _push2(`<p class="${ssrRenderClass(UI.SETTING_DESC)}"${_scopeId}>${ssrInterpolate(setting.description)}</p>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
                ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(inputComponents.value[setting.type]), {
                  setting,
                  modelValue: unref(form).settings[setting.key],
                  "onUpdate:modelValue": ($event) => updateSetting(setting.key, $event),
                  onFileUpload: handleFileUpload
                }, null), _parent2, _scopeId);
                _push2(`</div>`);
              });
              _push2(`<!--]--></div></div></div></div>`);
            });
            _push2(`<!--]--><div style="${ssrRenderStyle(activeTab.value === "database" ? null : { display: "none" })}"${_scopeId}><div class="${ssrRenderClass(UI.CONTENT_CARD)}"${_scopeId}><div class="${ssrRenderClass(UI.CONTENT_HEADER)}"${_scopeId}><h3 class="${ssrRenderClass(UI.CONTENT_TITLE)}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(CircleStackIcon), { class: "w-5 h-5 mr-2" }, null, _parent2, _scopeId));
            _push2(` Database Status </h3></div><div class="${ssrRenderClass(UI.CONTENT_BODY)}"${_scopeId}>`);
            if (activeTab.value === "database") {
              _push2(ssrRenderComponent(_sfc_main$1, {
                "initial-connections": isAdmin.value ? __props.databaseConnections : [],
                "is-admin": isAdmin.value
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div>`);
            if (isInitialized.value) {
              _push2(`<div class="${ssrRenderClass(UI.CARD)}"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><button type="button"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass(getButtonClass("reset"))}"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(ArrowPathIcon), {
                class: UI.BUTTON_ICON
              }, null, _parent2, _scopeId));
              _push2(` Reset to Default </button><div class="flex items-center space-x-3"${_scopeId}><button type="button" class="${ssrRenderClass(getButtonClass("preview"))}"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(EyeIcon), {
                class: UI.BUTTON_ICON
              }, null, _parent2, _scopeId));
              _push2(` Preview </button><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing || !hasChanges.value) ? " disabled" : ""} class="${ssrRenderClass(getButtonClass("save"))}"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(unref(form).processing ? "ArrowPathIcon" : "CheckIcon"), {
                class: [UI.BUTTON_ICON, { "animate-spin": unref(form).processing }]
              }, null), _parent2, _scopeId);
              _push2(` ${ssrInterpolate(unref(form).processing ? "Saving..." : "Save Changes")}</button></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</form></div></div></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: UI.MAIN
              }, [
                createVNode(Transition, UI.TRANSITION, {
                  default: withCtx(() => [
                    _ctx.$page.props.flash.success ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: UI.FLASH_CONTAINER
                    }, [
                      createVNode("div", {
                        class: UI.FLASH_SUCCESS
                      }, [
                        createVNode(unref(CheckCircleIcon), {
                          class: UI.FLASH_ICON
                        }, null, 8, ["class"]),
                        createVNode("span", { class: "font-medium" }, toDisplayString(_ctx.$page.props.flash.success), 1)
                      ], 2)
                    ], 2)) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 16),
                createVNode("div", {
                  class: UI.CONTAINER
                }, [
                  createVNode("div", {
                    class: UI.GRID
                  }, [
                    createVNode("div", { class: "lg:col-span-3" }, [
                      withMemo([activeTab.value, isAdmin.value], () => (openBlock(), createBlock("nav", {
                        class: UI.SIDEBAR
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(allTabs.value, (groupName, groupKey) => {
                          return openBlock(), createBlock("button", {
                            key: groupKey,
                            onClick: ($event) => setActiveTab(groupKey),
                            class: sidebarClasses.value[groupKey]
                          }, [
                            (openBlock(), createBlock(resolveDynamicComponent(tabIcons.value[groupKey]), {
                              class: UI.SIDEBAR_ICON
                            }, null, 8, ["class"])),
                            createVNode("span", { class: "truncate" }, toDisplayString(groupName), 1),
                            activeTab.value === groupKey ? (openBlock(), createBlock(unref(ChevronRightIcon), {
                              key: 0,
                              class: UI.SIDEBAR_CHEVRON
                            }, null, 8, ["class"])) : createCommentVNode("", true)
                          ], 10, ["onClick"]);
                        }), 128))
                      ], 2)), _cache, 0)
                    ]),
                    createVNode("div", { class: "lg:col-span-9" }, [
                      !isInitialized.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: UI.CONTENT_CARD
                      }, [
                        createVNode("div", { class: "flex items-center justify-center" }, [
                          createVNode("div", { class: "animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" }),
                          createVNode("span", { class: "ml-3 text-gray-600 dark:text-gray-400" }, "Loading settings...")
                        ])
                      ], 2)) : !hasValidData.value ? (openBlock(), createBlock("div", {
                        key: 1,
                        class: UI.CONTENT_CARD
                      }, [
                        createVNode("div", { class: "flex flex-col items-center justify-center" }, [
                          createVNode(unref(CogIcon), { class: "w-12 h-12 text-gray-400 mb-4" }),
                          createVNode("h3", { class: "text-lg font-medium text-gray-900 dark:text-white mb-2" }, "No Settings Available"),
                          createVNode("p", { class: "text-gray-600 dark:text-gray-400 text-center" }, "There are no settings configured for this application.")
                        ])
                      ], 2)) : createCommentVNode("", true),
                      message.value.show ? (openBlock(), createBlock("div", {
                        key: 2,
                        class: [
                          "fixed top-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg transition-all duration-300",
                          message.value.type === "success" ? "bg-green-50 border border-green-200 text-green-800" : "bg-red-50 border border-red-200 text-red-800"
                        ]
                      }, [
                        createVNode("div", { class: "flex items-center gap-3" }, [
                          (openBlock(), createBlock(resolveDynamicComponent(message.value.type === "success" ? "CheckCircleIcon" : "ExclamationTriangleIcon"), {
                            class: [
                              "h-5 w-5",
                              message.value.type === "success" ? "text-green-600" : "text-red-600"
                            ]
                          }, null, 8, ["class"])),
                          createVNode("p", { class: "text-sm font-medium" }, toDisplayString(message.value.text), 1),
                          createVNode("button", {
                            onClick: ($event) => message.value.show = false,
                            class: "ml-auto text-gray-400 hover:text-gray-600"
                          }, [
                            createVNode("span", { class: "sr-only" }, "Close"),
                            (openBlock(), createBlock("svg", {
                              class: "h-4 w-4",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M6 18L18 6M6 6l12 12"
                              })
                            ]))
                          ], 8, ["onClick"])
                        ])
                      ], 2)) : createCommentVNode("", true),
                      createVNode("form", {
                        onSubmit: withModifiers(updateSettings, ["prevent"]),
                        class: "space-y-8"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.settings, (groupSettings, groupKey, ___, _cached) => {
                          const _memo = [activeTab.value, unref(form).settings];
                          if (_cached && _cached.key === groupKey && isMemoSame(_cached, _memo)) return _cached;
                          const _item = withDirectives((openBlock(), createBlock("div", { key: groupKey }, [
                            createVNode("div", {
                              class: UI.CONTENT_CARD
                            }, [
                              createVNode("div", {
                                class: UI.CONTENT_HEADER
                              }, [
                                createVNode("h3", {
                                  class: UI.CONTENT_TITLE
                                }, [
                                  (openBlock(), createBlock(resolveDynamicComponent(tabIcons.value[groupKey]), { class: "w-5 h-5 mr-2" })),
                                  createTextVNode(" " + toDisplayString(__props.groups[groupKey]), 1)
                                ], 2)
                              ], 2),
                              createVNode("div", {
                                class: UI.CONTENT_BODY
                              }, [
                                createVNode("div", {
                                  class: UI.CONTENT_GRID
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(groupSettings, (setting, __, ___2, _cached2) => {
                                    const _memo2 = [unref(form).settings[setting.key]];
                                    if (_cached2 && _cached2.key === setting.key && isMemoSame(_cached2, _memo2)) return _cached2;
                                    const _item2 = (openBlock(), createBlock("div", {
                                      key: setting.key,
                                      class: UI.SETTING_ITEM
                                    }, [
                                      createVNode("div", null, [
                                        createVNode("label", {
                                          for: setting.key,
                                          class: UI.SETTING_LABEL
                                        }, toDisplayString(settingLabels.value[setting.key]), 11, ["for"]),
                                        setting.description ? (openBlock(), createBlock("p", {
                                          key: 0,
                                          class: UI.SETTING_DESC
                                        }, toDisplayString(setting.description), 3)) : createCommentVNode("", true)
                                      ]),
                                      (openBlock(), createBlock(resolveDynamicComponent(inputComponents.value[setting.type]), {
                                        setting,
                                        modelValue: unref(form).settings[setting.key],
                                        "onUpdate:modelValue": ($event) => updateSetting(setting.key, $event),
                                        onFileUpload: handleFileUpload
                                      }, null, 40, ["setting", "modelValue", "onUpdate:modelValue"]))
                                    ], 2));
                                    _item2.memo = _memo2;
                                    return _item2;
                                  }, _cache, 1), 128))
                                ], 2)
                              ], 2)
                            ], 2)
                          ])), [
                            [vShow, activeTab.value === groupKey]
                          ]);
                          _item.memo = _memo;
                          return _item;
                        }, _cache, 3), 128)),
                        withMemo([activeTab.value], () => withDirectives((openBlock(), createBlock("div", null, [
                          createVNode("div", {
                            class: UI.CONTENT_CARD
                          }, [
                            createVNode("div", {
                              class: UI.CONTENT_HEADER
                            }, [
                              createVNode("h3", {
                                class: UI.CONTENT_TITLE
                              }, [
                                createVNode(unref(CircleStackIcon), { class: "w-5 h-5 mr-2" }),
                                createTextVNode(" Database Status ")
                              ], 2)
                            ], 2),
                            createVNode("div", {
                              class: UI.CONTENT_BODY
                            }, [
                              activeTab.value === "database" ? (openBlock(), createBlock(_sfc_main$1, {
                                key: 0,
                                "initial-connections": isAdmin.value ? __props.databaseConnections : [],
                                "is-admin": isAdmin.value
                              }, null, 8, ["initial-connections", "is-admin"])) : createCommentVNode("", true)
                            ], 2)
                          ], 2)
                        ], 512)), [
                          [vShow, activeTab.value === "database"]
                        ]), _cache, 5),
                        isInitialized.value ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: UI.CARD
                        }, [
                          createVNode("div", { class: "flex items-center justify-between" }, [
                            createVNode("button", {
                              type: "button",
                              onClick: resetSettings,
                              disabled: unref(form).processing,
                              class: getButtonClass("reset")
                            }, [
                              createVNode(unref(ArrowPathIcon), {
                                class: UI.BUTTON_ICON
                              }, null, 8, ["class"]),
                              createTextVNode(" Reset to Default ")
                            ], 10, ["disabled"]),
                            createVNode("div", { class: "flex items-center space-x-3" }, [
                              createVNode("button", {
                                type: "button",
                                onClick: previewChanges,
                                class: getButtonClass("preview")
                              }, [
                                createVNode(unref(EyeIcon), {
                                  class: UI.BUTTON_ICON
                                }, null, 8, ["class"]),
                                createTextVNode(" Preview ")
                              ], 2),
                              createVNode("button", {
                                type: "submit",
                                disabled: unref(form).processing || !hasChanges.value,
                                class: getButtonClass("save")
                              }, [
                                (openBlock(), createBlock(resolveDynamicComponent(unref(form).processing ? "ArrowPathIcon" : "CheckIcon"), {
                                  class: [UI.BUTTON_ICON, { "animate-spin": unref(form).processing }]
                                }, null, 8, ["class"])),
                                createTextVNode(" " + toDisplayString(unref(form).processing ? "Saving..." : "Save Changes"), 1)
                              ], 10, ["disabled"])
                            ])
                          ])
                        ], 2)) : createCommentVNode("", true)
                      ], 32)
                    ])
                  ], 2)
                ], 2)
              ], 2)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
