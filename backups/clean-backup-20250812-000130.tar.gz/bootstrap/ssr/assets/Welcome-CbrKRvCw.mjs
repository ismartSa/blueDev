import { ref, onMounted, computed, unref, withCtx, createVNode, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import { a as _sfc_main$1, _ as _sfc_main$2 } from "./SwitchLangNavbar-hXFGqixW.mjs";
import { _ as _sfc_main$3 } from "./SwitchDarkMode-qMtWjm8v.mjs";
import { Head, Link } from "@inertiajs/vue3";
import _sfc_main$4 from "./Footer-BZHBgS6s.mjs";
import { ChevronDownIcon, Cog6ToothIcon, UserIcon, ArrowRightOnRectangleIcon } from "@heroicons/vue/24/outline";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main = {
  __name: "Welcome",
  __ssrInlineRender: true,
  props: {
    canLogin: Boolean,
    canRegister: Boolean,
    laravelVersion: String,
    phpVersion: String,
    courses: {
      type: [Array, Object],
      default: () => []
    }
  },
  setup(__props) {
    const isVisible = ref(false);
    const currentSlide = ref(0);
    ref(null);
    const showUserDropdown = ref(false);
    onMounted(() => {
      setTimeout(() => isVisible.value = true, 200);
      setInterval(() => {
        currentSlide.value = (currentSlide.value + 1) % testimonials.length;
      }, 4e3);
    });
    const content = computed(() => ({
      hero: {
        title: "Master Skills That Matter",
        titleAr: "أتقن المهارات المهمة",
        subtitle: "Unlock your potential with world-class online education",
        subtitleAr: "اطلق إمكاناتك مع التعليم الإلكتروني عالمي المستوى",
        cta: "Explore Courses",
        ctaAr: "استكشف الدورات"
      },
      nav: {
        home: "Home",
        courses: "Courses",
        about: "About",
        contact: "Contact",
        login: "Login",
        register: "Register",
        dashboard: "Dashboard",
        profile: "Profile",
        logout: "Logout"
      }
    }));
    const features = [
      {
        icon: "🎯",
        title: "Personalized Learning",
        titleAr: "تعلم مخصص",
        desc: "AI-powered recommendations tailored to your goals",
        descAr: "توصيات مدعومة بالذكاء الاصطناعي مصممة لأهدافك"
      },
      {
        icon: "⚡",
        title: "Lightning Fast",
        titleAr: "سريع البرق",
        desc: "Optimized platform for seamless learning experience",
        descAr: "منصة محسنة لتجربة تعلم سلسة"
      },
      {
        icon: "🏆",
        title: "Industry Certified",
        titleAr: "معتمد من الصناعة",
        desc: "Certificates recognized by top employers worldwide",
        descAr: "شهادات معترف بها من كبار أصحاب العمل عالمياً"
      },
      {
        icon: "🌍",
        title: "Global Access",
        titleAr: "وصول عالمي",
        desc: "Learn anywhere, anytime with mobile-first design",
        descAr: "تعلم في أي مكان وأي وقت بتصميم يركز على الهاتف المحمول"
      }
    ];
    const metrics = [
      { value: "25K+", label: "Students", labelAr: "طالب" },
      { value: "150+", label: "Courses", labelAr: "دورة" },
      { value: "95%", label: "Success Rate", labelAr: "معدل النجاح" },
      { value: "24/7", label: "Support", labelAr: "دعم" }
    ];
    const testimonials = [
      {
        name: "Alex Chen",
        role: "Software Engineer",
        company: "Google",
        quote: "The best investment I made for my career growth.",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&crop=face"
      },
      {
        name: "Sarah Kim",
        role: "Product Manager",
        company: "Microsoft",
        quote: "Practical skills that I use every day at work.",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=80&h=80&fit=crop&crop=face"
      },
      {
        name: "David Wilson",
        role: "Data Scientist",
        company: "Netflix",
        quote: "Transformed my understanding of machine learning.",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&crop=face"
      }
    ];
    const categories = [
      { name: "Web Development", icon: "💻", courses: 45 },
      { name: "Data Science", icon: "📊", courses: 32 },
      { name: "Design", icon: "🎨", courses: 28 },
      { name: "Business", icon: "💼", courses: 38 },
      { name: "Marketing", icon: "📈", courses: 25 },
      { name: "Mobile Dev", icon: "📱", courses: 22 }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: content.value.nav.home
      }, null, _parent));
      _push(`<div class="${ssrRenderClass([{ "opacity-100": isVisible.value, "opacity-0": !isVisible.value }, "min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300"])}" data-v-4d977bbf><header class="fixed top-0 w-full bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800 z-50" data-v-4d977bbf><div class="max-w-6xl mx-auto px-6" data-v-4d977bbf><div class="flex items-center justify-between h-16" data-v-4d977bbf><div class="flex items-center space-x-3" data-v-4d977bbf>`);
      _push(ssrRenderComponent(_sfc_main$1, { class: "h-8 w-auto" }, null, _parent));
      _push(`<span class="text-xl font-bold text-gray-900 dark:text-white" data-v-4d977bbf>${ssrInterpolate(_ctx.$page.props.app.name)}</span></div><nav class="hidden md:flex items-center space-x-8" data-v-4d977bbf><!--[-->`);
      ssrRenderList(["home", "courses", "about", "contact"], (item) => {
        _push(`<a${ssrRenderAttr("href", `#${item}`)} class="nav-link" data-v-4d977bbf>${ssrInterpolate(content.value.nav[item])}</a>`);
      });
      _push(`<!--]--></nav><div class="flex items-center space-x-4" data-v-4d977bbf>`);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      if (__props.canLogin) {
        _push(`<div class="flex items-center space-x-3" data-v-4d977bbf>`);
        if (_ctx.$page.props.auth.user) {
          _push(`<div class="relative" data-v-4d977bbf><button class="flex items-center space-x-2 px-3 py-2 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" data-v-4d977bbf><div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium" data-v-4d977bbf>${ssrInterpolate(_ctx.$page.props.auth.user.name.charAt(0).toUpperCase())}</div><span class="hidden sm:block text-sm font-medium text-gray-700 dark:text-gray-300" data-v-4d977bbf>${ssrInterpolate(_ctx.$page.props.auth.user.name)}</span>`);
          _push(ssrRenderComponent(unref(ChevronDownIcon), {
            class: ["w-4 h-4 text-gray-500 transition-transform", { "rotate-180": showUserDropdown.value }]
          }, null, _parent));
          _push(`</button><div style="${ssrRenderStyle(showUserDropdown.value ? null : { display: "none" })}" class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-1 z-50" data-v-4d977bbf>`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("dashboard"),
            class: "flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(Cog6ToothIcon), { class: "w-4 h-4 mr-3" }, null, _parent2, _scopeId));
                _push2(` ${ssrInterpolate(content.value.nav.dashboard)}`);
              } else {
                return [
                  createVNode(unref(Cog6ToothIcon), { class: "w-4 h-4 mr-3" }),
                  createTextVNode(" " + toDisplayString(content.value.nav.dashboard), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("profile.edit"),
            class: "flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(UserIcon), { class: "w-4 h-4 mr-3" }, null, _parent2, _scopeId));
                _push2(` ${ssrInterpolate(content.value.nav.profile)}`);
              } else {
                return [
                  createVNode(unref(UserIcon), { class: "w-4 h-4 mr-3" }),
                  createTextVNode(" " + toDisplayString(content.value.nav.profile), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`<hr class="my-1 border-gray-200 dark:border-gray-700" data-v-4d977bbf>`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("logout"),
            method: "post",
            class: "flex items-center px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(ArrowRightOnRectangleIcon), { class: "w-4 h-4 mr-3" }, null, _parent2, _scopeId));
                _push2(` ${ssrInterpolate(content.value.nav.logout)}`);
              } else {
                return [
                  createVNode(unref(ArrowRightOnRectangleIcon), { class: "w-4 h-4 mr-3" }),
                  createTextVNode(" " + toDisplayString(content.value.nav.logout), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div></div>`);
        } else {
          _push(`<!--[-->`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("login"),
            class: "btn-ghost"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(content.value.nav.login)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(content.value.nav.login), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          if (__props.canRegister) {
            _push(ssrRenderComponent(unref(Link), {
              href: _ctx.route("register"),
              class: "btn-primary"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`${ssrInterpolate(content.value.nav.register)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(content.value.nav.register), 1)
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`<!--]-->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></header><section class="pt-32 pb-32 px-6" data-v-4d977bbf><div class="max-w-5xl mx-auto" data-v-4d977bbf><div class="text-center space-y-12" data-v-4d977bbf><div class="space-y-8" data-v-4d977bbf><h1 class="text-6xl md:text-8xl font-light text-gray-900 dark:text-white leading-none tracking-tight" data-v-4d977bbf>${ssrInterpolate(content.value.hero.title)}</h1><p class="text-2xl font-light text-gray-500 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed" data-v-4d977bbf>${ssrInterpolate(content.value.hero.subtitle)}</p></div><div class="flex flex-col sm:flex-row gap-6 justify-center pt-8" data-v-4d977bbf>`);
      _push(ssrRenderComponent(unref(Link), {
        href: __props.canRegister ? _ctx.route("register") : _ctx.route("login"),
        class: "btn-hero"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(content.value.hero.cta)}`);
          } else {
            return [
              createTextVNode(toDisplayString(content.value.hero.cta), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button class="btn-outline" data-v-4d977bbf>Watch Demo</button></div></div></div></section><section class="py-24 bg-gray-50 dark:bg-gray-900" data-v-4d977bbf><div class="max-w-6xl mx-auto px-6" data-v-4d977bbf><div class="grid grid-cols-2 md:grid-cols-4 gap-12" data-v-4d977bbf><!--[-->`);
      ssrRenderList(metrics, (metric) => {
        _push(`<div class="metric-card" data-v-4d977bbf><div class="text-5xl font-light text-gray-900 dark:text-white mb-2" data-v-4d977bbf>${ssrInterpolate(metric.value)}</div><div class="text-lg font-light text-gray-500 dark:text-gray-400" data-v-4d977bbf>${ssrInterpolate(metric.label)}</div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="py-32" data-v-4d977bbf><div class="max-w-6xl mx-auto px-6" data-v-4d977bbf><div class="text-center mb-24" data-v-4d977bbf><h2 class="text-5xl font-light text-gray-900 dark:text-white mb-6 tracking-tight" data-v-4d977bbf>Why Choose Us</h2><p class="text-xl font-light text-gray-500 dark:text-gray-400 max-w-2xl mx-auto" data-v-4d977bbf>Everything you need to succeed in your learning journey</p></div><div class="grid md:grid-cols-2 lg:grid-cols-4 gap-12" data-v-4d977bbf><!--[-->`);
      ssrRenderList(features, (feature, index) => {
        _push(`<div class="feature-card" data-v-4d977bbf><div class="text-5xl mb-6" data-v-4d977bbf>${ssrInterpolate(feature.icon)}</div><h3 class="text-xl font-medium text-gray-900 dark:text-white mb-4 tracking-tight" data-v-4d977bbf>${ssrInterpolate(feature.title)}</h3><p class="text-gray-500 dark:text-gray-400 font-light leading-relaxed" data-v-4d977bbf>${ssrInterpolate(feature.desc)}</p></div>`);
      });
      _push(`<!--]--></div></div></section><section class="py-32 bg-gray-50 dark:bg-gray-900" data-v-4d977bbf><div class="max-w-6xl mx-auto px-6" data-v-4d977bbf><div class="text-center mb-24" data-v-4d977bbf><h2 class="text-5xl font-light text-gray-900 dark:text-white mb-6 tracking-tight" data-v-4d977bbf>Popular Categories</h2><p class="text-xl font-light text-gray-500 dark:text-gray-400 max-w-2xl mx-auto" data-v-4d977bbf>Explore our most in-demand courses</p></div><div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8" data-v-4d977bbf><!--[-->`);
      ssrRenderList(categories, (category) => {
        _push(`<div class="category-card" data-v-4d977bbf><div class="text-4xl mb-4" data-v-4d977bbf>${ssrInterpolate(category.icon)}</div><h3 class="font-medium text-gray-900 dark:text-white mb-2 tracking-tight" data-v-4d977bbf>${ssrInterpolate(category.name)}</h3><p class="text-sm font-light text-gray-500 dark:text-gray-400" data-v-4d977bbf>${ssrInterpolate(category.courses)} courses</p></div>`);
      });
      _push(`<!--]--></div></div></section><section class="py-32" data-v-4d977bbf><div class="max-w-5xl mx-auto px-6" data-v-4d977bbf><div class="text-center mb-24" data-v-4d977bbf><h2 class="text-5xl font-light text-gray-900 dark:text-white mb-6 tracking-tight" data-v-4d977bbf>Student Success</h2><p class="text-xl font-light text-gray-500 dark:text-gray-400 max-w-2xl mx-auto" data-v-4d977bbf>Real stories from our community</p></div><div class="relative" data-v-4d977bbf><div class="testimonial-slider" data-v-4d977bbf><!--[-->`);
      ssrRenderList(testimonials, (testimonial, index) => {
        _push(`<div class="${ssrRenderClass([{ "active": currentSlide.value === index }, "testimonial-slide"])}" data-v-4d977bbf><div class="testimonial-content" data-v-4d977bbf><blockquote class="text-2xl font-light text-gray-700 dark:text-gray-300 mb-8 leading-relaxed" data-v-4d977bbf> &quot;${ssrInterpolate(testimonial.quote)}&quot; </blockquote><div class="flex items-center justify-center space-x-6" data-v-4d977bbf><img${ssrRenderAttr("src", testimonial.avatar)}${ssrRenderAttr("alt", testimonial.name)} class="w-16 h-16 rounded-full" data-v-4d977bbf><div class="text-left" data-v-4d977bbf><div class="font-medium text-gray-900 dark:text-white text-lg" data-v-4d977bbf>${ssrInterpolate(testimonial.name)}</div><div class="font-light text-gray-500 dark:text-gray-400" data-v-4d977bbf>${ssrInterpolate(testimonial.role)} at ${ssrInterpolate(testimonial.company)}</div></div></div></div></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-center space-x-3 mt-12" data-v-4d977bbf><!--[-->`);
      ssrRenderList(testimonials, (_, index) => {
        _push(`<button class="${ssrRenderClass([{ "active": currentSlide.value === index }, "slide-indicator"])}" data-v-4d977bbf></button>`);
      });
      _push(`<!--]--></div></div></div></section><section class="py-32 bg-black dark:bg-gray-900" data-v-4d977bbf><div class="max-w-4xl mx-auto text-center px-6" data-v-4d977bbf><h2 class="text-5xl font-light text-white mb-8 tracking-tight" data-v-4d977bbf>Start Your Journey Today</h2><p class="text-xl font-light text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed" data-v-4d977bbf>Join thousands of learners who are already transforming their careers</p>`);
      _push(ssrRenderComponent(unref(Link), {
        href: __props.canRegister ? _ctx.route("register") : _ctx.route("login"),
        class: "btn-cta"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Get Started Free `);
          } else {
            return [
              createTextVNode(" Get Started Free ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
      _push(ssrRenderComponent(_sfc_main$4, null, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Index/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Welcome = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-4d977bbf"]]);
export {
  Welcome as default
};
