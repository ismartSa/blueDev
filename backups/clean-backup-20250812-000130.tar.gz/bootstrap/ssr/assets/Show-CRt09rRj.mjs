import { resolveComponent, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, openBlock, ref, useSSRContext } from "vue";
import { Link, useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import _sfc_main$2 from "./QuizImport-BtFezPi0.mjs";
import _sfc_main$1 from "./Edit-Z0m-k8rS.mjs";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./Footer-DT6KV5L9.mjs";
import "./Breadcrumb-BsPLZkqL.mjs";
import "./PrimaryButton-Be3Csrwm.mjs";
import "./InputLabel-CUhtyl2S.mjs";
import "./TextInput-BXI4L1ZJ.mjs";
import "./InputError-C7WpniWA.mjs";
import "./Modal-UKMpWsGi.mjs";
import "./SecondaryButton-DkF3Mn0U.mjs";
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$3,
    Link,
    QuizImport: _sfc_main$2,
    QuizEdit: _sfc_main$1
  },
  props: {
    quiz: Object
  },
  setup(props) {
    const form = useForm({});
    const showImportQuestions = ref(false);
    const showEditQuiz = ref(false);
    function startQuiz() {
      if (props.quiz.questions.length === 0) {
        alert("This quiz has no questions. Unable to start the quiz.");
        return;
      }
      form.post(route("quizzes.start", props.quiz.id));
    }
    function toggleImportQuestions() {
      showImportQuestions.value = !showImportQuestions.value;
    }
    function getQuestionTypeName(typeId) {
      const types = {
        1: "Multiple Choice",
        2: "True/False",
        3: "Short Answer"
        // Add more types as needed
      };
      return types[typeId] || "Unknown";
    }
    return {
      startQuiz,
      showImportQuestions,
      toggleImportQuestions,
      getQuestionTypeName,
      showEditQuiz
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  const _component_Link = resolveComponent("Link");
  const _component_QuizImport = resolveComponent("QuizImport");
  const _component_QuizEdit = resolveComponent("QuizEdit");
  _push(ssrRenderComponent(_component_AuthenticatedLayout, _attrs, {
    header: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>${ssrInterpolate($props.quiz.title)}</h2>`);
      } else {
        return [
          createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, toDisplayString($props.quiz.title), 1)
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Quiz Details</h3><p${_scopeId}><strong${_scopeId}>Description:</strong> ${ssrInterpolate($props.quiz.description)}</p><p${_scopeId}><strong${_scopeId}>Time Limit:</strong> ${ssrInterpolate($props.quiz.time_limit)} minutes</p><p${_scopeId}><strong${_scopeId}>Passing Score:</strong> ${ssrInterpolate($props.quiz.passing_score)}%</p><p${_scopeId}><strong${_scopeId}>Total Questions:</strong> ${ssrInterpolate($props.quiz.questions.length)}</p><div class="mt-6"${_scopeId}>`);
        _push2(ssrRenderComponent(_component_Link, {
          href: _ctx.route("quizzes.questions.list", $props.quiz.id),
          class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(` View Questions `);
            } else {
              return [
                createTextVNode(" View Questions ")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(ssrRenderComponent(_component_Link, {
          href: _ctx.route("quizzes.questions.create", $props.quiz.id),
          class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2"
        }, {
          default: withCtx((_2, _push3, _parent3, _scopeId2) => {
            if (_push3) {
              _push3(` Add New Question `);
            } else {
              return [
                createTextVNode(" Add New Question ")
              ];
            }
          }),
          _: 1
        }, _parent2, _scopeId));
        _push2(`<button class="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded"${_scopeId}>${ssrInterpolate($setup.showImportQuestions ? "Hide Import Options" : "Import Questions")}</button></div>`);
        if ($props.quiz.questions.length > 0) {
          _push2(`<button class="mt-4 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"${_scopeId}> Start Quiz </button>`);
        } else {
          _push2(`<p class="mt-4 text-red-600"${_scopeId}> This quiz has no questions yet. Please add questions or import them. </p>`);
        }
        if ($setup.showImportQuestions) {
          _push2(ssrRenderComponent(_component_QuizImport, {
            quizId: $props.quiz.id
          }, null, _parent2, _scopeId));
        } else {
          _push2(`<!---->`);
        }
        _push2(ssrRenderComponent(_component_QuizEdit, {
          show: $setup.showEditQuiz,
          onClose: ($event) => $setup.showEditQuiz = false,
          quiz: $props.quiz,
          title: $props.quiz.title,
          description: $props.quiz.description,
          time_limit: $props.quiz.time_limit,
          passing_score: $props.quiz.passing_score,
          course_id: $props.quiz.course_id,
          section_id: $props.quiz.section_id
        }, null, _parent2, _scopeId));
        _push2(`</div></div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-12" }, [
            createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                  createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Quiz Details"),
                  createVNode("p", null, [
                    createVNode("strong", null, "Description:"),
                    createTextVNode(" " + toDisplayString($props.quiz.description), 1)
                  ]),
                  createVNode("p", null, [
                    createVNode("strong", null, "Time Limit:"),
                    createTextVNode(" " + toDisplayString($props.quiz.time_limit) + " minutes", 1)
                  ]),
                  createVNode("p", null, [
                    createVNode("strong", null, "Passing Score:"),
                    createTextVNode(" " + toDisplayString($props.quiz.passing_score) + "%", 1)
                  ]),
                  createVNode("p", null, [
                    createVNode("strong", null, "Total Questions:"),
                    createTextVNode(" " + toDisplayString($props.quiz.questions.length), 1)
                  ]),
                  createVNode("div", { class: "mt-6" }, [
                    createVNode(_component_Link, {
                      href: _ctx.route("quizzes.questions.list", $props.quiz.id),
                      class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" View Questions ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_Link, {
                      href: _ctx.route("quizzes.questions.create", $props.quiz.id),
                      class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Add New Question ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode("button", {
                      onClick: $setup.toggleImportQuestions,
                      class: "bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded"
                    }, toDisplayString($setup.showImportQuestions ? "Hide Import Options" : "Import Questions"), 9, ["onClick"])
                  ]),
                  $props.quiz.questions.length > 0 ? (openBlock(), createBlock("button", {
                    key: 0,
                    onClick: $setup.startQuiz,
                    class: "mt-4 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
                  }, " Start Quiz ", 8, ["onClick"])) : (openBlock(), createBlock("p", {
                    key: 1,
                    class: "mt-4 text-red-600"
                  }, " This quiz has no questions yet. Please add questions or import them. ")),
                  $setup.showImportQuestions ? (openBlock(), createBlock(_component_QuizImport, {
                    key: 2,
                    quizId: $props.quiz.id
                  }, null, 8, ["quizId"])) : createCommentVNode("", true),
                  createVNode(_component_QuizEdit, {
                    show: $setup.showEditQuiz,
                    onClose: ($event) => $setup.showEditQuiz = false,
                    quiz: $props.quiz,
                    title: $props.quiz.title,
                    description: $props.quiz.description,
                    time_limit: $props.quiz.time_limit,
                    passing_score: $props.quiz.passing_score,
                    course_id: $props.quiz.course_id,
                    section_id: $props.quiz.section_id
                  }, null, 8, ["show", "onClose", "quiz", "title", "description", "time_limit", "passing_score", "course_id", "section_id"])
                ])
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Show = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Show as default
};
