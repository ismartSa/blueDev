import { reactive, computed, unref, withCtx, createTextVNode, toDisplayString, createVNode, createBlock, createCommentVNode, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$5 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$2 } from "./PrimaryButton-Be3Csrwm.mjs";
import _sfc_main$3 from "./Section-DwuYk5Us.mjs";
import _sfc_main$4 from "./Add-DgPZenCv.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
import "./Lecture-BH6Bpz_d.mjs";
import "./InputError-C7WpniWA.mjs";
import "./InputLabel-CUhtyl2S.mjs";
import "./Modal-UKMpWsGi.mjs";
import "./SecondaryButton-DkF3Mn0U.mjs";
import "./TextInput-BXI4L1ZJ.mjs";
const _sfc_main = {
  __name: "Learn",
  __ssrInlineRender: true,
  props: {
    title: String,
    course: Object,
    sections: Array,
    lectures: Array,
    breadcrumbs: Object,
    user: Object,
    enrolled: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const data = reactive({
      createOpen: false
    });
    const form = useForm({
      course_id: props.course.id,
      user_id: props.user.id
    });
    const enroll = () => {
      form.post(route("courses.enroll", { courseId: props.course.id }), {
        preserveScroll: true,
        onSuccess: () => {
          form.reset();
        },
        onError: (errors) => {
          console.error("Enrollment failed:", errors);
        }
      });
    };
    const sortedSections = computed(() => {
      return [...props.sections].sort((a, b) => a.order - b.order);
    });
    const filteredLectures = (sectionId) => {
      return props.lectures.filter((lecture) => lecture.section_id === sectionId);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Course Details" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$5, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$5, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6"${_scopeId}><div class="max-w-6xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="space-y-3"${_scopeId}><div class="px-4 sm:px-0"${_scopeId}><div class="rounded-lg overflow-hidden w-full max-w-md mx-auto"${_scopeId}><img${ssrRenderAttr("src", __props.course.image)} alt="Course Image" class="w-full h-48 object-cover"${_scopeId}></div></div><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}><div class="flex flex-col sm:flex-row sm:justify-between sm:items-center p-4 gap-3"${_scopeId}><h2 class="text-xl font-bold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(__props.course.title)}</h2><div class="flex flex-wrap items-center gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              onClick: enroll,
              disabled: unref(form).processing || __props.enrolled,
              class: [{ "opacity-25": unref(form).processing }, "text-sm px-4 py-2"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(__props.enrolled ? "Enrolled" : "Enroll Now")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(__props.enrolled ? "Enrolled" : "Enroll Now"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            if (_ctx.can(["create course"])) {
              _push2(ssrRenderComponent(_sfc_main$2, {
                onClick: ($event) => data.createOpen = true,
                class: "text-sm px-4 py-2"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Add Section `);
                  } else {
                    return [
                      createTextVNode(" Add Section ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("course.create.lecture", { courseId: __props.course.id }),
              class: "inline-flex items-center"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$2, { class: "text-sm px-4 py-2" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Add Lecture`);
                      } else {
                        return [
                          createTextVNode("Add Lecture")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$2, { class: "text-sm px-4 py-2" }, {
                      default: withCtx(() => [
                        createTextVNode("Add Lecture")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="p-4"${_scopeId}><p class="text-gray-600 dark:text-gray-300"${_scopeId}>${ssrInterpolate(__props.course.description)}</p><div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4"${_scopeId}><div${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2"${_scopeId}>Instructor</h3><p class="text-gray-600 dark:text-gray-300"${_scopeId}>${ssrInterpolate(__props.course.name)}</p></div>`);
            if (__props.course.prerequisites && __props.course.prerequisites.length) {
              _push2(`<div${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2"${_scopeId}>Prerequisites</h3><ul class="list-disc ml-4 text-gray-600 dark:text-gray-300 space-y-1"${_scopeId}><!--[-->`);
              ssrRenderList(__props.course.prerequisites, (prerequisite, index) => {
                _push2(`<li class="text-sm"${_scopeId}>${ssrInterpolate(prerequisite)}</li>`);
              });
              _push2(`<!--]--></ul></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            if (__props.course.learningOutcomes && __props.course.learningOutcomes.length) {
              _push2(`<div class="mt-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2"${_scopeId}>Learning Outcomes</h3><ul class="list-disc ml-4 text-gray-600 dark:text-gray-300 space-y-1"${_scopeId}><!--[-->`);
              ssrRenderList(__props.course.learningOutcomes, (outcome, index) => {
                _push2(`<li class="text-sm"${_scopeId}>${ssrInterpolate(outcome)}</li>`);
              });
              _push2(`<!--]--></ul></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="mt-6"${_scopeId}><!--[-->`);
            ssrRenderList(sortedSections.value, (section) => {
              _push2(`<div class="mb-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                section,
                lectures: filteredLectures(section.id)
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            });
            _push2(`<!--]--></div></div></div></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              show: data.createOpen,
              onClose: ($event) => data.createOpen = false,
              title: __props.title,
              courseId: __props.course.id
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "max-w-6xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "space-y-3" }, [
                    createVNode("div", { class: "px-4 sm:px-0" }, [
                      createVNode("div", { class: "rounded-lg overflow-hidden w-full max-w-md mx-auto" }, [
                        createVNode("img", {
                          src: __props.course.image,
                          alt: "Course Image",
                          class: "w-full h-48 object-cover"
                        }, null, 8, ["src"])
                      ])
                    ]),
                    createVNode("div", { class: "relative bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                      createVNode("div", { class: "flex flex-col sm:flex-row sm:justify-between sm:items-center p-4 gap-3" }, [
                        createVNode("h2", { class: "text-xl font-bold text-gray-900 dark:text-white" }, toDisplayString(__props.course.title), 1),
                        createVNode("div", { class: "flex flex-wrap items-center gap-2" }, [
                          createVNode(_sfc_main$2, {
                            onClick: enroll,
                            disabled: unref(form).processing || __props.enrolled,
                            class: [{ "opacity-25": unref(form).processing }, "text-sm px-4 py-2"]
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(__props.enrolled ? "Enrolled" : "Enroll Now"), 1)
                            ]),
                            _: 1
                          }, 8, ["disabled", "class"]),
                          _ctx.can(["create course"]) ? (openBlock(), createBlock(_sfc_main$2, {
                            key: 0,
                            onClick: ($event) => data.createOpen = true,
                            class: "text-sm px-4 py-2"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Add Section ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])) : createCommentVNode("", true),
                          createVNode(unref(Link), {
                            href: _ctx.route("course.create.lecture", { courseId: __props.course.id }),
                            class: "inline-flex items-center"
                          }, {
                            default: withCtx(() => [
                              createVNode(_sfc_main$2, { class: "text-sm px-4 py-2" }, {
                                default: withCtx(() => [
                                  createTextVNode("Add Lecture")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ])
                      ]),
                      createVNode("div", { class: "p-4" }, [
                        createVNode("p", { class: "text-gray-600 dark:text-gray-300" }, toDisplayString(__props.course.description), 1),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4" }, [
                          createVNode("div", null, [
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-2" }, "Instructor"),
                            createVNode("p", { class: "text-gray-600 dark:text-gray-300" }, toDisplayString(__props.course.name), 1)
                          ]),
                          __props.course.prerequisites && __props.course.prerequisites.length ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-2" }, "Prerequisites"),
                            createVNode("ul", { class: "list-disc ml-4 text-gray-600 dark:text-gray-300 space-y-1" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.course.prerequisites, (prerequisite, index) => {
                                return openBlock(), createBlock("li", {
                                  key: index,
                                  class: "text-sm"
                                }, toDisplayString(prerequisite), 1);
                              }), 128))
                            ])
                          ])) : createCommentVNode("", true)
                        ]),
                        __props.course.learningOutcomes && __props.course.learningOutcomes.length ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "mt-4"
                        }, [
                          createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-2" }, "Learning Outcomes"),
                          createVNode("ul", { class: "list-disc ml-4 text-gray-600 dark:text-gray-300 space-y-1" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.course.learningOutcomes, (outcome, index) => {
                              return openBlock(), createBlock("li", {
                                key: index,
                                class: "text-sm"
                              }, toDisplayString(outcome), 1);
                            }), 128))
                          ])
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "mt-6" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(sortedSections.value, (section) => {
                            return openBlock(), createBlock("div", {
                              key: section.id,
                              class: "mb-4"
                            }, [
                              createVNode(_sfc_main$3, {
                                section,
                                lectures: filteredLectures(section.id)
                              }, null, 8, ["section", "lectures"])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode(_sfc_main$4, {
                show: data.createOpen,
                onClose: ($event) => data.createOpen = false,
                title: __props.title,
                courseId: __props.course.id
              }, null, 8, ["show", "onClose", "title", "courseId"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Learn.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
