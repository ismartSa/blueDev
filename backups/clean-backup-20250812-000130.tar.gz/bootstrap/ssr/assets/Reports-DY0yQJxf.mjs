import { unref, withCtx, createVNode, resolveDynamicComponent, createBlock, openBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderVNode, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import { ChartBarIcon, ChartPieIcon, UserGroupIcon, AcademicCapIcon } from "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
const _sfc_main = {
  __name: "Reports",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    },
    stats: {
      type: Object,
      required: true
    },
    recentQuizzes: {
      type: Array,
      required: true
    },
    topPerformers: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const stats = [
      {
        name: "Total Quizzes",
        value: props.stats.totalQuizzes,
        icon: ChartBarIcon,
        color: "bg-blue-500"
      },
      {
        name: "Average Score",
        value: `${props.stats.averageScore}%`,
        icon: ChartPieIcon,
        color: "bg-green-500"
      },
      {
        name: "Total Participants",
        value: props.stats.totalParticipants,
        icon: UserGroupIcon,
        color: "bg-purple-500"
      },
      {
        name: "Pass Rate",
        value: `${props.stats.passRate}%`,
        icon: AcademicCapIcon,
        color: "bg-yellow-500"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: __props.title }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4"${_scopeId}><!--[-->`);
            ssrRenderList(stats, (stat) => {
              _push2(`<div class="bg-white dark:bg-slate-800 overflow-hidden shadow rounded-lg"${_scopeId}><div class="p-5"${_scopeId}><div class="flex items-center"${_scopeId}><div class="flex-shrink-0"${_scopeId}>`);
              ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(stat.icon), {
                class: "h-6 w-6 text-gray-400",
                "aria-hidden": "true"
              }, null), _parent2, _scopeId);
              _push2(`</div><div class="ml-5 w-0 flex-1"${_scopeId}><dl${_scopeId}><dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate"${_scopeId}>${ssrInterpolate(stat.name)}</dt><dd class="flex items-baseline"${_scopeId}><div class="text-2xl font-semibold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(stat.value)}</div></dd></dl></div></div></div></div>`);
            });
            _push2(`<!--]--></div><div class="mt-8"${_scopeId}><h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white"${_scopeId}> Recent Quizzes </h3><div class="mt-4 bg-white dark:bg-slate-800 shadow overflow-hidden sm:rounded-lg"${_scopeId}><ul role="list" class="divide-y divide-gray-200 dark:divide-slate-700"${_scopeId}><!--[-->`);
            ssrRenderList(__props.recentQuizzes, (quiz) => {
              _push2(`<li class="px-4 py-4 sm:px-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex items-center"${_scopeId}><p class="text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(quiz.title)}</p></div><div class="ml-2 flex-shrink-0 flex"${_scopeId}><p class="${ssrRenderClass([quiz.passed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800", "px-2 inline-flex text-xs leading-5 font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(quiz.score)}% </p></div></div></li>`);
            });
            _push2(`<!--]--></ul></div></div><div class="mt-8"${_scopeId}><h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white"${_scopeId}> Top Performers </h3><div class="mt-4 bg-white dark:bg-slate-800 shadow overflow-hidden sm:rounded-lg"${_scopeId}><ul role="list" class="divide-y divide-gray-200 dark:divide-slate-700"${_scopeId}><!--[-->`);
            ssrRenderList(__props.topPerformers, (performer) => {
              _push2(`<li class="px-4 py-4 sm:px-6"${_scopeId}><div class="flex items-center justify-between"${_scopeId}><div class="flex items-center"${_scopeId}><div class="flex-shrink-0"${_scopeId}><img class="h-8 w-8 rounded-full"${ssrRenderAttr("src", performer.avatar)}${ssrRenderAttr("alt", performer.name)}${_scopeId}></div><div class="ml-4"${_scopeId}><p class="text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(performer.name)}</p><p class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(performer.email)}</p></div></div><div class="ml-2 flex-shrink-0 flex"${_scopeId}><p class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800"${_scopeId}>${ssrInterpolate(performer.averageScore)}% </p></div></div></li>`);
            });
            _push2(`<!--]--></ul></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4" }, [
                    (openBlock(), createBlock(Fragment, null, renderList(stats, (stat) => {
                      return createVNode("div", {
                        key: stat.name,
                        class: "bg-white dark:bg-slate-800 overflow-hidden shadow rounded-lg"
                      }, [
                        createVNode("div", { class: "p-5" }, [
                          createVNode("div", { class: "flex items-center" }, [
                            createVNode("div", { class: "flex-shrink-0" }, [
                              (openBlock(), createBlock(resolveDynamicComponent(stat.icon), {
                                class: "h-6 w-6 text-gray-400",
                                "aria-hidden": "true"
                              }))
                            ]),
                            createVNode("div", { class: "ml-5 w-0 flex-1" }, [
                              createVNode("dl", null, [
                                createVNode("dt", { class: "text-sm font-medium text-gray-500 dark:text-gray-400 truncate" }, toDisplayString(stat.name), 1),
                                createVNode("dd", { class: "flex items-baseline" }, [
                                  createVNode("div", { class: "text-2xl font-semibold text-gray-900 dark:text-white" }, toDisplayString(stat.value), 1)
                                ])
                              ])
                            ])
                          ])
                        ])
                      ]);
                    }), 64))
                  ]),
                  createVNode("div", { class: "mt-8" }, [
                    createVNode("h3", { class: "text-lg leading-6 font-medium text-gray-900 dark:text-white" }, " Recent Quizzes "),
                    createVNode("div", { class: "mt-4 bg-white dark:bg-slate-800 shadow overflow-hidden sm:rounded-lg" }, [
                      createVNode("ul", {
                        role: "list",
                        class: "divide-y divide-gray-200 dark:divide-slate-700"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.recentQuizzes, (quiz) => {
                          return openBlock(), createBlock("li", {
                            key: quiz.id,
                            class: "px-4 py-4 sm:px-6"
                          }, [
                            createVNode("div", { class: "flex items-center justify-between" }, [
                              createVNode("div", { class: "flex items-center" }, [
                                createVNode("p", { class: "text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(quiz.title), 1)
                              ]),
                              createVNode("div", { class: "ml-2 flex-shrink-0 flex" }, [
                                createVNode("p", {
                                  class: ["px-2 inline-flex text-xs leading-5 font-semibold rounded-full", quiz.passed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"]
                                }, toDisplayString(quiz.score) + "% ", 3)
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "mt-8" }, [
                    createVNode("h3", { class: "text-lg leading-6 font-medium text-gray-900 dark:text-white" }, " Top Performers "),
                    createVNode("div", { class: "mt-4 bg-white dark:bg-slate-800 shadow overflow-hidden sm:rounded-lg" }, [
                      createVNode("ul", {
                        role: "list",
                        class: "divide-y divide-gray-200 dark:divide-slate-700"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.topPerformers, (performer) => {
                          return openBlock(), createBlock("li", {
                            key: performer.id,
                            class: "px-4 py-4 sm:px-6"
                          }, [
                            createVNode("div", { class: "flex items-center justify-between" }, [
                              createVNode("div", { class: "flex items-center" }, [
                                createVNode("div", { class: "flex-shrink-0" }, [
                                  createVNode("img", {
                                    class: "h-8 w-8 rounded-full",
                                    src: performer.avatar,
                                    alt: performer.name
                                  }, null, 8, ["src", "alt"])
                                ]),
                                createVNode("div", { class: "ml-4" }, [
                                  createVNode("p", { class: "text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(performer.name), 1),
                                  createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(performer.email), 1)
                                ])
                              ]),
                              createVNode("div", { class: "ml-2 flex-shrink-0 flex" }, [
                                createVNode("p", { class: "px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800" }, toDisplayString(performer.averageScore) + "% ", 1)
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Reports.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
