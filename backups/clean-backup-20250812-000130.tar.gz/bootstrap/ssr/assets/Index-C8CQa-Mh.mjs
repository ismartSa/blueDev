import { ref, withCtx, createTextVNode, unref, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, createBlock, createCommentVNode, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { useForm, router } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$9 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$2 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$4 } from "./SecondaryButton-DkF3Mn0U.mjs";
import { _ as _sfc_main$5 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$3 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$8 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$7 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$6 } from "./Pagination-BcteoMDy.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
import "lodash";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    // Simplified props definition
    categories: Object,
    filters: Object
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters.search || "");
    const showCreateModal = ref(false);
    const showEditModal = ref(false);
    const editingCategory = ref(null);
    const form = useForm({
      name: "",
      description: ""
    });
    const searchCategories = () => {
      router.get(route("admin.category.index"), { search: search.value }, {
        preserveState: true,
        replace: true
        // Avoids polluting browser history with search queries
      });
    };
    const editCategory = (category) => {
      editingCategory.value = category;
      form.name = category.name;
      form.description = category.description;
      showEditModal.value = true;
    };
    const deleteCategory = (category) => {
      if (confirm("Are you sure you want to delete this category? This action cannot be undone.")) {
        router.delete(route("admin.category.destroy", category.id), {
          preserveScroll: true,
          // Keep scroll position after delete
          onSuccess: () => {
          }
        });
      }
    };
    const submitForm = () => {
      if (editingCategory.value) {
        form.put(route("admin.category.update", editingCategory.value.id), {
          preserveScroll: true,
          onSuccess: () => closeModal()
        });
      } else {
        form.post(route("admin.category.store"), {
          preserveScroll: true,
          onSuccess: () => closeModal()
        });
      }
    };
    const closeModal = () => {
      showCreateModal.value = false;
      showEditModal.value = false;
      editingCategory.value = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$9, {
              title: "Categories",
              breadcrumbs: [{ name: "Dashboard", href: _ctx.route("dashboard") }]
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$9, {
                title: "Categories",
                breadcrumbs: [{ name: "Dashboard", href: _ctx.route("dashboard") }]
              }, null, 8, ["breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="py-8"${_scopeId}><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 shadow-sm rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900 dark:text-white"${_scopeId}>Categories</h1><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId}>Manage your course categories</p></div><div class="mt-4 sm:mt-0"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              onClick: ($event) => showCreateModal.value = true,
              class: "w-full sm:w-auto"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Add Category `);
                } else {
                  return [
                    createTextVNode(" Add Category ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="mb-8"${_scopeId}><div class="max-w-md"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              modelValue: search.value,
              "onUpdate:modelValue": ($event) => search.value = $event,
              placeholder: "Search categories...",
              onInput: searchCategories,
              class: "w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
            if (__props.categories.data && __props.categories.data.length > 0) {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"${_scopeId}><!--[-->`);
              ssrRenderList(__props.categories.data, (category) => {
                _push2(`<div class="bg-white dark:bg-slate-700 rounded-lg shadow-sm border border-gray-200 dark:border-slate-600 hover:shadow-md transition-all duration-200"${_scopeId}><div class="p-6"${_scopeId}><div class="flex items-start justify-between mb-4"${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(category.name)}</h3><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"${_scopeId}>${ssrInterpolate(category.courses_count)} courses </span></div><p class="text-gray-600 dark:text-gray-300 text-sm mb-6 min-h-[3rem]"${_scopeId}>${ssrInterpolate(category.description || "No description available.")}</p><div class="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-slate-600"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$4, {
                  onClick: ($event) => editCategory(category),
                  class: "text-sm px-4 py-2"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Edit `);
                    } else {
                      return [
                        createTextVNode(" Edit ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(_sfc_main$5, {
                  onClick: ($event) => deleteCategory(category),
                  class: "text-sm px-4 py-2"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Delete `);
                    } else {
                      return [
                        createTextVNode(" Delete ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div></div>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<div class="text-center py-12"${_scopeId}><div class="mx-auto w-24 h-24 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center mb-4"${_scopeId}><svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"${_scopeId}></path></svg></div><h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2"${_scopeId}>No categories found</h3><p class="text-gray-500 dark:text-gray-400 mb-4"${_scopeId}>${ssrInterpolate(search.value ? "Try adjusting your search terms." : "Get started by creating your first category.")}</p>`);
              if (!search.value) {
                _push2(ssrRenderComponent(_sfc_main$2, {
                  onClick: ($event) => showCreateModal.value = true
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` Create Category `);
                    } else {
                      return [
                        createTextVNode(" Create Category ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            }
            if (__props.categories.data && __props.categories.data.length > 0) {
              _push2(`<div class="mt-8"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$6, {
                links: ((_a = __props.categories) == null ? void 0 : _a.links) || { data: [], links: [] }
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$7, {
              show: showCreateModal.value || showEditModal.value,
              onClose: closeModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto"${_scopeId2}><h2 class="text-xl font-semibold mb-6 text-gray-700"${_scopeId2}>${ssrInterpolate(editingCategory.value ? "Edit" : "Create New")} Category</h2><form${_scopeId2}><div class="mb-5"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    for: "name",
                    value: "Category Name",
                    class: "mb-1"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    id: "name",
                    modelValue: unref(form).name,
                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                    required: "",
                    class: "w-full",
                    placeholder: "e.g., Programming"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="mb-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    for: "description",
                    value: "Description",
                    class: "mb-1"
                  }, null, _parent3, _scopeId2));
                  _push3(`<textarea id="description" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24" placeholder="A brief description of the category"${_scopeId2}>${ssrInterpolate(unref(form).description)}</textarea></div><div class="flex justify-end space-x-3 pt-4 border-t"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$4, { onClick: closeModal }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Cancel`);
                      } else {
                        return [
                          createTextVNode("Cancel")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    type: "submit",
                    disabled: unref(form).processing
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(editingCategory.value ? "Update Category" : "Create Category")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto" }, [
                      createVNode("h2", { class: "text-xl font-semibold mb-6 text-gray-700" }, toDisplayString(editingCategory.value ? "Edit" : "Create New") + " Category", 1),
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-5" }, [
                          createVNode(_sfc_main$8, {
                            for: "name",
                            value: "Category Name",
                            class: "mb-1"
                          }),
                          createVNode(_sfc_main$3, {
                            id: "name",
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            required: "",
                            class: "w-full",
                            placeholder: "e.g., Programming"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        createVNode("div", { class: "mb-6" }, [
                          createVNode(_sfc_main$8, {
                            for: "description",
                            value: "Description",
                            class: "mb-1"
                          }),
                          withDirectives(createVNode("textarea", {
                            id: "description",
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            class: "w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24",
                            placeholder: "A brief description of the category"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).description]
                          ])
                        ]),
                        createVNode("div", { class: "flex justify-end space-x-3 pt-4 border-t" }, [
                          createVNode(_sfc_main$4, { onClick: closeModal }, {
                            default: withCtx(() => [
                              createTextVNode("Cancel")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$2, {
                            type: "submit",
                            disabled: unref(form).processing
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "py-8" }, [
                createVNode("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 shadow-sm rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8" }, [
                        createVNode("div", null, [
                          createVNode("h1", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, "Categories"),
                          createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, "Manage your course categories")
                        ]),
                        createVNode("div", { class: "mt-4 sm:mt-0" }, [
                          createVNode(_sfc_main$2, {
                            onClick: ($event) => showCreateModal.value = true,
                            class: "w-full sm:w-auto"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Add Category ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ])
                      ]),
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("div", { class: "max-w-md" }, [
                          createVNode(_sfc_main$3, {
                            modelValue: search.value,
                            "onUpdate:modelValue": ($event) => search.value = $event,
                            placeholder: "Search categories...",
                            onInput: searchCategories,
                            class: "w-full"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ])
                      ]),
                      __props.categories.data && __props.categories.data.length > 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.categories.data, (category) => {
                          return openBlock(), createBlock("div", {
                            key: category.id,
                            class: "bg-white dark:bg-slate-700 rounded-lg shadow-sm border border-gray-200 dark:border-slate-600 hover:shadow-md transition-all duration-200"
                          }, [
                            createVNode("div", { class: "p-6" }, [
                              createVNode("div", { class: "flex items-start justify-between mb-4" }, [
                                createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, toDisplayString(category.name), 1),
                                createVNode("span", { class: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" }, toDisplayString(category.courses_count) + " courses ", 1)
                              ]),
                              createVNode("p", { class: "text-gray-600 dark:text-gray-300 text-sm mb-6 min-h-[3rem]" }, toDisplayString(category.description || "No description available."), 1),
                              createVNode("div", { class: "flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-slate-600" }, [
                                createVNode(_sfc_main$4, {
                                  onClick: ($event) => editCategory(category),
                                  class: "text-sm px-4 py-2"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Edit ")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"]),
                                createVNode(_sfc_main$5, {
                                  onClick: ($event) => deleteCategory(category),
                                  class: "text-sm px-4 py-2"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" Delete ")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ])
                            ])
                          ]);
                        }), 128))
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "text-center py-12"
                      }, [
                        createVNode("div", { class: "mx-auto w-24 h-24 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center mb-4" }, [
                          (openBlock(), createBlock("svg", {
                            class: "w-12 h-12 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24"
                          }, [
                            createVNode("path", {
                              "stroke-linecap": "round",
                              "stroke-linejoin": "round",
                              "stroke-width": "2",
                              d: "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                            })
                          ]))
                        ]),
                        createVNode("h3", { class: "text-lg font-medium text-gray-900 dark:text-white mb-2" }, "No categories found"),
                        createVNode("p", { class: "text-gray-500 dark:text-gray-400 mb-4" }, toDisplayString(search.value ? "Try adjusting your search terms." : "Get started by creating your first category."), 1),
                        !search.value ? (openBlock(), createBlock(_sfc_main$2, {
                          key: 0,
                          onClick: ($event) => showCreateModal.value = true
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Create Category ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])) : createCommentVNode("", true)
                      ])),
                      __props.categories.data && __props.categories.data.length > 0 ? (openBlock(), createBlock("div", {
                        key: 2,
                        class: "mt-8"
                      }, [
                        createVNode(_sfc_main$6, {
                          links: ((_b = __props.categories) == null ? void 0 : _b.links) || { data: [], links: [] }
                        }, null, 8, ["links"])
                      ])) : createCommentVNode("", true)
                    ])
                  ])
                ])
              ]),
              createVNode(_sfc_main$7, {
                show: showCreateModal.value || showEditModal.value,
                onClose: closeModal
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto" }, [
                    createVNode("h2", { class: "text-xl font-semibold mb-6 text-gray-700" }, toDisplayString(editingCategory.value ? "Edit" : "Create New") + " Category", 1),
                    createVNode("form", {
                      onSubmit: withModifiers(submitForm, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-5" }, [
                        createVNode(_sfc_main$8, {
                          for: "name",
                          value: "Category Name",
                          class: "mb-1"
                        }),
                        createVNode(_sfc_main$3, {
                          id: "name",
                          modelValue: unref(form).name,
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          required: "",
                          class: "w-full",
                          placeholder: "e.g., Programming"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode(_sfc_main$8, {
                          for: "description",
                          value: "Description",
                          class: "mb-1"
                        }),
                        withDirectives(createVNode("textarea", {
                          id: "description",
                          "onUpdate:modelValue": ($event) => unref(form).description = $event,
                          class: "w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24",
                          placeholder: "A brief description of the category"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).description]
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end space-x-3 pt-4 border-t" }, [
                        createVNode(_sfc_main$4, { onClick: closeModal }, {
                          default: withCtx(() => [
                            createTextVNode("Cancel")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$2, {
                          type: "submit",
                          disabled: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard/Category/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
