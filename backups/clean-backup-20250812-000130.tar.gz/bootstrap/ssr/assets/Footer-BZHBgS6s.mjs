import { computed, mergeProps, unref, createVNode, resolveDynamicComponent, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderVNode } from "vue/server-renderer";
import { usePage } from "@inertiajs/vue3";
import { AcademicCapIcon, CodeBracketIcon, MapPinIcon, PhoneIcon, EnvelopeIcon, HeartIcon } from "@heroicons/vue/24/outline";
const _sfc_main = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePage();
    const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    const appName = computed(() => page.props.app.name);
    const footerSections = {
      courses: [
        { name: "Web Development", href: "/explore?category=web" },
        { name: "Data Science", href: "/explore?category=data" },
        { name: "Digital Marketing", href: "/explore?category=marketing" },
        { name: "Design", href: "/explore?category=design" },
        { name: "Business", href: "/explore?category=business" }
      ],
      quickLinks: [
        { name: "About", href: "/about" },
        { name: "Instructors", href: "/instructors" },
        { name: "FAQ", href: "/faq" },
        { name: "Privacy Policy", href: "/privacy" },
        { name: "Terms of Service", href: "/terms" }
      ],
      contact: [
        { icon: MapPinIcon, text: "Riyadh, Saudi Arabia" },
        { icon: PhoneIcon, text: "+966 12 345 6789" },
        { icon: EnvelopeIcon, text: "info@brive.com" }
      ]
    };
    const socialLinks = [
      { name: "GitHub", href: "https://github.com/erikwibowo", icon: CodeBracketIcon },
      { name: "Website", href: "https://brive.erikwibowo.com", icon: AcademicCapIcon }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "bg-gray-900 dark:bg-black text-gray-400 py-16" }, _attrs))}><div class="max-w-7xl mx-auto px-6"><div class="grid grid-cols-1 md:grid-cols-4 gap-12"><div class="space-y-6"><div class="flex items-center space-x-3"><div class="p-2 bg-blue-600 rounded-full">`);
      _push(ssrRenderComponent(unref(AcademicCapIcon), { class: "h-6 w-6 text-white" }, null, _parent));
      _push(`</div><h3 class="text-white text-2xl font-bold tracking-tight">${ssrInterpolate(appName.value)}</h3></div><p class="text-gray-400 leading-relaxed max-w-xs"> Empowering learners worldwide with quality online education and professional development courses. </p><div class="flex space-x-4"><!--[-->`);
      ssrRenderList(socialLinks, (social) => {
        _push(`<a${ssrRenderAttr("href", social.href)} target="_blank" rel="noopener noreferrer" class="p-3 rounded-lg bg-gray-800 hover:bg-blue-600 text-gray-400 hover:text-white transition-all duration-300 group"${ssrRenderAttr("title", social.name)}>`);
        ssrRenderVNode(_push, createVNode(resolveDynamicComponent(social.icon), { class: "h-5 w-5" }, null), _parent);
        _push(`</a>`);
      });
      _push(`<!--]--></div></div><div class="space-y-6"><h4 class="text-white text-lg font-semibold uppercase tracking-wider">Popular Courses</h4><ul class="space-y-3"><!--[-->`);
      ssrRenderList(footerSections.courses, (course) => {
        _push(`<li><a${ssrRenderAttr("href", course.href)} class="text-gray-400 hover:text-white hover:translate-x-1 transition-all duration-200 block">${ssrInterpolate(course.name)}</a></li>`);
      });
      _push(`<!--]--></ul></div><div class="space-y-6"><h4 class="text-white text-lg font-semibold uppercase tracking-wider">Quick Links</h4><ul class="space-y-3"><!--[-->`);
      ssrRenderList(footerSections.quickLinks, (link) => {
        _push(`<li><a${ssrRenderAttr("href", link.href)} class="text-gray-400 hover:text-white hover:translate-x-1 transition-all duration-200 block">${ssrInterpolate(link.name)}</a></li>`);
      });
      _push(`<!--]--></ul></div><div class="space-y-6"><h4 class="text-white text-lg font-semibold uppercase tracking-wider">Contact Info</h4><ul class="space-y-4"><!--[-->`);
      ssrRenderList(footerSections.contact, (contact) => {
        _push(`<li class="flex items-center space-x-3">`);
        ssrRenderVNode(_push, createVNode(resolveDynamicComponent(contact.icon), { class: "h-5 w-5 text-blue-400 flex-shrink-0" }, null), _parent);
        _push(`<span class="text-gray-400">${ssrInterpolate(contact.text)}</span></li>`);
      });
      _push(`<!--]--></ul></div></div></div><div class="border-t border-gray-800 mt-16 pt-8"><div class="max-w-7xl mx-auto px-6"><div class="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0"><div class="text-gray-400 text-sm"> © ${ssrInterpolate(unref(currentYear))} ${ssrInterpolate(appName.value)}. All rights reserved. </div><div class="flex items-center space-x-2 text-sm text-gray-400"><span>Made with</span>`);
      _push(ssrRenderComponent(unref(HeartIcon), { class: "h-4 w-4 text-red-500 animate-pulse" }, null, _parent));
      _push(`<span>by</span><a href="https://github.com/erikwibowo" target="_blank" rel="noopener noreferrer" class="font-medium text-blue-400 hover:text-blue-300 transition-colors duration-200"> Erik Wibowo </a></div></div></div></div></footer>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Index/Partials/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
