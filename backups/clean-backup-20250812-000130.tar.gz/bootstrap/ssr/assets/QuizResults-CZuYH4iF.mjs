import { unref, withCtx, createVNode, toDisplayString, createBlock, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-BxXS-MwJ.mjs";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-hXFGqixW.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./Footer-DT6KV5L9.mjs";
const _sfc_main = {
  __name: "QuizResults",
  __ssrInlineRender: true,
  props: {
    quiz: {
      type: Object,
      required: true
    },
    result: {
      type: Object,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Quiz Results - ${__props.quiz.title}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: `Quiz Results - ${__props.quiz.title}`,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: `Quiz Results - ${__props.quiz.title}`,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="mb-8"${_scopeId}><h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-4"${_scopeId}>Results Summary</h3><div class="grid grid-cols-1 md:grid-cols-3 gap-4"${_scopeId}><div class="bg-blue-50 dark:bg-blue-900/50 p-4 rounded-lg"${_scopeId}><p class="text-sm text-blue-800 dark:text-blue-200"${_scopeId}>Score</p><p class="text-3xl font-bold text-blue-600 dark:text-blue-400"${_scopeId}>${ssrInterpolate(__props.result.score)}%</p></div><div class="bg-green-50 dark:bg-green-900/50 p-4 rounded-lg"${_scopeId}><p class="text-sm text-green-800 dark:text-green-200"${_scopeId}>Correct Answers</p><p class="text-3xl font-bold text-green-600 dark:text-green-400"${_scopeId}>${ssrInterpolate(__props.result.correct_answers)}/${ssrInterpolate(__props.result.total_questions)}</p></div><div class="bg-purple-50 dark:bg-purple-900/50 p-4 rounded-lg"${_scopeId}><p class="text-sm text-purple-800 dark:text-purple-200"${_scopeId}>Time Taken</p><p class="text-3xl font-bold text-purple-600 dark:text-purple-400"${_scopeId}>${ssrInterpolate(__props.result.time_taken)} minutes </p></div></div></div><div${_scopeId}><h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4"${_scopeId}>Answer Details</h3><!--[-->`);
            ssrRenderList(__props.result.questions, (question, index) => {
              _push2(`<div class="mb-6 border-b dark:border-slate-700 pb-4 last:border-0"${_scopeId}><p class="font-medium text-gray-900 dark:text-white mb-2"${_scopeId}>${ssrInterpolate(index + 1)}. ${ssrInterpolate(question.text)}</p><!--[-->`);
              ssrRenderList(question.answers, (answer) => {
                _push2(`<div class="ml-4"${_scopeId}><div class="${ssrRenderClass([{
                  "text-green-600 dark:text-green-400": answer.is_correct,
                  "text-red-600 dark:text-red-400": answer.is_selected && !answer.is_correct
                }, "flex items-center"])}"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(answer.is_selected) ? " checked" : ""} class="mr-2 rounded border-gray-300 dark:border-slate-600 text-blue-600 dark:text-blue-500 focus:ring-blue-500 dark:focus:ring-blue-600" disabled${_scopeId}><span${_scopeId}>${ssrInterpolate(answer.text)}</span></div></div>`);
              });
              _push2(`<!--]--></div>`);
            });
            _push2(`<!--]--></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h3", { class: "text-2xl font-bold text-gray-900 dark:text-white mb-4" }, "Results Summary"),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-4" }, [
                          createVNode("div", { class: "bg-blue-50 dark:bg-blue-900/50 p-4 rounded-lg" }, [
                            createVNode("p", { class: "text-sm text-blue-800 dark:text-blue-200" }, "Score"),
                            createVNode("p", { class: "text-3xl font-bold text-blue-600 dark:text-blue-400" }, toDisplayString(__props.result.score) + "%", 1)
                          ]),
                          createVNode("div", { class: "bg-green-50 dark:bg-green-900/50 p-4 rounded-lg" }, [
                            createVNode("p", { class: "text-sm text-green-800 dark:text-green-200" }, "Correct Answers"),
                            createVNode("p", { class: "text-3xl font-bold text-green-600 dark:text-green-400" }, toDisplayString(__props.result.correct_answers) + "/" + toDisplayString(__props.result.total_questions), 1)
                          ]),
                          createVNode("div", { class: "bg-purple-50 dark:bg-purple-900/50 p-4 rounded-lg" }, [
                            createVNode("p", { class: "text-sm text-purple-800 dark:text-purple-200" }, "Time Taken"),
                            createVNode("p", { class: "text-3xl font-bold text-purple-600 dark:text-purple-400" }, toDisplayString(__props.result.time_taken) + " minutes ", 1)
                          ])
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("h3", { class: "text-xl font-bold text-gray-900 dark:text-white mb-4" }, "Answer Details"),
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.result.questions, (question, index) => {
                          return openBlock(), createBlock("div", {
                            key: index,
                            class: "mb-6 border-b dark:border-slate-700 pb-4 last:border-0"
                          }, [
                            createVNode("p", { class: "font-medium text-gray-900 dark:text-white mb-2" }, toDisplayString(index + 1) + ". " + toDisplayString(question.text), 1),
                            (openBlock(true), createBlock(Fragment, null, renderList(question.answers, (answer) => {
                              return openBlock(), createBlock("div", {
                                key: answer.id,
                                class: "ml-4"
                              }, [
                                createVNode("div", {
                                  class: ["flex items-center", {
                                    "text-green-600 dark:text-green-400": answer.is_correct,
                                    "text-red-600 dark:text-red-400": answer.is_selected && !answer.is_correct
                                  }]
                                }, [
                                  createVNode("input", {
                                    type: "checkbox",
                                    checked: answer.is_selected,
                                    class: "mr-2 rounded border-gray-300 dark:border-slate-600 text-blue-600 dark:text-blue-500 focus:ring-blue-500 dark:focus:ring-blue-600",
                                    disabled: ""
                                  }, null, 8, ["checked"]),
                                  createVNode("span", null, toDisplayString(answer.text), 1)
                                ], 2)
                              ]);
                            }), 128))
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Course/QuizResults.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
