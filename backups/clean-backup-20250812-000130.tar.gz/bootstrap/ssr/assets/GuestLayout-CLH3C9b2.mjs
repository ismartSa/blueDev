import { mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from "vue/server-renderer";
import { a as _sfc_main$1, _ as _sfc_main$2 } from "./SwitchLangNavbar-hXFGqixW.mjs";
import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./SwitchDarkMode-qMtWjm8v.mjs";
import { _ as _sfc_main$4 } from "./Footer-DT6KV5L9.mjs";
const _sfc_main = {
  __name: "GuestLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-h-screen flex flex-col bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-300" }, _attrs))}><div class="flex-1 flex flex-col-2 sm:justify-center items-center pt-6 sm:pt-0"><div class="w-full sm:max-w-md lg:max-w-4xl my-4 bg-white dark:bg-slate-800 shadow-md overflow-hidden sm:rounded-lg"><div class="grid grid-cols-1 lg:grid-cols-2"><div class="space-y-6 px-6 py-4 lg:py-16"><div class="flex justify-between items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        class: "flex items-center",
        href: "/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$1, { class: "w-8 h-8 fill-current" }, null, _parent2, _scopeId));
            _push2(`<p class="text-lg ml-2"${_scopeId}>${ssrInterpolate(_ctx.$page.props.app.name)}</p>`);
          } else {
            return [
              createVNode(_sfc_main$1, { class: "w-8 h-8 fill-current" }),
              createVNode("p", { class: "text-lg ml-2" }, toDisplayString(_ctx.$page.props.app.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex space-x-2 items-center">`);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      _push(`</div></div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div><div class="hidden lg:flex lg:flex-col px-6 py-4 justify-center items-center space-y-2 bg-primary text-white">`);
      ssrRenderSlot(_ctx.$slots, "illustration", {}, null, _push, _parent);
      _push(`</div></div></div></div>`);
      _push(ssrRenderComponent(_sfc_main$4, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/GuestLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
