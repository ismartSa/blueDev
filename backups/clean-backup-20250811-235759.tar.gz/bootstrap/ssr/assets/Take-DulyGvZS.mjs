import { ref, onMounted, onUnmounted, unref, withCtx, createTextVNode, createVNode, createBlock, createCommentVNode, toDisplayString, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$3 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$2 } from "./PrimaryButton-Be3Csrwm.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
};
const calculateRemainingTime = (timeLimit, elapsedTime) => {
  const totalSeconds = timeLimit * 60;
  return Math.max(0, totalSeconds - elapsedTime);
};
const _sfc_main = {
  __name: "Take",
  __ssrInlineRender: true,
  props: {
    quiz: {
      type: Object,
      required: true
    },
    course: {
      type: Object,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      answers: []
    });
    const currentQuestionIndex = ref(0);
    const timeRemaining = ref(calculateRemainingTime(props.quiz.time_limit, 0));
    const timer = ref(null);
    const isSubmitting = ref(false);
    const currentQuestion = computed(() => props.quiz.questions[currentQuestionIndex.value]);
    const progress = computed(() => {
      return Math.round(currentQuestionIndex.value / props.quiz.questions.length * 100);
    });
    const startTimer = () => {
      timer.value = setInterval(() => {
        timeRemaining.value = Math.max(0, timeRemaining.value - 1);
        if (timeRemaining.value === 0) {
          submitQuiz();
        }
      }, 1e3);
    };
    const stopTimer = () => {
      if (timer.value) {
        clearInterval(timer.value);
      }
    };
    const selectAnswer = (answerId) => {
      const questionId = currentQuestion.value.id;
      const existingAnswerIndex = form.answers.findIndex((a) => a.question_id === questionId);
      if (existingAnswerIndex !== -1) {
        form.answers[existingAnswerIndex].answer_id = answerId;
      } else {
        form.answers.push({
          question_id: questionId,
          answer_id: answerId
        });
      }
    };
    const nextQuestion = () => {
      if (currentQuestionIndex.value < props.quiz.questions.length - 1) {
        currentQuestionIndex.value++;
      }
    };
    const previousQuestion = () => {
      if (currentQuestionIndex.value > 0) {
        currentQuestionIndex.value--;
      }
    };
    const submitQuiz = () => {
      if (isSubmitting.value) return;
      isSubmitting.value = true;
      stopTimer();
      form.post(route("quizzes.submit", {
        quizId: props.quiz.id,
        courseId: props.course.id
      }));
    };
    onMounted(() => {
      startTimer();
    });
    onUnmounted(() => {
      stopTimer();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Take Quiz - ${__props.quiz.title}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$3, {
              title: `Take Quiz - ${__props.quiz.title}`,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$3, {
                title: `Take Quiz - ${__props.quiz.title}`,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="mb-8"${_scopeId}><div class="flex justify-between items-center mb-4"${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(__props.quiz.title)}</h2><div class="text-lg font-medium text-gray-900 dark:text-white"${_scopeId}> Time Remaining: ${ssrInterpolate(unref(formatTime)(timeRemaining.value))}</div></div><div class="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2.5"${_scopeId}><div class="bg-indigo-600 h-2.5 rounded-full" style="${ssrRenderStyle({ width: `${unref(progress)}%` })}"${_scopeId}></div></div></div>`);
            if (unref(currentQuestion)) {
              _push2(`<div class="mb-8"${_scopeId}><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}> Question ${ssrInterpolate(currentQuestionIndex.value + 1)} of ${ssrInterpolate(__props.quiz.questions.length)}</h3><p class="text-gray-700 dark:text-gray-300 mb-6"${_scopeId}>${ssrInterpolate(unref(currentQuestion).text)}</p><div class="space-y-4"${_scopeId}><!--[-->`);
              ssrRenderList(unref(currentQuestion).answers, (answer) => {
                _push2(`<div class="${ssrRenderClass([{
                  "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/50": unref(form).answers.find((a) => a.question_id === unref(currentQuestion).id && a.answer_id === answer.id),
                  "border-gray-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500": !unref(form).answers.find((a) => a.question_id === unref(currentQuestion).id && a.answer_id === answer.id)
                }, "flex items-center p-4 border rounded-lg cursor-pointer transition-colors"])}"${_scopeId}><div class="flex-1"${_scopeId}><p class="text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(answer.text)}</p></div></div>`);
              });
              _push2(`<!--]--></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between"${_scopeId}>`);
            if (currentQuestionIndex.value > 0) {
              _push2(ssrRenderComponent(_sfc_main$2, {
                onClick: previousQuestion,
                class: "bg-gray-600 hover:bg-gray-700"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Previous Question `);
                  } else {
                    return [
                      createTextVNode(" Previous Question ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<div class="w-32"${_scopeId}></div>`);
            }
            if (currentQuestionIndex.value < __props.quiz.questions.length - 1) {
              _push2(ssrRenderComponent(_sfc_main$2, { onClick: nextQuestion }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Next Question `);
                  } else {
                    return [
                      createTextVNode(" Next Question ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(ssrRenderComponent(_sfc_main$2, {
                onClick: submitQuiz,
                disabled: isSubmitting.value,
                class: { "opacity-50": isSubmitting.value }
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Submit Quiz `);
                  } else {
                    return [
                      createTextVNode(" Submit Quiz ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            }
            _push2(`</div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("div", { class: "flex justify-between items-center mb-4" }, [
                          createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, toDisplayString(__props.quiz.title), 1),
                          createVNode("div", { class: "text-lg font-medium text-gray-900 dark:text-white" }, " Time Remaining: " + toDisplayString(unref(formatTime)(timeRemaining.value)), 1)
                        ]),
                        createVNode("div", { class: "w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2.5" }, [
                          createVNode("div", {
                            class: "bg-indigo-600 h-2.5 rounded-full",
                            style: { width: `${unref(progress)}%` }
                          }, null, 4)
                        ])
                      ]),
                      unref(currentQuestion) ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "mb-8"
                      }, [
                        createVNode("h3", { class: "text-xl font-semibold text-gray-900 dark:text-white mb-4" }, " Question " + toDisplayString(currentQuestionIndex.value + 1) + " of " + toDisplayString(__props.quiz.questions.length), 1),
                        createVNode("p", { class: "text-gray-700 dark:text-gray-300 mb-6" }, toDisplayString(unref(currentQuestion).text), 1),
                        createVNode("div", { class: "space-y-4" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(currentQuestion).answers, (answer) => {
                            return openBlock(), createBlock("div", {
                              key: answer.id,
                              class: ["flex items-center p-4 border rounded-lg cursor-pointer transition-colors", {
                                "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/50": unref(form).answers.find((a) => a.question_id === unref(currentQuestion).id && a.answer_id === answer.id),
                                "border-gray-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500": !unref(form).answers.find((a) => a.question_id === unref(currentQuestion).id && a.answer_id === answer.id)
                              }],
                              onClick: ($event) => selectAnswer(answer.id)
                            }, [
                              createVNode("div", { class: "flex-1" }, [
                                createVNode("p", { class: "text-gray-900 dark:text-white" }, toDisplayString(answer.text), 1)
                              ])
                            ], 10, ["onClick"]);
                          }), 128))
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "flex justify-between" }, [
                        currentQuestionIndex.value > 0 ? (openBlock(), createBlock(_sfc_main$2, {
                          key: 0,
                          onClick: previousQuestion,
                          class: "bg-gray-600 hover:bg-gray-700"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Previous Question ")
                          ]),
                          _: 1
                        })) : (openBlock(), createBlock("div", {
                          key: 1,
                          class: "w-32"
                        })),
                        currentQuestionIndex.value < __props.quiz.questions.length - 1 ? (openBlock(), createBlock(_sfc_main$2, {
                          key: 2,
                          onClick: nextQuestion
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Next Question ")
                          ]),
                          _: 1
                        })) : (openBlock(), createBlock(_sfc_main$2, {
                          key: 3,
                          onClick: submitQuiz,
                          disabled: isSubmitting.value,
                          class: { "opacity-50": isSubmitting.value }
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Submit Quiz ")
                          ]),
                          _: 1
                        }, 8, ["disabled", "class"]))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Take.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
