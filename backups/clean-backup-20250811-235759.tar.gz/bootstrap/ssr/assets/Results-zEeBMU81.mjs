import { unref, withCtx, createVNode, toDisplayString, createBlock, openBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Results",
  __ssrInlineRender: true,
  props: {
    quiz: {
      type: Object,
      required: true
    },
    attempt: {
      type: Object,
      required: true
    },
    score: {
      type: Number,
      required: true
    },
    totalQuestions: {
      type: Number,
      required: true
    },
    passed: {
      type: Boolean,
      required: true
    },
    answers: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Quiz Results - ${__props.quiz.title}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: `Quiz Results - ${__props.quiz.title}`,
              breadcrumbs: [
                { label: "Dashboard", href: _ctx.route("dashboard") },
                { label: "Quizzes", href: _ctx.route("quizzes.index") },
                { label: __props.quiz.title, href: _ctx.route("quizzes.show", __props.quiz.id) },
                { label: "Results", href: "#" }
              ]
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: `Quiz Results - ${__props.quiz.title}`,
                breadcrumbs: [
                  { label: "Dashboard", href: _ctx.route("dashboard") },
                  { label: "Quizzes", href: _ctx.route("quizzes.index") },
                  { label: __props.quiz.title, href: _ctx.route("quizzes.show", __props.quiz.id) },
                  { label: "Results", href: "#" }
                ]
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="text-center mb-8"${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-4"${_scopeId}> Quiz Results </h2><div class="${ssrRenderClass([__props.passed ? "text-green-600" : "text-red-600", "text-4xl font-bold"])}"${_scopeId}>${ssrInterpolate(__props.score)}% </div><p class="mt-2 text-gray-600 dark:text-gray-300"${_scopeId}>${ssrInterpolate(__props.passed ? "Congratulations! You passed the quiz." : "You need to retake the quiz.")}</p></div><div class="space-y-6"${_scopeId}><!--[-->`);
            ssrRenderList(__props.answers, (answer, index) => {
              _push2(`<div class="border-b dark:border-slate-700 pb-4 last:border-0"${_scopeId}><div class="flex items-start"${_scopeId}><div class="flex-shrink-0"${_scopeId}><div class="${ssrRenderClass([answer.correct ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600", "w-6 h-6 rounded-full flex items-center justify-center"])}"${_scopeId}>${ssrInterpolate(index + 1)}</div></div><div class="ml-4"${_scopeId}><p class="text-gray-900 dark:text-white font-medium"${_scopeId}>${ssrInterpolate(answer.question)}</p><p class="mt-1 text-sm text-gray-600 dark:text-gray-300"${_scopeId}> Your answer: ${ssrInterpolate(answer.user_answer)}</p>`);
              if (!answer.correct) {
                _push2(`<p class="mt-1 text-sm text-green-600"${_scopeId}> Correct answer: ${ssrInterpolate(answer.correct_answer)}</p>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></div>`);
            });
            _push2(`<!--]--></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "text-center mb-8" }, [
                        createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-white mb-4" }, " Quiz Results "),
                        createVNode("div", {
                          class: ["text-4xl font-bold", __props.passed ? "text-green-600" : "text-red-600"]
                        }, toDisplayString(__props.score) + "% ", 3),
                        createVNode("p", { class: "mt-2 text-gray-600 dark:text-gray-300" }, toDisplayString(__props.passed ? "Congratulations! You passed the quiz." : "You need to retake the quiz."), 1)
                      ]),
                      createVNode("div", { class: "space-y-6" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.answers, (answer, index) => {
                          return openBlock(), createBlock("div", {
                            key: index,
                            class: "border-b dark:border-slate-700 pb-4 last:border-0"
                          }, [
                            createVNode("div", { class: "flex items-start" }, [
                              createVNode("div", { class: "flex-shrink-0" }, [
                                createVNode("div", {
                                  class: ["w-6 h-6 rounded-full flex items-center justify-center", answer.correct ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"]
                                }, toDisplayString(index + 1), 3)
                              ]),
                              createVNode("div", { class: "ml-4" }, [
                                createVNode("p", { class: "text-gray-900 dark:text-white font-medium" }, toDisplayString(answer.question), 1),
                                createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-300" }, " Your answer: " + toDisplayString(answer.user_answer), 1),
                                !answer.correct ? (openBlock(), createBlock("p", {
                                  key: 0,
                                  class: "mt-1 text-sm text-green-600"
                                }, " Correct answer: " + toDisplayString(answer.correct_answer), 1)) : createCommentVNode("", true)
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Results.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
