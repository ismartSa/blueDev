import { reactive, ref, computed, watch, nextTick, unref, withCtx, createTextVNode, createVNode, toDisplayString, resolveDynamicComponent, createBlock, createCommentVNode, openBlock, withModifiers, Transition, withDirectives, vShow, Fragment, renderList, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderVNode, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { useForm, router, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$6 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$3 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$5 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$2 } from "./SecondaryButton-DkF3Mn0U.mjs";
import { _ as _sfc_main$4 } from "./SelectInput-BcLpPrB1.mjs";
import { _ as _sfc_main$7 } from "./Checkbox-C7w3fFTm.mjs";
import { _ as _sfc_main$8 } from "./Pagination-BcteoMDy.mjs";
import { _ as _sfc_main$9 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$a } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$b } from "./InputError-C7WpniWA.mjs";
import { _ as _sfc_main$c } from "./TextArea-D6-Dt9po.mjs";
import pkg from "lodash";
import { CheckCircleIcon, PlusIcon, TrashIcon, MagnifyingGlassIcon, ExclamationTriangleIcon, ArrowUpIcon, ArrowDownIcon, EyeIcon, PencilIcon } from "@heroicons/vue/24/solid";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const DEBOUNCE_DELAY = 300;
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: { type: String, required: true },
    filters: { type: Object, default: () => ({}) },
    courses: { type: Object, required: true },
    categories: { type: Array, default: () => [] },
    breadcrumbs: { type: Array, default: () => [] },
    perPage: { type: Number, default: 10 },
    stats: { type: Object, default: () => ({}) }
  },
  setup(__props) {
    const { debounce, pickBy } = pkg;
    const PER_PAGE_OPTIONS = [
      { value: 10, label: "10 per page" },
      { value: 25, label: "25 per page" },
      { value: 50, label: "50 per page" },
      { value: 100, label: "100 per page" }
    ];
    const STATUS_OPTIONS = [
      { value: "active", label: "Active" },
      { value: "inactive", label: "Inactive" },
      { value: "draft", label: "Draft" }
    ];
    const props = __props;
    const data = reactive({
      params: {
        search: props.filters.search || "",
        field: props.filters.field || "created_at",
        order: props.filters.order || "desc",
        perPage: props.perPage
      },
      selectedIds: [],
      loading: false,
      error: null,
      // Modal states
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      // UI state
      processing: false,
      showSuccess: false,
      successMessage: "",
      courseToDelete: null
    });
    const createForm = useForm({
      title: "",
      category_id: null,
      status: "active",
      description: ""
    });
    const editForm = useForm({
      title: "",
      category_id: null,
      status: "active",
      description: ""
    });
    const deleteForm = useForm({});
    const bulkDeleteForm = useForm({
      ids: []
    });
    const createTitleInput = ref(null);
    const editTitleInput = ref(null);
    const isAllSelected = computed(
      () => {
        var _a, _b;
        return ((_b = (_a = props.courses) == null ? void 0 : _a.data) == null ? void 0 : _b.length) > 0 && data.selectedIds.length === props.courses.data.length;
      }
    );
    const isIndeterminate = computed(
      () => data.selectedIds.length > 0 && data.selectedIds.length < props.courses.data.length
    );
    const hasSelectedItems = computed(() => data.selectedIds.length > 0);
    const sortableColumns = computed(() => [
      { key: "title", label: "Course Title", sortable: true },
      { key: "status", label: "Status", sortable: true },
      { key: "created_at", label: "Created At", sortable: true },
      { key: "updated_at", label: "Updated At", sortable: true }
    ]);
    const categoriesForSelect = computed(() => [
      { value: null, label: "Select Category" },
      ...props.categories.map((cat) => ({ value: cat.id, label: cat.name }))
    ]);
    const filteredCoursesCount = computed(() => {
      var _a;
      return ((_a = props.courses) == null ? void 0 : _a.total) || 0;
    });
    const currentPageRange = computed(() => {
      var _a, _b;
      if (!((_b = (_a = props.courses) == null ? void 0 : _a.data) == null ? void 0 : _b.length)) return "";
      const from = (props.courses.current_page - 1) * props.courses.per_page + 1;
      const to = Math.min(from + props.courses.data.length - 1, props.courses.total);
      return `${from}-${to} of ${props.courses.total}`;
    });
    const performSearch = debounce(() => {
      data.loading = true;
      data.error = null;
      const params = pickBy(data.params, (value) => value !== "" && value !== null);
      router.get(route("courses.index"), params, {
        replace: true,
        preserveState: true,
        preserveScroll: true,
        onFinish: () => {
          data.loading = false;
        },
        onError: (errors) => {
          data.error = "Failed to load courses. Please try again.";
          data.loading = false;
          console.error("Loading error:", errors);
        }
      });
    }, DEBOUNCE_DELAY);
    const sortBy = (field) => {
      if (data.params.field === field) {
        data.params.order = data.params.order === "asc" ? "desc" : "asc";
      } else {
        data.params.field = field;
        data.params.order = "asc";
      }
    };
    const selectAll = (event) => {
      var _a, _b;
      data.selectedIds = event.target.checked ? ((_b = (_a = props.courses) == null ? void 0 : _a.data) == null ? void 0 : _b.map((course) => course.id)) || [] : [];
    };
    const clearSelection = () => {
      data.selectedIds = [];
    };
    const goToCourseDetails = (course) => {
      try {
        if (course.slug) {
          router.visit(route("courses.details.show", { id: course.slug }));
        } else if (course.id) {
          router.visit(route("courses.details.show", { id: course.id }));
        } else {
          throw new Error("Course missing required slug or id parameter");
        }
      } catch (error) {
        console.error("Navigation error:", error);
        data.error = "Failed to navigate to course details";
      }
    };
    const openCreateModal = () => {
      createForm.reset();
      createForm.clearErrors();
      data.createOpen = true;
      nextTick(() => {
        var _a;
        (_a = createTitleInput.value) == null ? void 0 : _a.focus();
      });
    };
    const openEditModal = (course) => {
      var _a;
      editForm.reset();
      editForm.clearErrors();
      editForm.title = course.title;
      editForm.category_id = ((_a = course.category) == null ? void 0 : _a.id) || null;
      editForm.status = course.status.toLowerCase();
      editForm.description = course.description || "";
      data.courseToDelete = course;
      data.editOpen = true;
      nextTick(() => {
        var _a2;
        (_a2 = editTitleInput.value) == null ? void 0 : _a2.focus();
      });
    };
    const openDeleteModal = (course) => {
      data.courseToDelete = course;
      data.deleteOpen = true;
    };
    const openBulkDeleteModal = () => {
      bulkDeleteForm.ids = [...data.selectedIds];
      data.deleteBulkOpen = true;
    };
    const closeModals = () => {
      data.createOpen = false;
      data.editOpen = false;
      data.deleteOpen = false;
      data.deleteBulkOpen = false;
      data.courseToDelete = null;
    };
    const submitCreate = () => {
      createForm.post(route("courses.store"), {
        onSuccess: () => {
          closeModals();
          showSuccessMessage("Course created successfully!");
        },
        onError: (errors) => {
          console.error("Create error:", errors);
        }
      });
    };
    const submitEdit = () => {
      var _a;
      editForm.put(route("courses.update", (_a = data.courseToDelete) == null ? void 0 : _a.id), {
        onSuccess: () => {
          closeModals();
          showSuccessMessage("Course updated successfully!");
        },
        onError: (errors) => {
          console.error("Update error:", errors);
        }
      });
    };
    const submitDelete = () => {
      deleteForm.delete(route("courses.destroy", data.courseToDelete.id), {
        onSuccess: () => {
          closeModals();
          showSuccessMessage("Course deleted successfully!");
        },
        onError: (errors) => {
          console.error("Delete error:", errors);
        }
      });
    };
    const submitBulkDelete = () => {
      bulkDeleteForm.post(route("courses.bulk-delete"), {
        onSuccess: () => {
          closeModals();
          clearSelection();
          showSuccessMessage(`${bulkDeleteForm.ids.length} courses deleted successfully!`);
        },
        onError: (errors) => {
          console.error("Bulk delete error:", errors);
        }
      });
    };
    const showSuccessMessage = (message) => {
      data.successMessage = message;
      data.showSuccess = true;
      setTimeout(() => {
        data.showSuccess = false;
      }, 5e3);
    };
    const getTableIndex = (index) => {
      if (!props.courses.current_page || !props.courses.per_page) return index + 1;
      return (props.courses.current_page - 1) * props.courses.per_page + index + 1;
    };
    const getStatusBadgeClass = (status) => {
      const statusLower = status.toLowerCase();
      const classes = {
        active: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400",
        inactive: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400",
        draft: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      };
      return classes[statusLower] || "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    };
    const getSortIcon = (field) => {
      if (data.params.field !== field) return null;
      return data.params.order === "asc" ? ArrowUpIcon : ArrowDownIcon;
    };
    watch(
      () => [data.params.search, data.params.field, data.params.order, data.params.perPage],
      performSearch
    );
    watch(
      () => data.selectedIds.length,
      () => {
        nextTick(() => {
          const selectAllCheckbox = document.querySelector("#select-all-checkbox");
          if (selectAllCheckbox) {
            selectAllCheckbox.indeterminate = isIndeterminate.value;
          }
        });
      }
    );
    const handleKeydown = (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key === "n") {
        event.preventDefault();
        openCreateModal();
      }
      if (event.key === "Escape") {
        closeModals();
      }
    };
    nextTick(() => {
      document.addEventListener("keydown", handleKeydown);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="space-y-6"${_scopeId}>`);
            if (data.showSuccess) {
              _push2(`<div class="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4"${_scopeId}><div class="flex items-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(CheckCircleIcon), { class: "w-5 h-5 text-green-600 dark:text-green-400 mr-3" }, null, _parent2, _scopeId));
              _push2(`<p class="text-green-800 dark:text-green-200"${_scopeId}>${ssrInterpolate(data.successMessage)}</p><button class="ml-auto text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200"${_scopeId}> × </button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="bg-white dark:bg-slate-800 shadow rounded-lg p-6"${_scopeId}><div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4"${_scopeId}><div${_scopeId}><h1 class="text-2xl font-bold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(props.title)}</h1><p class="text-gray-600 dark:text-gray-400 mt-1"${_scopeId}> Manage your courses and categories </p></div><div class="flex gap-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Export `);
                } else {
                  return [
                    createTextVNode(" Export ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              onClick: openCreateModal,
              class: "flex items-center gap-2",
              title: "Create new course (Ctrl+N)"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(PlusIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                  _push3(` Add Course `);
                } else {
                  return [
                    createVNode(unref(PlusIcon), { class: "w-4 h-4" }),
                    createTextVNode(" Add Course ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"${_scopeId}><div class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800"${_scopeId}><h3 class="text-sm font-medium text-blue-600 dark:text-blue-400"${_scopeId}>Total Courses</h3><p class="text-2xl font-bold text-blue-900 dark:text-blue-100"${_scopeId}>${ssrInterpolate(props.stats.total || 0)}</p></div><div class="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800"${_scopeId}><h3 class="text-sm font-medium text-green-600 dark:text-green-400"${_scopeId}>Active</h3><p class="text-2xl font-bold text-green-900 dark:text-green-100"${_scopeId}>${ssrInterpolate(props.stats.active || 0)}</p></div><div class="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800"${_scopeId}><h3 class="text-sm font-medium text-yellow-600 dark:text-yellow-400"${_scopeId}>Draft</h3><p class="text-2xl font-bold text-yellow-900 dark:text-yellow-100"${_scopeId}>${ssrInterpolate(props.stats.draft || 0)}</p></div><div class="bg-gray-50 dark:bg-gray-900/20 p-4 rounded-lg border border-gray-200 dark:border-gray-800"${_scopeId}><h3 class="text-sm font-medium text-gray-600 dark:text-gray-400"${_scopeId}>Inactive</h3><p class="text-2xl font-bold text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(props.stats.inactive || 0)}</p></div></div></div><div class="bg-white dark:bg-slate-800 shadow rounded-lg overflow-hidden"${_scopeId}><div class="flex flex-col lg:flex-row justify-between items-start lg:items-center p-4 border-b border-gray-200 dark:border-gray-700 gap-4"${_scopeId}><div class="flex flex-col sm:flex-row items-start sm:items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              modelValue: data.params.perPage,
              "onUpdate:modelValue": ($event) => data.params.perPage = $event,
              dataSet: PER_PAGE_OPTIONS,
              class: "w-32",
              "aria-label": "Items per page"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              style: hasSelectedItems.value ? null : { display: "none" },
              onClick: openBulkDeleteModal,
              class: "flex items-center gap-2",
              "aria-label": `Delete ${data.selectedIds.length} selected courses`
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                  _push3(` Delete Selected (${ssrInterpolate(data.selectedIds.length)}) `);
                } else {
                  return [
                    createVNode(unref(TrashIcon), { class: "w-4 h-4" }),
                    createTextVNode(" Delete Selected (" + toDisplayString(data.selectedIds.length) + ") ", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            if (filteredCoursesCount.value) {
              _push2(`<div class="text-sm text-gray-600 dark:text-gray-400"${_scopeId}> Showing ${ssrInterpolate(currentPageRange.value)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="relative w-full lg:w-80"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(MagnifyingGlassIcon), { class: "absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              modelValue: data.params.search,
              "onUpdate:modelValue": ($event) => data.params.search = $event,
              type: "text",
              class: "w-full pl-10",
              placeholder: "Search courses, categories, status...",
              "aria-label": "Search courses"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
            if (data.loading) {
              _push2(`<div class="flex justify-center items-center py-12"${_scopeId}><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 dark:border-blue-400"${_scopeId}></div><span class="ml-3 text-gray-600 dark:text-gray-400"${_scopeId}>Loading courses...</span></div>`);
            } else if (data.error) {
              _push2(`<div class="text-center py-12"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(ExclamationTriangleIcon), { class: "w-12 h-12 text-red-500 mx-auto mb-4" }, null, _parent2, _scopeId));
              _push2(`<p class="text-red-600 dark:text-red-400 mb-4"${_scopeId}>${ssrInterpolate(data.error)}</p>`);
              _push2(ssrRenderComponent(_sfc_main$3, { onClick: unref(performSearch) }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Try Again `);
                  } else {
                    return [
                      createTextVNode(" Try Again ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<div class="overflow-x-auto"${_scopeId}><table class="w-full" role="table" aria-label="Courses table"${_scopeId}><thead class="bg-gray-50 dark:bg-slate-900/50"${_scopeId}><tr${_scopeId}><th class="px-4 py-3 text-center w-16" scope="col"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$7, {
                id: "select-all-checkbox",
                checked: isAllSelected.value,
                "onUpdate:checked": ($event) => isAllSelected.value = $event,
                onChange: selectAll,
                "aria-label": isAllSelected.value ? "Deselect all courses" : "Select all courses",
                class: "rounded"
              }, null, _parent2, _scopeId));
              _push2(`</th><th class="px-4 py-3 text-left w-16 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider" scope="col"${_scopeId}> # </th><!--[-->`);
              ssrRenderList(sortableColumns.value, (column) => {
                _push2(`<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors" scope="col"${ssrRenderAttr("aria-sort", data.params.field === column.key ? data.params.order === "asc" ? "ascending" : "descending" : "none")}${_scopeId}><div class="flex items-center justify-between"${_scopeId}><span${_scopeId}>${ssrInterpolate(column.label)}</span>`);
                if (getSortIcon(column.key)) {
                  ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(getSortIcon(column.key)), { class: "w-4 h-4 text-blue-600 dark:text-blue-400" }, null), _parent2, _scopeId);
                } else {
                  _push2(`<div class="flex flex-col opacity-50"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(ArrowUpIcon), { class: "w-3 h-3" }, null, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(ArrowDownIcon), { class: "w-3 h-3 -mt-1" }, null, _parent2, _scopeId));
                  _push2(`</div>`);
                }
                _push2(`</div></th>`);
              });
              _push2(`<!--]--><th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider" scope="col"${_scopeId}> Category </th><th class="px-4 py-3 text-center w-40 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider" scope="col"${_scopeId}> Actions </th></tr></thead><tbody class="bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-gray-700"${_scopeId}>`);
              if (!((_b = (_a = props.courses) == null ? void 0 : _a.data) == null ? void 0 : _b.length)) {
                _push2(`<tr class="text-center"${_scopeId}><td colspan="8" class="px-4 py-16 text-gray-500 dark:text-gray-400"${_scopeId}><div class="flex flex-col items-center"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(MagnifyingGlassIcon), { class: "w-12 h-12 text-gray-300 dark:text-gray-600 mb-4" }, null, _parent2, _scopeId));
                _push2(`<p class="text-lg mb-2"${_scopeId}>No courses found</p><p class="text-sm"${_scopeId}>Try adjusting your search criteria or create a new course</p></div></td></tr>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<!--[-->`);
              ssrRenderList(props.courses.data, (course, index) => {
                _push2(`<tr class="${ssrRenderClass([{ "bg-blue-50 dark:bg-blue-900/20": data.selectedIds.includes(course.id) }, "hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors"])}"${_scopeId}><td class="px-4 py-3 text-center"${_scopeId}><input type="checkbox"${ssrRenderAttr("value", course.id)}${ssrIncludeBooleanAttr(Array.isArray(data.selectedIds) ? ssrLooseContain(data.selectedIds, course.id) : data.selectedIds) ? " checked" : ""} class="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-slate-700"${ssrRenderAttr("aria-label", `Select course: ${course.title}`)}${_scopeId}></td><td class="px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100"${_scopeId}>${ssrInterpolate(getTableIndex(index))}</td><td class="px-4 py-3"${_scopeId}><div class="text-sm font-medium"${_scopeId}><button class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 hover:underline transition-colors text-left"${ssrRenderAttr("title", `View details for ${course.title}`)}${ssrRenderAttr("aria-label", `View details for course: ${course.title}`)}${_scopeId}>${ssrInterpolate(course.title)}</button></div>`);
                if (course.description) {
                  _push2(`<div class="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs"${_scopeId}>${ssrInterpolate(course.description)}</div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</td><td class="px-4 py-3"${_scopeId}><span class="${ssrRenderClass([getStatusBadgeClass(course.status), "inline-flex px-2 py-1 text-xs font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(course.status)}</span></td><td class="px-4 py-3 text-sm text-gray-500 dark:text-gray-400"${_scopeId}><time${ssrRenderAttr("datetime", course.created_at)}${_scopeId}>${ssrInterpolate(course.created_at)}</time></td><td class="px-4 py-3 text-sm text-gray-500 dark:text-gray-400"${_scopeId}><time${ssrRenderAttr("datetime", course.updated_at)}${_scopeId}>${ssrInterpolate(course.updated_at)}</time></td><td class="px-4 py-3 text-sm text-gray-500 dark:text-gray-400"${_scopeId}>`);
                if (course.category) {
                  _push2(`<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"${_scopeId}>${ssrInterpolate(course.category.name)}</span>`);
                } else {
                  _push2(`<span class="text-gray-400"${_scopeId}>-</span>`);
                }
                _push2(`</td><td class="px-4 py-3"${_scopeId}><div class="flex items-center justify-center gap-1"${_scopeId}><button class="p-2 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-md transition-colors"${ssrRenderAttr("title", `View details for ${course.title}`)}${ssrRenderAttr("aria-label", `View details for course: ${course.title}`)}${_scopeId}>`);
                _push2(ssrRenderComponent(unref(EyeIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
                _push2(`</button>`);
                _push2(ssrRenderComponent(_sfc_main$3, {
                  onClick: ($event) => openEditModal(course),
                  class: "p-2 text-xs",
                  title: `Edit ${course.title}`,
                  "aria-label": `Edit course: ${course.title}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(_sfc_main$5, {
                  onClick: ($event) => openDeleteModal(course),
                  class: "p-2 text-xs",
                  title: `Delete ${course.title}`,
                  "aria-label": `Delete course: ${course.title}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></td></tr>`);
              });
              _push2(`<!--]--></tbody></table></div>`);
            }
            _push2(`<div class="px-4 py-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-slate-900/50"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              links: props.courses,
              filters: data.params
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
            _push2(ssrRenderComponent(_sfc_main$9, {
              show: data.createOpen,
              onClose: closeModals,
              "max-width": "2xl"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6"${_scopeId2}> Create New Course </h2><form class="space-y-6"${_scopeId2}><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "create-title",
                    value: "Course Title"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$6, {
                    id: "create-title",
                    ref_key: "createTitleInput",
                    ref: createTitleInput,
                    modelValue: unref(createForm).title,
                    "onUpdate:modelValue": ($event) => unref(createForm).title = $event,
                    type: "text",
                    class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.title }],
                    placeholder: "Enter course title",
                    required: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(createForm).errors.title,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "create-category",
                    value: "Category"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    id: "create-category",
                    modelValue: unref(createForm).category_id,
                    "onUpdate:modelValue": ($event) => unref(createForm).category_id = $event,
                    dataSet: categoriesForSelect.value,
                    class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.category_id }]
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(createForm).errors.category_id,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "create-status",
                    value: "Status"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    id: "create-status",
                    modelValue: unref(createForm).status,
                    "onUpdate:modelValue": ($event) => unref(createForm).status = $event,
                    dataSet: STATUS_OPTIONS,
                    class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.status }]
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(createForm).errors.status,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "create-description",
                    value: "Description"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$c, {
                    id: "create-description",
                    modelValue: unref(createForm).description,
                    "onUpdate:modelValue": ($event) => unref(createForm).description = $event,
                    class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.description }],
                    rows: "4",
                    placeholder: "Enter course description (optional)"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(createForm).errors.description,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="flex justify-end gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    onClick: closeModals,
                    type: "button"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    type: "submit",
                    disabled: unref(createForm).processing,
                    class: "flex items-center gap-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (unref(createForm).processing) {
                          _push4(`<span class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"${_scopeId3}></span>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` ${ssrInterpolate(unref(createForm).processing ? "Creating..." : "Create Course")}`);
                      } else {
                        return [
                          unref(createForm).processing ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                          })) : createCommentVNode("", true),
                          createTextVNode(" " + toDisplayString(unref(createForm).processing ? "Creating..." : "Create Course"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6" }, " Create New Course "),
                      createVNode("form", {
                        onSubmit: withModifiers(submitCreate, ["prevent"]),
                        class: "space-y-6"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "create-title",
                            value: "Course Title"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "create-title",
                            ref_key: "createTitleInput",
                            ref: createTitleInput,
                            modelValue: unref(createForm).title,
                            "onUpdate:modelValue": ($event) => unref(createForm).title = $event,
                            type: "text",
                            class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.title }],
                            placeholder: "Enter course title",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(createForm).errors.title,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "create-category",
                            value: "Category"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "create-category",
                            modelValue: unref(createForm).category_id,
                            "onUpdate:modelValue": ($event) => unref(createForm).category_id = $event,
                            dataSet: categoriesForSelect.value,
                            class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.category_id }]
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(createForm).errors.category_id,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "create-status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "create-status",
                            modelValue: unref(createForm).status,
                            "onUpdate:modelValue": ($event) => unref(createForm).status = $event,
                            dataSet: STATUS_OPTIONS,
                            class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.status }]
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(createForm).errors.status,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "create-description",
                            value: "Description"
                          }),
                          createVNode(_sfc_main$c, {
                            id: "create-description",
                            modelValue: unref(createForm).description,
                            "onUpdate:modelValue": ($event) => unref(createForm).description = $event,
                            class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.description }],
                            rows: "4",
                            placeholder: "Enter course description (optional)"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(createForm).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "flex justify-end gap-3" }, [
                          createVNode(_sfc_main$2, {
                            onClick: closeModals,
                            type: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$3, {
                            type: "submit",
                            disabled: unref(createForm).processing,
                            class: "flex items-center gap-2"
                          }, {
                            default: withCtx(() => [
                              unref(createForm).processing ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                              })) : createCommentVNode("", true),
                              createTextVNode(" " + toDisplayString(unref(createForm).processing ? "Creating..." : "Create Course"), 1)
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              show: data.editOpen,
              onClose: closeModals,
              "max-width": "2xl"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6"${_scopeId2}> Edit Course </h2><form class="space-y-6"${_scopeId2}><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "edit-title",
                    value: "Course Title"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$6, {
                    id: "edit-title",
                    ref_key: "editTitleInput",
                    ref: editTitleInput,
                    modelValue: unref(editForm).title,
                    "onUpdate:modelValue": ($event) => unref(editForm).title = $event,
                    type: "text",
                    class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.title }],
                    placeholder: "Enter course title",
                    required: ""
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(editForm).errors.title,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "edit-category",
                    value: "Category"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    id: "edit-category",
                    modelValue: unref(editForm).category_id,
                    "onUpdate:modelValue": ($event) => unref(editForm).category_id = $event,
                    dataSet: categoriesForSelect.value,
                    class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.category_id }]
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(editForm).errors.category_id,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "edit-status",
                    value: "Status"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    id: "edit-status",
                    modelValue: unref(editForm).status,
                    "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                    dataSet: STATUS_OPTIONS,
                    class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.status }]
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(editForm).errors.status,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$a, {
                    for: "edit-description",
                    value: "Description"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$c, {
                    id: "edit-description",
                    modelValue: unref(editForm).description,
                    "onUpdate:modelValue": ($event) => unref(editForm).description = $event,
                    class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.description }],
                    rows: "4",
                    placeholder: "Enter course description (optional)"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$b, {
                    message: unref(editForm).errors.description,
                    class: "mt-2"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="flex justify-end gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    onClick: closeModals,
                    type: "button"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    type: "submit",
                    disabled: unref(editForm).processing,
                    class: "flex items-center gap-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (unref(editForm).processing) {
                          _push4(`<span class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"${_scopeId3}></span>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` ${ssrInterpolate(unref(editForm).processing ? "Updating..." : "Update Course")}`);
                      } else {
                        return [
                          unref(editForm).processing ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                          })) : createCommentVNode("", true),
                          createTextVNode(" " + toDisplayString(unref(editForm).processing ? "Updating..." : "Update Course"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6" }, " Edit Course "),
                      createVNode("form", {
                        onSubmit: withModifiers(submitEdit, ["prevent"]),
                        class: "space-y-6"
                      }, [
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "edit-title",
                            value: "Course Title"
                          }),
                          createVNode(_sfc_main$6, {
                            id: "edit-title",
                            ref_key: "editTitleInput",
                            ref: editTitleInput,
                            modelValue: unref(editForm).title,
                            "onUpdate:modelValue": ($event) => unref(editForm).title = $event,
                            type: "text",
                            class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.title }],
                            placeholder: "Enter course title",
                            required: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(editForm).errors.title,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "edit-category",
                            value: "Category"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "edit-category",
                            modelValue: unref(editForm).category_id,
                            "onUpdate:modelValue": ($event) => unref(editForm).category_id = $event,
                            dataSet: categoriesForSelect.value,
                            class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.category_id }]
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(editForm).errors.category_id,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "edit-status",
                            value: "Status"
                          }),
                          createVNode(_sfc_main$4, {
                            id: "edit-status",
                            modelValue: unref(editForm).status,
                            "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                            dataSet: STATUS_OPTIONS,
                            class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.status }]
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(editForm).errors.status,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", null, [
                          createVNode(_sfc_main$a, {
                            for: "edit-description",
                            value: "Description"
                          }),
                          createVNode(_sfc_main$c, {
                            id: "edit-description",
                            modelValue: unref(editForm).description,
                            "onUpdate:modelValue": ($event) => unref(editForm).description = $event,
                            class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.description }],
                            rows: "4",
                            placeholder: "Enter course description (optional)"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                          createVNode(_sfc_main$b, {
                            message: unref(editForm).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "flex justify-end gap-3" }, [
                          createVNode(_sfc_main$2, {
                            onClick: closeModals,
                            type: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$3, {
                            type: "submit",
                            disabled: unref(editForm).processing,
                            class: "flex items-center gap-2"
                          }, {
                            default: withCtx(() => [
                              unref(editForm).processing ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                              })) : createCommentVNode("", true),
                              createTextVNode(" " + toDisplayString(unref(editForm).processing ? "Updating..." : "Update Course"), 1)
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              show: data.deleteOpen,
              onClose: closeModals,
              "max-width": "md"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a2, _b2;
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><div class="flex items-center mb-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }, null, _parent3, _scopeId2));
                  _push3(`<h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}> Delete Course </h2></div><div class="mb-6"${_scopeId2}><p class="text-gray-600 dark:text-gray-400"${_scopeId2}> Are you sure you want to delete &quot;<span class="font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate((_a2 = data.courseToDelete) == null ? void 0 : _a2.title)}</span>&quot;? </p><p class="text-sm text-red-600 dark:text-red-400 mt-2"${_scopeId2}> This action cannot be undone. </p></div><div class="flex justify-end gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    onClick: closeModals,
                    type: "button"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    onClick: submitDelete,
                    disabled: unref(deleteForm).processing,
                    class: "flex items-center gap-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (unref(deleteForm).processing) {
                          _push4(`<span class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"${_scopeId3}></span>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` ${ssrInterpolate(unref(deleteForm).processing ? "Deleting..." : "Delete Course")}`);
                      } else {
                        return [
                          unref(deleteForm).processing ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                          })) : createCommentVNode("", true),
                          createTextVNode(" " + toDisplayString(unref(deleteForm).processing ? "Deleting..." : "Delete Course"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex items-center mb-6" }, [
                        createVNode(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }),
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Delete Course ")
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, [
                          createTextVNode(' Are you sure you want to delete "'),
                          createVNode("span", { class: "font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString((_b2 = data.courseToDelete) == null ? void 0 : _b2.title), 1),
                          createTextVNode('"? ')
                        ]),
                        createVNode("p", { class: "text-sm text-red-600 dark:text-red-400 mt-2" }, " This action cannot be undone. ")
                      ]),
                      createVNode("div", { class: "flex justify-end gap-3" }, [
                        createVNode(_sfc_main$2, {
                          onClick: closeModals,
                          type: "button"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$5, {
                          onClick: submitDelete,
                          disabled: unref(deleteForm).processing,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            unref(deleteForm).processing ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                            })) : createCommentVNode("", true),
                            createTextVNode(" " + toDisplayString(unref(deleteForm).processing ? "Deleting..." : "Delete Course"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              show: data.deleteBulkOpen,
              onClose: closeModals,
              "max-width": "md"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6"${_scopeId2}><div class="flex items-center mb-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }, null, _parent3, _scopeId2));
                  _push3(`<h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}> Delete Multiple Courses </h2></div><div class="mb-6"${_scopeId2}><p class="text-gray-600 dark:text-gray-400"${_scopeId2}> Are you sure you want to delete <span class="font-semibold text-gray-900 dark:text-gray-100"${_scopeId2}>${ssrInterpolate(unref(bulkDeleteForm).ids.length)}</span> selected courses? </p><p class="text-sm text-red-600 dark:text-red-400 mt-2"${_scopeId2}> This action cannot be undone. </p></div><div class="flex justify-end gap-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    onClick: closeModals,
                    type: "button"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Cancel `);
                      } else {
                        return [
                          createTextVNode(" Cancel ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$5, {
                    onClick: submitBulkDelete,
                    disabled: unref(bulkDeleteForm).processing,
                    class: "flex items-center gap-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (unref(bulkDeleteForm).processing) {
                          _push4(`<span class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"${_scopeId3}></span>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(` ${ssrInterpolate(unref(bulkDeleteForm).processing ? "Deleting..." : `Delete ${unref(bulkDeleteForm).ids.length} Courses`)}`);
                      } else {
                        return [
                          unref(bulkDeleteForm).processing ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                          })) : createCommentVNode("", true),
                          createTextVNode(" " + toDisplayString(unref(bulkDeleteForm).processing ? "Deleting..." : `Delete ${unref(bulkDeleteForm).ids.length} Courses`), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex items-center mb-6" }, [
                        createVNode(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }),
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Delete Multiple Courses ")
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, [
                          createTextVNode(" Are you sure you want to delete "),
                          createVNode("span", { class: "font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(unref(bulkDeleteForm).ids.length), 1),
                          createTextVNode(" selected courses? ")
                        ]),
                        createVNode("p", { class: "text-sm text-red-600 dark:text-red-400 mt-2" }, " This action cannot be undone. ")
                      ]),
                      createVNode("div", { class: "flex justify-end gap-3" }, [
                        createVNode(_sfc_main$2, {
                          onClick: closeModals,
                          type: "button"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$5, {
                          onClick: submitBulkDelete,
                          disabled: unref(bulkDeleteForm).processing,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            unref(bulkDeleteForm).processing ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                            })) : createCommentVNode("", true),
                            createTextVNode(" " + toDisplayString(unref(bulkDeleteForm).processing ? "Deleting..." : `Delete ${unref(bulkDeleteForm).ids.length} Courses`), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "space-y-6" }, [
                createVNode(Transition, {
                  "enter-active-class": "transition ease-out duration-300",
                  "enter-from-class": "opacity-0 transform translate-y-2",
                  "enter-to-class": "opacity-100 transform translate-y-0",
                  "leave-active-class": "transition ease-in duration-200",
                  "leave-from-class": "opacity-100 transform translate-y-0",
                  "leave-to-class": "opacity-0 transform translate-y-2"
                }, {
                  default: withCtx(() => [
                    data.showSuccess ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4"
                    }, [
                      createVNode("div", { class: "flex items-center" }, [
                        createVNode(unref(CheckCircleIcon), { class: "w-5 h-5 text-green-600 dark:text-green-400 mr-3" }),
                        createVNode("p", { class: "text-green-800 dark:text-green-200" }, toDisplayString(data.successMessage), 1),
                        createVNode("button", {
                          onClick: ($event) => data.showSuccess = false,
                          class: "ml-auto text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200"
                        }, " × ", 8, ["onClick"])
                      ])
                    ])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "bg-white dark:bg-slate-800 shadow rounded-lg p-6" }, [
                  createVNode("div", { class: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4" }, [
                    createVNode("div", null, [
                      createVNode("h1", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, toDisplayString(props.title), 1),
                      createVNode("p", { class: "text-gray-600 dark:text-gray-400 mt-1" }, " Manage your courses and categories ")
                    ]),
                    createVNode("div", { class: "flex gap-3" }, [
                      createVNode(_sfc_main$2, null, {
                        default: withCtx(() => [
                          createTextVNode(" Export ")
                        ]),
                        _: 1
                      }),
                      createVNode(_sfc_main$3, {
                        onClick: openCreateModal,
                        class: "flex items-center gap-2",
                        title: "Create new course (Ctrl+N)"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(PlusIcon), { class: "w-4 h-4" }),
                          createTextVNode(" Add Course ")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" }, [
                    createVNode("div", { class: "bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800" }, [
                      createVNode("h3", { class: "text-sm font-medium text-blue-600 dark:text-blue-400" }, "Total Courses"),
                      createVNode("p", { class: "text-2xl font-bold text-blue-900 dark:text-blue-100" }, toDisplayString(props.stats.total || 0), 1)
                    ]),
                    createVNode("div", { class: "bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800" }, [
                      createVNode("h3", { class: "text-sm font-medium text-green-600 dark:text-green-400" }, "Active"),
                      createVNode("p", { class: "text-2xl font-bold text-green-900 dark:text-green-100" }, toDisplayString(props.stats.active || 0), 1)
                    ]),
                    createVNode("div", { class: "bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800" }, [
                      createVNode("h3", { class: "text-sm font-medium text-yellow-600 dark:text-yellow-400" }, "Draft"),
                      createVNode("p", { class: "text-2xl font-bold text-yellow-900 dark:text-yellow-100" }, toDisplayString(props.stats.draft || 0), 1)
                    ]),
                    createVNode("div", { class: "bg-gray-50 dark:bg-gray-900/20 p-4 rounded-lg border border-gray-200 dark:border-gray-800" }, [
                      createVNode("h3", { class: "text-sm font-medium text-gray-600 dark:text-gray-400" }, "Inactive"),
                      createVNode("p", { class: "text-2xl font-bold text-gray-900 dark:text-gray-100" }, toDisplayString(props.stats.inactive || 0), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white dark:bg-slate-800 shadow rounded-lg overflow-hidden" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row justify-between items-start lg:items-center p-4 border-b border-gray-200 dark:border-gray-700 gap-4" }, [
                    createVNode("div", { class: "flex flex-col sm:flex-row items-start sm:items-center gap-4" }, [
                      createVNode(_sfc_main$4, {
                        modelValue: data.params.perPage,
                        "onUpdate:modelValue": ($event) => data.params.perPage = $event,
                        dataSet: PER_PAGE_OPTIONS,
                        class: "w-32",
                        "aria-label": "Items per page"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(Transition, {
                        "enter-active-class": "transition ease-out duration-200",
                        "enter-from-class": "opacity-0 transform scale-95",
                        "enter-to-class": "opacity-100 transform scale-100",
                        "leave-active-class": "transition ease-in duration-150",
                        "leave-from-class": "opacity-100 transform scale-100",
                        "leave-to-class": "opacity-0 transform scale-95"
                      }, {
                        default: withCtx(() => [
                          withDirectives(createVNode(_sfc_main$5, {
                            onClick: openBulkDeleteModal,
                            class: "flex items-center gap-2",
                            "aria-label": `Delete ${data.selectedIds.length} selected courses`
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(TrashIcon), { class: "w-4 h-4" }),
                              createTextVNode(" Delete Selected (" + toDisplayString(data.selectedIds.length) + ") ", 1)
                            ]),
                            _: 1
                          }, 8, ["aria-label"]), [
                            [vShow, hasSelectedItems.value]
                          ])
                        ]),
                        _: 1
                      }),
                      filteredCoursesCount.value ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-gray-600 dark:text-gray-400"
                      }, " Showing " + toDisplayString(currentPageRange.value), 1)) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "relative w-full lg:w-80" }, [
                      createVNode(unref(MagnifyingGlassIcon), { class: "absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" }),
                      createVNode(_sfc_main$6, {
                        modelValue: data.params.search,
                        "onUpdate:modelValue": ($event) => data.params.search = $event,
                        type: "text",
                        class: "w-full pl-10",
                        placeholder: "Search courses, categories, status...",
                        "aria-label": "Search courses"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ])
                  ]),
                  data.loading ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "flex justify-center items-center py-12"
                  }, [
                    createVNode("div", { class: "animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 dark:border-blue-400" }),
                    createVNode("span", { class: "ml-3 text-gray-600 dark:text-gray-400" }, "Loading courses...")
                  ])) : data.error ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "text-center py-12"
                  }, [
                    createVNode(unref(ExclamationTriangleIcon), { class: "w-12 h-12 text-red-500 mx-auto mb-4" }),
                    createVNode("p", { class: "text-red-600 dark:text-red-400 mb-4" }, toDisplayString(data.error), 1),
                    createVNode(_sfc_main$3, { onClick: unref(performSearch) }, {
                      default: withCtx(() => [
                        createTextVNode(" Try Again ")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ])) : (openBlock(), createBlock("div", {
                    key: 2,
                    class: "overflow-x-auto"
                  }, [
                    createVNode("table", {
                      class: "w-full",
                      role: "table",
                      "aria-label": "Courses table"
                    }, [
                      createVNode("thead", { class: "bg-gray-50 dark:bg-slate-900/50" }, [
                        createVNode("tr", null, [
                          createVNode("th", {
                            class: "px-4 py-3 text-center w-16",
                            scope: "col"
                          }, [
                            createVNode(_sfc_main$7, {
                              id: "select-all-checkbox",
                              checked: isAllSelected.value,
                              "onUpdate:checked": ($event) => isAllSelected.value = $event,
                              onChange: selectAll,
                              "aria-label": isAllSelected.value ? "Deselect all courses" : "Select all courses",
                              class: "rounded"
                            }, null, 8, ["checked", "onUpdate:checked", "aria-label"])
                          ]),
                          createVNode("th", {
                            class: "px-4 py-3 text-left w-16 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider",
                            scope: "col"
                          }, " # "),
                          (openBlock(true), createBlock(Fragment, null, renderList(sortableColumns.value, (column) => {
                            return openBlock(), createBlock("th", {
                              key: column.key,
                              class: "px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors",
                              onClick: ($event) => sortBy(column.key),
                              scope: "col",
                              "aria-sort": data.params.field === column.key ? data.params.order === "asc" ? "ascending" : "descending" : "none"
                            }, [
                              createVNode("div", { class: "flex items-center justify-between" }, [
                                createVNode("span", null, toDisplayString(column.label), 1),
                                getSortIcon(column.key) ? (openBlock(), createBlock(resolveDynamicComponent(getSortIcon(column.key)), {
                                  key: 0,
                                  class: "w-4 h-4 text-blue-600 dark:text-blue-400"
                                })) : (openBlock(), createBlock("div", {
                                  key: 1,
                                  class: "flex flex-col opacity-50"
                                }, [
                                  createVNode(unref(ArrowUpIcon), { class: "w-3 h-3" }),
                                  createVNode(unref(ArrowDownIcon), { class: "w-3 h-3 -mt-1" })
                                ]))
                              ])
                            ], 8, ["onClick", "aria-sort"]);
                          }), 128)),
                          createVNode("th", {
                            class: "px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider",
                            scope: "col"
                          }, " Category "),
                          createVNode("th", {
                            class: "px-4 py-3 text-center w-40 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider",
                            scope: "col"
                          }, " Actions ")
                        ])
                      ]),
                      createVNode("tbody", { class: "bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-gray-700" }, [
                        !((_d = (_c = props.courses) == null ? void 0 : _c.data) == null ? void 0 : _d.length) ? (openBlock(), createBlock("tr", {
                          key: 0,
                          class: "text-center"
                        }, [
                          createVNode("td", {
                            colspan: "8",
                            class: "px-4 py-16 text-gray-500 dark:text-gray-400"
                          }, [
                            createVNode("div", { class: "flex flex-col items-center" }, [
                              createVNode(unref(MagnifyingGlassIcon), { class: "w-12 h-12 text-gray-300 dark:text-gray-600 mb-4" }),
                              createVNode("p", { class: "text-lg mb-2" }, "No courses found"),
                              createVNode("p", { class: "text-sm" }, "Try adjusting your search criteria or create a new course")
                            ])
                          ])
                        ])) : createCommentVNode("", true),
                        (openBlock(true), createBlock(Fragment, null, renderList(props.courses.data, (course, index) => {
                          return openBlock(), createBlock("tr", {
                            key: course.id,
                            class: ["hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors", { "bg-blue-50 dark:bg-blue-900/20": data.selectedIds.includes(course.id) }]
                          }, [
                            createVNode("td", { class: "px-4 py-3 text-center" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                value: course.id,
                                "onUpdate:modelValue": ($event) => data.selectedIds = $event,
                                class: "rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-slate-700",
                                "aria-label": `Select course: ${course.title}`
                              }, null, 8, ["value", "onUpdate:modelValue", "aria-label"]), [
                                [vModelCheckbox, data.selectedIds]
                              ])
                            ]),
                            createVNode("td", { class: "px-4 py-3 text-sm font-medium text-gray-900 dark:text-gray-100" }, toDisplayString(getTableIndex(index)), 1),
                            createVNode("td", { class: "px-4 py-3" }, [
                              createVNode("div", { class: "text-sm font-medium" }, [
                                createVNode("button", {
                                  onClick: ($event) => goToCourseDetails(course),
                                  class: "text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 hover:underline transition-colors text-left",
                                  title: `View details for ${course.title}`,
                                  "aria-label": `View details for course: ${course.title}`
                                }, toDisplayString(course.title), 9, ["onClick", "title", "aria-label"])
                              ]),
                              course.description ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs"
                              }, toDisplayString(course.description), 1)) : createCommentVNode("", true)
                            ]),
                            createVNode("td", { class: "px-4 py-3" }, [
                              createVNode("span", {
                                class: ["inline-flex px-2 py-1 text-xs font-semibold rounded-full", getStatusBadgeClass(course.status)]
                              }, toDisplayString(course.status), 3)
                            ]),
                            createVNode("td", { class: "px-4 py-3 text-sm text-gray-500 dark:text-gray-400" }, [
                              createVNode("time", {
                                datetime: course.created_at
                              }, toDisplayString(course.created_at), 9, ["datetime"])
                            ]),
                            createVNode("td", { class: "px-4 py-3 text-sm text-gray-500 dark:text-gray-400" }, [
                              createVNode("time", {
                                datetime: course.updated_at
                              }, toDisplayString(course.updated_at), 9, ["datetime"])
                            ]),
                            createVNode("td", { class: "px-4 py-3 text-sm text-gray-500 dark:text-gray-400" }, [
                              course.category ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                              }, toDisplayString(course.category.name), 1)) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "text-gray-400"
                              }, "-"))
                            ]),
                            createVNode("td", { class: "px-4 py-3" }, [
                              createVNode("div", { class: "flex items-center justify-center gap-1" }, [
                                createVNode("button", {
                                  onClick: ($event) => goToCourseDetails(course),
                                  class: "p-2 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-md transition-colors",
                                  title: `View details for ${course.title}`,
                                  "aria-label": `View details for course: ${course.title}`
                                }, [
                                  createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                                ], 8, ["onClick", "title", "aria-label"]),
                                createVNode(_sfc_main$3, {
                                  onClick: ($event) => openEditModal(course),
                                  class: "p-2 text-xs",
                                  title: `Edit ${course.title}`,
                                  "aria-label": `Edit course: ${course.title}`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                                  ]),
                                  _: 2
                                }, 1032, ["onClick", "title", "aria-label"]),
                                createVNode(_sfc_main$5, {
                                  onClick: ($event) => openDeleteModal(course),
                                  class: "p-2 text-xs",
                                  title: `Delete ${course.title}`,
                                  "aria-label": `Delete course: ${course.title}`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                                  ]),
                                  _: 2
                                }, 1032, ["onClick", "title", "aria-label"])
                              ])
                            ])
                          ], 2);
                        }), 128))
                      ])
                    ])
                  ])),
                  createVNode("div", { class: "px-4 py-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-slate-900/50" }, [
                    createVNode(_sfc_main$8, {
                      links: props.courses,
                      filters: data.params
                    }, null, 8, ["links", "filters"])
                  ])
                ])
              ]),
              createVNode(_sfc_main$9, {
                show: data.createOpen,
                onClose: closeModals,
                "max-width": "2xl"
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6" }, " Create New Course "),
                    createVNode("form", {
                      onSubmit: withModifiers(submitCreate, ["prevent"]),
                      class: "space-y-6"
                    }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "create-title",
                          value: "Course Title"
                        }),
                        createVNode(_sfc_main$6, {
                          id: "create-title",
                          ref_key: "createTitleInput",
                          ref: createTitleInput,
                          modelValue: unref(createForm).title,
                          "onUpdate:modelValue": ($event) => unref(createForm).title = $event,
                          type: "text",
                          class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.title }],
                          placeholder: "Enter course title",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(createForm).errors.title,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "create-category",
                          value: "Category"
                        }),
                        createVNode(_sfc_main$4, {
                          id: "create-category",
                          modelValue: unref(createForm).category_id,
                          "onUpdate:modelValue": ($event) => unref(createForm).category_id = $event,
                          dataSet: categoriesForSelect.value,
                          class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.category_id }]
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(createForm).errors.category_id,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "create-status",
                          value: "Status"
                        }),
                        createVNode(_sfc_main$4, {
                          id: "create-status",
                          modelValue: unref(createForm).status,
                          "onUpdate:modelValue": ($event) => unref(createForm).status = $event,
                          dataSet: STATUS_OPTIONS,
                          class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.status }]
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(createForm).errors.status,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "create-description",
                          value: "Description"
                        }),
                        createVNode(_sfc_main$c, {
                          id: "create-description",
                          modelValue: unref(createForm).description,
                          "onUpdate:modelValue": ($event) => unref(createForm).description = $event,
                          class: ["mt-1 block w-full", { "border-red-500": unref(createForm).errors.description }],
                          rows: "4",
                          placeholder: "Enter course description (optional)"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(createForm).errors.description,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "flex justify-end gap-3" }, [
                        createVNode(_sfc_main$2, {
                          onClick: closeModals,
                          type: "button"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$3, {
                          type: "submit",
                          disabled: unref(createForm).processing,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            unref(createForm).processing ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                            })) : createCommentVNode("", true),
                            createTextVNode(" " + toDisplayString(unref(createForm).processing ? "Creating..." : "Create Course"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"]),
              createVNode(_sfc_main$9, {
                show: data.editOpen,
                onClose: closeModals,
                "max-width": "2xl"
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100 mb-6" }, " Edit Course "),
                    createVNode("form", {
                      onSubmit: withModifiers(submitEdit, ["prevent"]),
                      class: "space-y-6"
                    }, [
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "edit-title",
                          value: "Course Title"
                        }),
                        createVNode(_sfc_main$6, {
                          id: "edit-title",
                          ref_key: "editTitleInput",
                          ref: editTitleInput,
                          modelValue: unref(editForm).title,
                          "onUpdate:modelValue": ($event) => unref(editForm).title = $event,
                          type: "text",
                          class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.title }],
                          placeholder: "Enter course title",
                          required: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(editForm).errors.title,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "edit-category",
                          value: "Category"
                        }),
                        createVNode(_sfc_main$4, {
                          id: "edit-category",
                          modelValue: unref(editForm).category_id,
                          "onUpdate:modelValue": ($event) => unref(editForm).category_id = $event,
                          dataSet: categoriesForSelect.value,
                          class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.category_id }]
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(editForm).errors.category_id,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "edit-status",
                          value: "Status"
                        }),
                        createVNode(_sfc_main$4, {
                          id: "edit-status",
                          modelValue: unref(editForm).status,
                          "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                          dataSet: STATUS_OPTIONS,
                          class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.status }]
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(editForm).errors.status,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", null, [
                        createVNode(_sfc_main$a, {
                          for: "edit-description",
                          value: "Description"
                        }),
                        createVNode(_sfc_main$c, {
                          id: "edit-description",
                          modelValue: unref(editForm).description,
                          "onUpdate:modelValue": ($event) => unref(editForm).description = $event,
                          class: ["mt-1 block w-full", { "border-red-500": unref(editForm).errors.description }],
                          rows: "4",
                          placeholder: "Enter course description (optional)"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                        createVNode(_sfc_main$b, {
                          message: unref(editForm).errors.description,
                          class: "mt-2"
                        }, null, 8, ["message"])
                      ]),
                      createVNode("div", { class: "flex justify-end gap-3" }, [
                        createVNode(_sfc_main$2, {
                          onClick: closeModals,
                          type: "button"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$3, {
                          type: "submit",
                          disabled: unref(editForm).processing,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            unref(editForm).processing ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                            })) : createCommentVNode("", true),
                            createTextVNode(" " + toDisplayString(unref(editForm).processing ? "Updating..." : "Update Course"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"]),
              createVNode(_sfc_main$9, {
                show: data.deleteOpen,
                onClose: closeModals,
                "max-width": "md"
              }, {
                default: withCtx(() => {
                  var _a2;
                  return [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex items-center mb-6" }, [
                        createVNode(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }),
                        createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Delete Course ")
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, [
                          createTextVNode(' Are you sure you want to delete "'),
                          createVNode("span", { class: "font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString((_a2 = data.courseToDelete) == null ? void 0 : _a2.title), 1),
                          createTextVNode('"? ')
                        ]),
                        createVNode("p", { class: "text-sm text-red-600 dark:text-red-400 mt-2" }, " This action cannot be undone. ")
                      ]),
                      createVNode("div", { class: "flex justify-end gap-3" }, [
                        createVNode(_sfc_main$2, {
                          onClick: closeModals,
                          type: "button"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Cancel ")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$5, {
                          onClick: submitDelete,
                          disabled: unref(deleteForm).processing,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            unref(deleteForm).processing ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                            })) : createCommentVNode("", true),
                            createTextVNode(" " + toDisplayString(unref(deleteForm).processing ? "Deleting..." : "Delete Course"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ])
                  ];
                }),
                _: 1
              }, 8, ["show"]),
              createVNode(_sfc_main$9, {
                show: data.deleteBulkOpen,
                onClose: closeModals,
                "max-width": "md"
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6" }, [
                    createVNode("div", { class: "flex items-center mb-6" }, [
                      createVNode(unref(ExclamationTriangleIcon), { class: "w-8 h-8 text-red-600 dark:text-red-400 mr-4" }),
                      createVNode("h2", { class: "text-lg font-semibold text-gray-900 dark:text-gray-100" }, " Delete Multiple Courses ")
                    ]),
                    createVNode("div", { class: "mb-6" }, [
                      createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, [
                        createTextVNode(" Are you sure you want to delete "),
                        createVNode("span", { class: "font-semibold text-gray-900 dark:text-gray-100" }, toDisplayString(unref(bulkDeleteForm).ids.length), 1),
                        createTextVNode(" selected courses? ")
                      ]),
                      createVNode("p", { class: "text-sm text-red-600 dark:text-red-400 mt-2" }, " This action cannot be undone. ")
                    ]),
                    createVNode("div", { class: "flex justify-end gap-3" }, [
                      createVNode(_sfc_main$2, {
                        onClick: closeModals,
                        type: "button"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Cancel ")
                        ]),
                        _: 1
                      }),
                      createVNode(_sfc_main$5, {
                        onClick: submitBulkDelete,
                        disabled: unref(bulkDeleteForm).processing,
                        class: "flex items-center gap-2"
                      }, {
                        default: withCtx(() => [
                          unref(bulkDeleteForm).processing ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                          })) : createCommentVNode("", true),
                          createTextVNode(" " + toDisplayString(unref(bulkDeleteForm).processing ? "Deleting..." : `Delete ${unref(bulkDeleteForm).ids.length} Courses`), 1)
                        ]),
                        _: 1
                      }, 8, ["disabled"])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard/Course/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
