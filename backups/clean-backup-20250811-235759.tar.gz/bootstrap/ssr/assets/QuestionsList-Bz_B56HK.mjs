import { ref, computed, unref, withCtx, createBlock, createTextVNode, openBlock, createVNode, toDisplayString, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$3 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$2 } from "./PrimaryButton-Be3Csrwm.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "QuestionsList",
  __ssrInlineRender: true,
  props: {
    quiz: {
      type: Object,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const showAnswers = ref(false);
    const title = computed(() => `Questions for ${props.quiz.title}`);
    function toggleShowAnswers() {
      showAnswers.value = !showAnswers.value;
    }
    function getQuestionTypeName(typeId) {
      const types = {
        1: "Multiple Choice",
        2: "True/False",
        3: "Short Answer",
        4: "Multiple Select",
        5: "Matching",
        6: "Fill in the Blank"
      };
      return types[typeId] || "Unknown";
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: title.value }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$3, {
              title: title.value,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$3, {
                title: title.value,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="mb-6"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("quizzes.index"),
              class: "inline-flex items-center px-4 py-2 bg-gray-600 dark:bg-gray-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 dark:hover:bg-gray-600 focus:bg-gray-700 dark:focus:bg-gray-600 active:bg-gray-900 dark:active:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId2}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"${_scopeId2}></path></svg> Back to Quizzes List `);
                } else {
                  return [
                    (openBlock(), createBlock("svg", {
                      xmlns: "http://www.w3.org/2000/svg",
                      class: "h-5 w-5 mr-2",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor"
                    }, [
                      createVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        "stroke-width": "2",
                        d: "M10 19l-7-7m0 0l7-7m-7 7h18"
                      })
                    ])),
                    createTextVNode(" Back to Quizzes List ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mb-8"${_scopeId}><h1 class="text-3xl font-bold text-gray-900 dark:text-white mb-2"${_scopeId}>${ssrInterpolate(__props.quiz.title)}</h1><p class="text-gray-600 dark:text-gray-400"${_scopeId}>${ssrInterpolate(__props.quiz.description)}</p></div><div class="mb-6 flex justify-between items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              onClick: toggleShowAnswers,
              class: showAnswers.value ? "bg-gray-600 hover:bg-gray-700" : ""
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(showAnswers.value ? "Hide Correct Answers" : "Show Correct Answers")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(showAnswers.value ? "Hide Correct Answers" : "Show Correct Answers"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="text-gray-600 dark:text-gray-400"${_scopeId}> Total Questions: ${ssrInterpolate(__props.quiz.questions.length)}</div></div>`);
            if (__props.quiz.questions.length > 0) {
              _push2(`<div class="space-y-6"${_scopeId}><!--[-->`);
              ssrRenderList(__props.quiz.questions, (question, index) => {
                _push2(`<div class="p-6 bg-gray-50 dark:bg-slate-700 rounded-lg"${_scopeId}><div class="flex items-start justify-between"${_scopeId}><div${_scopeId}><h4 class="text-lg font-semibold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(index + 1)}. ${ssrInterpolate(question.question_title)}</h4><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId}> Type: ${ssrInterpolate(getQuestionTypeName(question.question_type_id))}</p></div></div><ul class="mt-4 space-y-2"${_scopeId}><!--[-->`);
                ssrRenderList(question.answers, (answer) => {
                  _push2(`<li class="${ssrRenderClass([{
                    "bg-green-50 dark:bg-green-900/20": showAnswers.value && answer.is_correct,
                    "bg-white dark:bg-slate-600": !showAnswers.value || !answer.is_correct
                  }, "flex items-center p-3 rounded-md"])}"${_scopeId}><span class="text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(answer.answer)}</span>`);
                  if (showAnswers.value && answer.is_correct) {
                    _push2(`<span class="ml-2 text-xs font-medium text-green-600 dark:text-green-400"${_scopeId}> (Correct) </span>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</li>`);
                });
                _push2(`<!--]--></ul></div>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<p class="text-gray-600 dark:text-gray-400 text-center py-4"${_scopeId}> No questions added to this quiz yet. </p>`);
            }
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "mb-6" }, [
                        createVNode(unref(Link), {
                          href: _ctx.route("quizzes.index"),
                          class: "inline-flex items-center px-4 py-2 bg-gray-600 dark:bg-gray-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 dark:hover:bg-gray-600 focus:bg-gray-700 dark:focus:bg-gray-600 active:bg-gray-900 dark:active:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150"
                        }, {
                          default: withCtx(() => [
                            (openBlock(), createBlock("svg", {
                              xmlns: "http://www.w3.org/2000/svg",
                              class: "h-5 w-5 mr-2",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M10 19l-7-7m0 0l7-7m-7 7h18"
                              })
                            ])),
                            createTextVNode(" Back to Quizzes List ")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ]),
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("h1", { class: "text-3xl font-bold text-gray-900 dark:text-white mb-2" }, toDisplayString(__props.quiz.title), 1),
                        createVNode("p", { class: "text-gray-600 dark:text-gray-400" }, toDisplayString(__props.quiz.description), 1)
                      ]),
                      createVNode("div", { class: "mb-6 flex justify-between items-center" }, [
                        createVNode(_sfc_main$2, {
                          onClick: toggleShowAnswers,
                          class: showAnswers.value ? "bg-gray-600 hover:bg-gray-700" : ""
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(showAnswers.value ? "Hide Correct Answers" : "Show Correct Answers"), 1)
                          ]),
                          _: 1
                        }, 8, ["class"]),
                        createVNode("div", { class: "text-gray-600 dark:text-gray-400" }, " Total Questions: " + toDisplayString(__props.quiz.questions.length), 1)
                      ]),
                      __props.quiz.questions.length > 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "space-y-6"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.quiz.questions, (question, index) => {
                          return openBlock(), createBlock("div", {
                            key: question.id,
                            class: "p-6 bg-gray-50 dark:bg-slate-700 rounded-lg"
                          }, [
                            createVNode("div", { class: "flex items-start justify-between" }, [
                              createVNode("div", null, [
                                createVNode("h4", { class: "text-lg font-semibold text-gray-900 dark:text-white" }, toDisplayString(index + 1) + ". " + toDisplayString(question.question_title), 1),
                                createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, " Type: " + toDisplayString(getQuestionTypeName(question.question_type_id)), 1)
                              ])
                            ]),
                            createVNode("ul", { class: "mt-4 space-y-2" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(question.answers, (answer) => {
                                return openBlock(), createBlock("li", {
                                  key: answer.id,
                                  class: ["flex items-center p-3 rounded-md", {
                                    "bg-green-50 dark:bg-green-900/20": showAnswers.value && answer.is_correct,
                                    "bg-white dark:bg-slate-600": !showAnswers.value || !answer.is_correct
                                  }]
                                }, [
                                  createVNode("span", { class: "text-gray-900 dark:text-white" }, toDisplayString(answer.answer), 1),
                                  showAnswers.value && answer.is_correct ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "ml-2 text-xs font-medium text-green-600 dark:text-green-400"
                                  }, " (Correct) ")) : createCommentVNode("", true)
                                ], 2);
                              }), 128))
                            ])
                          ]);
                        }), 128))
                      ])) : (openBlock(), createBlock("p", {
                        key: 1,
                        class: "text-gray-600 dark:text-gray-400 text-center py-4"
                      }, " No questions added to this quiz yet. "))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/QuestionsList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
