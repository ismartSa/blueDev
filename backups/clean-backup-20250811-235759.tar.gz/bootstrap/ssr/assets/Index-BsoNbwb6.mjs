import { reactive, computed, watch, unref, withCtx, createTextVNode, createVNode, resolveDynamicComponent, toDisplayString, createBlock, createCommentVNode, openBlock, Fragment, renderList, withDirectives, vModelSelect, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderVNode, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderAttr } from "vue/server-renderer";
import { usePage, router, Head, Link } from "@inertiajs/vue3";
import { debounce, pickBy } from "lodash";
import { AcademicCapIcon, ChartBarIcon, PlusIcon, MagnifyingGlassIcon, FunnelIcon, Squares2X2Icon, ListBulletIcon, TrashIcon, ClockIcon, EyeIcon, PencilIcon } from "@heroicons/vue/24/outline";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$9 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$4 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$3 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$2 } from "./SecondaryButton-DkF3Mn0U.mjs";
import { _ as _sfc_main$6 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$5 } from "./SelectInput-BcLpPrB1.mjs";
import { _ as _sfc_main$7 } from "./Pagination-BcteoMDy.mjs";
import _sfc_main$8 from "./Delete-RhNj5p-n.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./Modal-UKMpWsGi.mjs";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    filters: Object,
    quizzes: Object,
    courses: Array,
    // Add this
    perPage: Number,
    breadcrumbs: Array
  },
  setup(__props) {
    var _a, _b, _c, _d;
    const props = __props;
    const data = reactive({
      params: {
        search: ((_a = props.filters) == null ? void 0 : _a.search) || "",
        course_id: ((_b = props.filters) == null ? void 0 : _b.course_id) || "",
        // Add this
        field: ((_c = props.filters) == null ? void 0 : _c.field) || "",
        order: ((_d = props.filters) == null ? void 0 : _d.order) || "",
        perPage: props.perPage
      },
      selectedId: [],
      deleteOpen: false,
      quizToDelete: null,
      dataSet: usePage().props.app.perpage,
      viewMode: "grid",
      showFilters: false
    });
    const totalQuestions = computed(
      () => {
        var _a2;
        return ((_a2 = props.quizzes.data) == null ? void 0 : _a2.reduce((sum, q) => sum + q.questions_count, 0)) || 0;
      }
    );
    const stats = computed(() => [
      { label: "Total Quizzes", value: props.quizzes.total || 0, icon: AcademicCapIcon, color: "blue" },
      { label: "Questions", value: totalQuestions.value, icon: ChartBarIcon, color: "green" },
      { label: "Active", value: props.quizzes.active || 0, color: "yellow" },
      { label: "Draft", value: props.quizzes.draft || 0, color: "purple" }
    ]);
    const colorClasses = {
      blue: "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400",
      green: "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-600 dark:text-green-400",
      yellow: "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800 text-yellow-600 dark:text-yellow-400",
      purple: "bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800 text-purple-600 dark:text-purple-400"
    };
    const order = (field) => {
      data.params.field = field;
      data.params.order = data.params.order === "asc" ? "desc" : "asc";
    };
    watch(() => data.params, debounce(() => {
      router.get(route("quizzes.index"), pickBy(data.params), {
        replace: true,
        preserveState: true,
        preserveScroll: true
      });
    }, 150));
    const selectAll = (e) => data.selectedId = e.target.checked ? props.quizzes.data.map((q) => q.id) : [];
    const openDeleteModal = (quiz) => {
      data.quizToDelete = quiz;
      data.deleteOpen = true;
    };
    const navigateToCreateQuiz = () => router.visit(route("quizzes.create"));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: __props.title }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$9, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$9, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-6" data-v-a97aa463${_scopeId}><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-v-a97aa463${_scopeId}><div class="bg-white dark:bg-slate-800 shadow rounded-lg p-6 mb-6" data-v-a97aa463${_scopeId}><div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4" data-v-a97aa463${_scopeId}><div data-v-a97aa463${_scopeId}><h1 class="text-2xl font-bold text-gray-900 dark:text-white" data-v-a97aa463${_scopeId}>${ssrInterpolate(__props.title)}</h1><p class="text-gray-600 dark:text-gray-400 mt-1" data-v-a97aa463${_scopeId}>Create, manage, and analyze quiz performance</p></div><div class="flex gap-3" data-v-a97aa463${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Export`);
                } else {
                  return [
                    createTextVNode("Export")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              onClick: navigateToCreateQuiz,
              class: "flex items-center gap-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(PlusIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                  _push3(`Create Quiz `);
                } else {
                  return [
                    createVNode(unref(PlusIcon), { class: "w-4 h-4" }),
                    createTextVNode("Create Quiz ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" data-v-a97aa463${_scopeId}><!--[-->`);
            ssrRenderList(stats.value, (stat) => {
              _push2(`<div class="${ssrRenderClass(`p-4 rounded-lg border ${colorClasses[stat.color]}`)}" data-v-a97aa463${_scopeId}>`);
              if (stat.icon) {
                ssrRenderVNode(_push2, createVNode(resolveDynamicComponent(stat.icon), { class: "w-6 h-6 mb-2" }, null), _parent2, _scopeId);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<h3 class="text-sm font-medium" data-v-a97aa463${_scopeId}>${ssrInterpolate(stat.label)}</h3><p class="text-2xl font-bold" data-v-a97aa463${_scopeId}>${ssrInterpolate(stat.value)}</p></div>`);
            });
            _push2(`<!--]--></div></div><div class="bg-white dark:bg-slate-800 rounded-lg shadow border p-6 mb-6" data-v-a97aa463${_scopeId}><div class="flex flex-col lg:flex-row lg:items-center gap-4" data-v-a97aa463${_scopeId}><div class="flex-1 relative" data-v-a97aa463${_scopeId}>`);
            _push2(ssrRenderComponent(unref(MagnifyingGlassIcon), { class: "absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              modelValue: data.params.search,
              "onUpdate:modelValue": ($event) => data.params.search = $event,
              type: "text",
              class: "pl-12 w-full rounded-lg",
              placeholder: "Search quizzes..."
            }, null, _parent2, _scopeId));
            _push2(`</div><select class="w-48 rounded-lg border-gray-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white focus:border-purple-500 focus:ring-purple-500" data-v-a97aa463${_scopeId}><option value="" data-v-a97aa463${ssrIncludeBooleanAttr(Array.isArray(data.params.course_id) ? ssrLooseContain(data.params.course_id, "") : ssrLooseEqual(data.params.course_id, "")) ? " selected" : ""}${_scopeId}>All Courses</option><!--[-->`);
            ssrRenderList(__props.courses, (course) => {
              _push2(`<option${ssrRenderAttr("value", course.id)} data-v-a97aa463${ssrIncludeBooleanAttr(Array.isArray(data.params.course_id) ? ssrLooseContain(data.params.course_id, course.id) : ssrLooseEqual(data.params.course_id, course.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(course.title)}</option>`);
            });
            _push2(`<!--]--></select><div class="flex items-center gap-3" data-v-a97aa463${_scopeId}><button class="flex items-center px-4 py-2 text-gray-600 border rounded-lg hover:border-purple-300" data-v-a97aa463${_scopeId}>`);
            _push2(ssrRenderComponent(unref(FunnelIcon), { class: "w-4 h-4 mr-2" }, null, _parent2, _scopeId));
            _push2(`Filters </button>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              modelValue: data.params.perPage,
              "onUpdate:modelValue": ($event) => data.params.perPage = $event,
              dataSet: data.dataSet,
              class: "w-20"
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex bg-gray-100 dark:bg-slate-700 rounded-lg p-1" data-v-a97aa463${_scopeId}><button class="${ssrRenderClass([data.viewMode === "grid" ? "bg-white shadow text-purple-600" : "text-gray-500", "p-2 rounded transition-all"])}" data-v-a97aa463${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Squares2X2Icon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
            _push2(`</button><button class="${ssrRenderClass([data.viewMode === "table" ? "bg-white shadow text-purple-600" : "text-gray-500", "p-2 rounded transition-all"])}" data-v-a97aa463${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListBulletIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
            _push2(`</button></div>`);
            if (data.selectedId.length > 0) {
              _push2(ssrRenderComponent(_sfc_main$6, {
                onClick: ($event) => data.deleteOpen = true
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4 mr-2" }, null, _parent3, _scopeId2));
                    _push3(`Delete (${ssrInterpolate(data.selectedId.length)}) `);
                  } else {
                    return [
                      createVNode(unref(TrashIcon), { class: "w-4 h-4 mr-2" }),
                      createTextVNode("Delete (" + toDisplayString(data.selectedId.length) + ") ", 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div>`);
            if (data.viewMode === "grid") {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-6" data-v-a97aa463${_scopeId}><!--[-->`);
              ssrRenderList(__props.quizzes.data, (quiz) => {
                _push2(`<div class="bg-white dark:bg-slate-800 rounded-lg shadow border hover:shadow-lg transition-all" data-v-a97aa463${_scopeId}><div class="p-6" data-v-a97aa463${_scopeId}><div class="flex items-start justify-between mb-4" data-v-a97aa463${_scopeId}><input type="checkbox"${ssrRenderAttr("value", quiz.id)}${ssrIncludeBooleanAttr(Array.isArray(data.selectedId) ? ssrLooseContain(data.selectedId, quiz.id) : data.selectedId) ? " checked" : ""} class="rounded border-gray-300 text-purple-600" data-v-a97aa463${_scopeId}><span class="px-3 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.questions_count)} Questions </span></div><h3 class="text-lg font-bold text-gray-900 dark:text-white mb-2" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.show", quiz.id)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(quiz.title)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(quiz.title), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</h3><p class="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.description || "No description available")}</p><div class="grid grid-cols-2 gap-3 mb-4" data-v-a97aa463${_scopeId}><div class="bg-blue-50 dark:bg-slate-700 rounded-lg p-3" data-v-a97aa463${_scopeId}><div class="flex items-center mb-1" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(ClockIcon), { class: "w-4 h-4 text-blue-500 mr-2" }, null, _parent2, _scopeId));
                _push2(`<span class="text-xs text-gray-600" data-v-a97aa463${_scopeId}>Duration</span></div><p class="font-bold" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.time_limit)}min</p></div><div class="bg-green-50 dark:bg-slate-700 rounded-lg p-3" data-v-a97aa463${_scopeId}><div class="flex items-center mb-1" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(ChartBarIcon), { class: "w-4 h-4 text-green-500 mr-2" }, null, _parent2, _scopeId));
                _push2(`<span class="text-xs text-gray-600" data-v-a97aa463${_scopeId}>Pass Score</span></div><p class="font-bold" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.passing_score)}%</p></div></div><div class="flex items-center justify-between pt-4 border-t" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.show", quiz.id),
                  class: "text-sm font-medium text-purple-600 hover:text-purple-800"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(EyeIcon), { class: "w-4 h-4 mr-1 inline" }, null, _parent3, _scopeId2));
                      _push3(`View `);
                    } else {
                      return [
                        createVNode(unref(EyeIcon), { class: "w-4 h-4 mr-1 inline" }),
                        createTextVNode("View ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<div class="flex space-x-1" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.edit", quiz.id),
                  class: "p-2 text-gray-500 hover:text-purple-600 rounded"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<button class="p-2 text-gray-500 hover:text-red-600 rounded" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
                _push2(`</button></div></div></div></div>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (data.viewMode === "table") {
              _push2(`<div class="bg-white dark:bg-slate-800 rounded-lg shadow overflow-hidden mb-6" data-v-a97aa463${_scopeId}><table class="min-w-full divide-y divide-gray-200 dark:divide-slate-700" data-v-a97aa463${_scopeId}><thead class="bg-gray-50 dark:bg-slate-700" data-v-a97aa463${_scopeId}><tr data-v-a97aa463${_scopeId}><th class="px-6 py-3 text-left" data-v-a97aa463${_scopeId}><input type="checkbox" class="rounded border-gray-300 text-purple-600" data-v-a97aa463${_scopeId}></th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase cursor-pointer" data-v-a97aa463${_scopeId}> Quiz Details </th><th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" data-v-a97aa463${_scopeId}>Course </th><th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" data-v-a97aa463${_scopeId}>Questions</th><th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" data-v-a97aa463${_scopeId}>Duration</th><th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" data-v-a97aa463${_scopeId}>Pass Score</th><th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase cursor-pointer" data-v-a97aa463${_scopeId}> Created </th><th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase" data-v-a97aa463${_scopeId}>Actions</th></tr></thead><tbody class="divide-y divide-gray-200 dark:divide-slate-700" data-v-a97aa463${_scopeId}><!--[-->`);
              ssrRenderList(__props.quizzes.data, (quiz) => {
                _push2(`<tr class="hover:bg-gray-50 dark:hover:bg-slate-700" data-v-a97aa463${_scopeId}><td class="px-6 py-4" data-v-a97aa463${_scopeId}><input type="checkbox"${ssrRenderAttr("value", quiz.id)}${ssrIncludeBooleanAttr(Array.isArray(data.selectedId) ? ssrLooseContain(data.selectedId, quiz.id) : data.selectedId) ? " checked" : ""} class="rounded border-gray-300 text-purple-600" data-v-a97aa463${_scopeId}></td><td class="px-6 py-4" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.show", quiz.id),
                  class: "font-medium text-gray-900 dark:text-white hover:text-purple-600"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(quiz.title)}`);
                    } else {
                      return [
                        createTextVNode(toDisplayString(quiz.title), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<p class="text-sm text-gray-500 line-clamp-1" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.description || "No description")}</p></td><td class="px-6 py-4 text-center" data-v-a97aa463${_scopeId}>`);
                if (quiz.course) {
                  _push2(`<span class="px-3 py-1 rounded-full text-sm bg-indigo-100 text-indigo-800" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.course.title)}</span>`);
                } else {
                  _push2(`<span class="text-gray-400 text-sm" data-v-a97aa463${_scopeId}>No Course</span>`);
                }
                _push2(`</td><td class="px-6 py-4 text-center font-medium" data-v-a97aa463${_scopeId}><span class="px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.questions_count || 0)}</span></td><td class="px-6 py-4 text-center font-medium" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.time_limit)}min</td><td class="px-6 py-4 text-center" data-v-a97aa463${_scopeId}><span class="px-3 py-1 rounded-full text-sm bg-green-100 text-green-800" data-v-a97aa463${_scopeId}>${ssrInterpolate(quiz.passing_score)}%</span></td><td class="px-6 py-4 text-center text-sm text-gray-500" data-v-a97aa463${_scopeId}>${ssrInterpolate(new Date(quiz.created_at).toLocaleDateString())}</td><td class="px-6 py-4 text-right" data-v-a97aa463${_scopeId}><div class="flex items-center justify-end space-x-2" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.show", quiz.id),
                  class: "p-2 text-purple-600 hover:bg-purple-50 rounded"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(EyeIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("quizzes.edit", quiz.id),
                  class: "p-2 text-gray-600 hover:bg-gray-50 rounded"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<button class="p-2 text-red-600 hover:bg-red-50 rounded" data-v-a97aa463${_scopeId}>`);
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
                _push2(`</button></div></td></tr>`);
              });
              _push2(`<!--]--></tbody></table></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.quizzes.data.length === 0) {
              _push2(`<div class="text-center py-12" data-v-a97aa463${_scopeId}><div class="bg-purple-100 dark:bg-slate-700 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center" data-v-a97aa463${_scopeId}>`);
              _push2(ssrRenderComponent(unref(AcademicCapIcon), { class: "w-10 h-10 text-purple-600" }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-xl font-bold text-gray-900 dark:text-white mb-2" data-v-a97aa463${_scopeId}>No quizzes found</h3><p class="text-gray-600 dark:text-gray-400 mb-6" data-v-a97aa463${_scopeId}>Start creating engaging quizzes to test knowledge.</p>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                onClick: navigateToCreateQuiz,
                class: "px-6 py-3"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(PlusIcon), { class: "w-5 h-5 mr-2" }, null, _parent3, _scopeId2));
                    _push3(`Create Your First Quiz `);
                  } else {
                    return [
                      createVNode(unref(PlusIcon), { class: "w-5 h-5 mr-2" }),
                      createTextVNode("Create Your First Quiz ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.quizzes.data.length > 0) {
              _push2(ssrRenderComponent(_sfc_main$7, {
                links: __props.quizzes.links
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              show: data.deleteOpen,
              quiz: data.quizToDelete,
              onClose: ($event) => data.deleteOpen = false
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "py-6" }, [
                createVNode("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 shadow rounded-lg p-6 mb-6" }, [
                    createVNode("div", { class: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4" }, [
                      createVNode("div", null, [
                        createVNode("h1", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, toDisplayString(__props.title), 1),
                        createVNode("p", { class: "text-gray-600 dark:text-gray-400 mt-1" }, "Create, manage, and analyze quiz performance")
                      ]),
                      createVNode("div", { class: "flex gap-3" }, [
                        createVNode(_sfc_main$2, null, {
                          default: withCtx(() => [
                            createTextVNode("Export")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$3, {
                          onClick: navigateToCreateQuiz,
                          class: "flex items-center gap-2"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(PlusIcon), { class: "w-4 h-4" }),
                            createTextVNode("Create Quiz ")
                          ]),
                          _: 1
                        })
                      ])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(stats.value, (stat) => {
                        return openBlock(), createBlock("div", {
                          key: stat.label,
                          class: `p-4 rounded-lg border ${colorClasses[stat.color]}`
                        }, [
                          stat.icon ? (openBlock(), createBlock(resolveDynamicComponent(stat.icon), {
                            key: 0,
                            class: "w-6 h-6 mb-2"
                          })) : createCommentVNode("", true),
                          createVNode("h3", { class: "text-sm font-medium" }, toDisplayString(stat.label), 1),
                          createVNode("p", { class: "text-2xl font-bold" }, toDisplayString(stat.value), 1)
                        ], 2);
                      }), 128))
                    ])
                  ]),
                  createVNode("div", { class: "bg-white dark:bg-slate-800 rounded-lg shadow border p-6 mb-6" }, [
                    createVNode("div", { class: "flex flex-col lg:flex-row lg:items-center gap-4" }, [
                      createVNode("div", { class: "flex-1 relative" }, [
                        createVNode(unref(MagnifyingGlassIcon), { class: "absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" }),
                        createVNode(_sfc_main$4, {
                          modelValue: data.params.search,
                          "onUpdate:modelValue": ($event) => data.params.search = $event,
                          type: "text",
                          class: "pl-12 w-full rounded-lg",
                          placeholder: "Search quizzes..."
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => data.params.course_id = $event,
                        class: "w-48 rounded-lg border-gray-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white focus:border-purple-500 focus:ring-purple-500"
                      }, [
                        createVNode("option", { value: "" }, "All Courses"),
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.courses, (course) => {
                          return openBlock(), createBlock("option", {
                            key: course.id,
                            value: course.id
                          }, toDisplayString(course.title), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, data.params.course_id]
                      ]),
                      createVNode("div", { class: "flex items-center gap-3" }, [
                        createVNode("button", {
                          onClick: ($event) => data.showFilters = !data.showFilters,
                          class: "flex items-center px-4 py-2 text-gray-600 border rounded-lg hover:border-purple-300"
                        }, [
                          createVNode(unref(FunnelIcon), { class: "w-4 h-4 mr-2" }),
                          createTextVNode("Filters ")
                        ], 8, ["onClick"]),
                        createVNode(_sfc_main$5, {
                          modelValue: data.params.perPage,
                          "onUpdate:modelValue": ($event) => data.params.perPage = $event,
                          dataSet: data.dataSet,
                          class: "w-20"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                        createVNode("div", { class: "flex bg-gray-100 dark:bg-slate-700 rounded-lg p-1" }, [
                          createVNode("button", {
                            onClick: ($event) => data.viewMode = "grid",
                            class: [data.viewMode === "grid" ? "bg-white shadow text-purple-600" : "text-gray-500", "p-2 rounded transition-all"]
                          }, [
                            createVNode(unref(Squares2X2Icon), { class: "w-5 h-5" })
                          ], 10, ["onClick"]),
                          createVNode("button", {
                            onClick: ($event) => data.viewMode = "table",
                            class: [data.viewMode === "table" ? "bg-white shadow text-purple-600" : "text-gray-500", "p-2 rounded transition-all"]
                          }, [
                            createVNode(unref(ListBulletIcon), { class: "w-5 h-5" })
                          ], 10, ["onClick"])
                        ]),
                        data.selectedId.length > 0 ? (openBlock(), createBlock(_sfc_main$6, {
                          key: 0,
                          onClick: ($event) => data.deleteOpen = true
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(TrashIcon), { class: "w-4 h-4 mr-2" }),
                            createTextVNode("Delete (" + toDisplayString(data.selectedId.length) + ") ", 1)
                          ]),
                          _: 1
                        }, 8, ["onClick"])) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  data.viewMode === "grid" ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-6"
                  }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.quizzes.data, (quiz) => {
                      return openBlock(), createBlock("div", {
                        key: quiz.id,
                        class: "bg-white dark:bg-slate-800 rounded-lg shadow border hover:shadow-lg transition-all"
                      }, [
                        createVNode("div", { class: "p-6" }, [
                          createVNode("div", { class: "flex items-start justify-between mb-4" }, [
                            withDirectives(createVNode("input", {
                              type: "checkbox",
                              value: quiz.id,
                              "onUpdate:modelValue": ($event) => data.selectedId = $event,
                              class: "rounded border-gray-300 text-purple-600"
                            }, null, 8, ["value", "onUpdate:modelValue"]), [
                              [vModelCheckbox, data.selectedId]
                            ]),
                            createVNode("span", { class: "px-3 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800" }, toDisplayString(quiz.questions_count) + " Questions ", 1)
                          ]),
                          createVNode("h3", { class: "text-lg font-bold text-gray-900 dark:text-white mb-2" }, [
                            createVNode(unref(Link), {
                              href: _ctx.route("quizzes.show", quiz.id)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(quiz.title), 1)
                              ]),
                              _: 2
                            }, 1032, ["href"])
                          ]),
                          createVNode("p", { class: "text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2" }, toDisplayString(quiz.description || "No description available"), 1),
                          createVNode("div", { class: "grid grid-cols-2 gap-3 mb-4" }, [
                            createVNode("div", { class: "bg-blue-50 dark:bg-slate-700 rounded-lg p-3" }, [
                              createVNode("div", { class: "flex items-center mb-1" }, [
                                createVNode(unref(ClockIcon), { class: "w-4 h-4 text-blue-500 mr-2" }),
                                createVNode("span", { class: "text-xs text-gray-600" }, "Duration")
                              ]),
                              createVNode("p", { class: "font-bold" }, toDisplayString(quiz.time_limit) + "min", 1)
                            ]),
                            createVNode("div", { class: "bg-green-50 dark:bg-slate-700 rounded-lg p-3" }, [
                              createVNode("div", { class: "flex items-center mb-1" }, [
                                createVNode(unref(ChartBarIcon), { class: "w-4 h-4 text-green-500 mr-2" }),
                                createVNode("span", { class: "text-xs text-gray-600" }, "Pass Score")
                              ]),
                              createVNode("p", { class: "font-bold" }, toDisplayString(quiz.passing_score) + "%", 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center justify-between pt-4 border-t" }, [
                            createVNode(unref(Link), {
                              href: _ctx.route("quizzes.show", quiz.id),
                              class: "text-sm font-medium text-purple-600 hover:text-purple-800"
                            }, {
                              default: withCtx(() => [
                                createVNode(unref(EyeIcon), { class: "w-4 h-4 mr-1 inline" }),
                                createTextVNode("View ")
                              ]),
                              _: 2
                            }, 1032, ["href"]),
                            createVNode("div", { class: "flex space-x-1" }, [
                              createVNode(unref(Link), {
                                href: _ctx.route("quizzes.edit", quiz.id),
                                class: "p-2 text-gray-500 hover:text-purple-600 rounded"
                              }, {
                                default: withCtx(() => [
                                  createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                                ]),
                                _: 2
                              }, 1032, ["href"]),
                              createVNode("button", {
                                onClick: ($event) => openDeleteModal(quiz),
                                class: "p-2 text-gray-500 hover:text-red-600 rounded"
                              }, [
                                createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                              ], 8, ["onClick"])
                            ])
                          ])
                        ])
                      ]);
                    }), 128))
                  ])) : createCommentVNode("", true),
                  data.viewMode === "table" ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "bg-white dark:bg-slate-800 rounded-lg shadow overflow-hidden mb-6"
                  }, [
                    createVNode("table", { class: "min-w-full divide-y divide-gray-200 dark:divide-slate-700" }, [
                      createVNode("thead", { class: "bg-gray-50 dark:bg-slate-700" }, [
                        createVNode("tr", null, [
                          createVNode("th", { class: "px-6 py-3 text-left" }, [
                            createVNode("input", {
                              type: "checkbox",
                              onChange: selectAll,
                              class: "rounded border-gray-300 text-purple-600"
                            }, null, 32)
                          ]),
                          createVNode("th", {
                            class: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase cursor-pointer",
                            onClick: ($event) => order("title")
                          }, " Quiz Details ", 8, ["onClick"]),
                          createVNode("th", { class: "px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" }, "Course "),
                          createVNode("th", { class: "px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" }, "Questions"),
                          createVNode("th", { class: "px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" }, "Duration"),
                          createVNode("th", { class: "px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase" }, "Pass Score"),
                          createVNode("th", {
                            class: "px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase cursor-pointer",
                            onClick: ($event) => order("created_at")
                          }, " Created ", 8, ["onClick"]),
                          createVNode("th", { class: "px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase" }, "Actions")
                        ])
                      ]),
                      createVNode("tbody", { class: "divide-y divide-gray-200 dark:divide-slate-700" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.quizzes.data, (quiz) => {
                          return openBlock(), createBlock("tr", {
                            key: quiz.id,
                            class: "hover:bg-gray-50 dark:hover:bg-slate-700"
                          }, [
                            createVNode("td", { class: "px-6 py-4" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                value: quiz.id,
                                "onUpdate:modelValue": ($event) => data.selectedId = $event,
                                class: "rounded border-gray-300 text-purple-600"
                              }, null, 8, ["value", "onUpdate:modelValue"]), [
                                [vModelCheckbox, data.selectedId]
                              ])
                            ]),
                            createVNode("td", { class: "px-6 py-4" }, [
                              createVNode(unref(Link), {
                                href: _ctx.route("quizzes.show", quiz.id),
                                class: "font-medium text-gray-900 dark:text-white hover:text-purple-600"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(quiz.title), 1)
                                ]),
                                _: 2
                              }, 1032, ["href"]),
                              createVNode("p", { class: "text-sm text-gray-500 line-clamp-1" }, toDisplayString(quiz.description || "No description"), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 text-center" }, [
                              quiz.course ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "px-3 py-1 rounded-full text-sm bg-indigo-100 text-indigo-800"
                              }, toDisplayString(quiz.course.title), 1)) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "text-gray-400 text-sm"
                              }, "No Course"))
                            ]),
                            createVNode("td", { class: "px-6 py-4 text-center font-medium" }, [
                              createVNode("span", { class: "px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800" }, toDisplayString(quiz.questions_count || 0), 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 text-center font-medium" }, toDisplayString(quiz.time_limit) + "min", 1),
                            createVNode("td", { class: "px-6 py-4 text-center" }, [
                              createVNode("span", { class: "px-3 py-1 rounded-full text-sm bg-green-100 text-green-800" }, toDisplayString(quiz.passing_score) + "%", 1)
                            ]),
                            createVNode("td", { class: "px-6 py-4 text-center text-sm text-gray-500" }, toDisplayString(new Date(quiz.created_at).toLocaleDateString()), 1),
                            createVNode("td", { class: "px-6 py-4 text-right" }, [
                              createVNode("div", { class: "flex items-center justify-end space-x-2" }, [
                                createVNode(unref(Link), {
                                  href: _ctx.route("quizzes.show", quiz.id),
                                  class: "p-2 text-purple-600 hover:bg-purple-50 rounded"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                                  ]),
                                  _: 2
                                }, 1032, ["href"]),
                                createVNode(unref(Link), {
                                  href: _ctx.route("quizzes.edit", quiz.id),
                                  class: "p-2 text-gray-600 hover:bg-gray-50 rounded"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                                  ]),
                                  _: 2
                                }, 1032, ["href"]),
                                createVNode("button", {
                                  onClick: ($event) => openDeleteModal(quiz),
                                  class: "p-2 text-red-600 hover:bg-red-50 rounded"
                                }, [
                                  createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                                ], 8, ["onClick"])
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ])) : createCommentVNode("", true),
                  __props.quizzes.data.length === 0 ? (openBlock(), createBlock("div", {
                    key: 2,
                    class: "text-center py-12"
                  }, [
                    createVNode("div", { class: "bg-purple-100 dark:bg-slate-700 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center" }, [
                      createVNode(unref(AcademicCapIcon), { class: "w-10 h-10 text-purple-600" })
                    ]),
                    createVNode("h3", { class: "text-xl font-bold text-gray-900 dark:text-white mb-2" }, "No quizzes found"),
                    createVNode("p", { class: "text-gray-600 dark:text-gray-400 mb-6" }, "Start creating engaging quizzes to test knowledge."),
                    createVNode(_sfc_main$3, {
                      onClick: navigateToCreateQuiz,
                      class: "px-6 py-3"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(PlusIcon), { class: "w-5 h-5 mr-2" }),
                        createTextVNode("Create Your First Quiz ")
                      ]),
                      _: 1
                    })
                  ])) : createCommentVNode("", true),
                  __props.quizzes.data.length > 0 ? (openBlock(), createBlock(_sfc_main$7, {
                    key: 3,
                    links: __props.quizzes.links
                  }, null, 8, ["links"])) : createCommentVNode("", true)
                ])
              ]),
              createVNode(_sfc_main$8, {
                show: data.deleteOpen,
                quiz: data.quizToDelete,
                onClose: ($event) => data.deleteOpen = false
              }, null, 8, ["show", "quiz", "onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a97aa463"]]);
export {
  Index as default
};
