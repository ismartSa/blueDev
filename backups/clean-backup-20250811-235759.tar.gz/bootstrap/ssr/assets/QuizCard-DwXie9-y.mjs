import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { DocumentTextIcon, ClockIcon, CheckCircleIcon } from "@heroicons/vue/24/outline";
const _sfc_main = {
  __name: "QuizCard",
  __ssrInlineRender: true,
  props: {
    quiz: {
      type: Object,
      required: true
    },
    isSelected: {
      type: Boolean,
      default: false
    }
  },
  emits: ["selected"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["quiz-card p-4 rounded-lg border transition-all cursor-pointer", {
          "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/50": __props.isSelected,
          "border-gray-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500": !__props.isSelected
        }]
      }, _attrs))}><div class="flex items-center space-x-3"><div class="flex-shrink-0 bg-indigo-100 dark:bg-indigo-900/50 p-2 rounded-full">`);
      _push(ssrRenderComponent(unref(DocumentTextIcon), { class: "h-5 w-5 text-indigo-600 dark:text-indigo-400" }, null, _parent));
      _push(`</div><div class="min-w-0"><h3 class="text-sm font-medium text-gray-900 dark:text-white truncate">${ssrInterpolate(__props.quiz.title)}</h3><p class="text-sm text-gray-500 dark:text-gray-400">${ssrInterpolate(__props.quiz.questions_count)} questions</p></div></div><div class="mt-2 flex justify-between text-xs text-gray-500 dark:text-gray-400"><span class="flex items-center">`);
      _push(ssrRenderComponent(unref(ClockIcon), { class: "h-4 w-4 mr-1" }, null, _parent));
      _push(` Time: ${ssrInterpolate(__props.quiz.time_limit)} minutes </span><span class="flex items-center">`);
      _push(ssrRenderComponent(unref(CheckCircleIcon), { class: "h-4 w-4 mr-1" }, null, _parent));
      _push(` Passing Score: ${ssrInterpolate(__props.quiz.passing_score)}% </span></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Components/QuizCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
