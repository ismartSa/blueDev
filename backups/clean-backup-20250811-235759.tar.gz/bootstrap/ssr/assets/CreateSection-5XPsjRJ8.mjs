import { ref, withCtx, unref, createVNode, createBlock, createCommentVNode, toDisplayString, withModifiers, withDirectives, vModelText, openBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "CreateSection",
  __ssrInlineRender: true,
  props: {
    course: Object,
    sections: Array
  },
  setup(__props) {
    const props = __props;
    const sectionForm = useForm({
      title: "",
      description: "",
      order: 1,
      course_id: props.course.id
    });
    const showEditModal = ref(false);
    const currentSectionId = ref(null);
    const editSectionForm = useForm({
      title: "",
      description: "",
      order: 1
    });
    const submitSection = () => {
      sectionForm.post(route("courses.sections.store", { course: props.course.id }), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {
          sectionForm.reset();
          sectionForm.order = props.sections.length + 1;
        }
      });
    };
    const editSection = (section) => {
      currentSectionId.value = section.id;
      editSectionForm.title = section.title;
      editSectionForm.description = section.description;
      editSectionForm.order = section.order;
      showEditModal.value = true;
    };
    const updateSection = () => {
      editSectionForm.put(route("courses.sections.update", { course: props.course.id, section: currentSectionId.value }), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {
          showEditModal.value = false;
        }
      });
    };
    const deleteSection = (sectionId) => {
      if (confirm("هل أنت متأكد من حذف هذا القسم؟")) {
        useForm().delete(route("courses.sections.destroy", { course: props.course.id, section: sectionId }), {
          preserveState: true,
          preserveScroll: true
        });
      }
    };
    const goToCourse = () => {
      window.location.href = route("courses.details", { id: props.course.id, courseSlug: props.course.slug });
    };
    const goToLectures = () => {
      window.location.href = route("courses.lectures.create", { course: props.course.id });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.add_sections"))} - ${ssrInterpolate(__props.course.title)}</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, toDisplayString(_ctx.$t("sections.add_sections")) + " - " + toDisplayString(__props.course.title), 1)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.add_new_section"))}</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.title"))}:</label><input id="title"${ssrRenderAttr("value", unref(sectionForm).title)} type="text" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(sectionForm).errors.title) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(sectionForm).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.description"))}:</label><textarea id="description" class="form-textarea w-full rounded-md shadow-sm" rows="3" required${_scopeId}>${ssrInterpolate(unref(sectionForm).description)}</textarea>`);
            if (unref(sectionForm).errors.description) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(sectionForm).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="order" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.order"))}:</label><input id="order"${ssrRenderAttr("value", unref(sectionForm).order)} type="number" min="1" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(sectionForm).errors.order) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(sectionForm).errors.order)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex justify-end"${_scopeId}><button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${ssrIncludeBooleanAttr(unref(sectionForm).processing) ? " disabled" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("sections.add_section"))}</button></div></form></div></div><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.current_sections"))}</h3>`);
            if (__props.sections.length === 0) {
              _push2(`<div class="text-gray-500 text-center py-4"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.no_sections_yet"))}</div>`);
            } else {
              _push2(`<div class="space-y-4"${_scopeId}><!--[-->`);
              ssrRenderList(__props.sections, (section) => {
                _push2(`<div class="border rounded-md p-4"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div${_scopeId}><h4 class="font-semibold"${_scopeId}>${ssrInterpolate(section.title)}</h4><p class="text-sm text-gray-600"${_scopeId}>${ssrInterpolate(section.description)}</p><p class="text-xs text-gray-500"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.order"))}: ${ssrInterpolate(section.order)}</p></div><div class="flex space-x-2"${_scopeId}><button class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.edit"))}</button><button class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.delete"))}</button></div></div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`<div class="mt-6 flex justify-between"${_scopeId}><button class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.back_to_course"))}</button><button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.continue_to_lectures"))}</button></div></div></div></div></div>`);
            if (showEditModal.value) {
              _push2(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"${_scopeId}><div class="bg-white rounded-lg p-6 w-full max-w-md"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.edit_section"))}</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label for="edit-title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.title"))}:</label><input id="edit-title"${ssrRenderAttr("value", unref(editSectionForm).title)} type="text" class="form-input w-full rounded-md shadow-sm" required${_scopeId}></div><div class="mb-4"${_scopeId}><label for="edit-description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.description"))}:</label><textarea id="edit-description" class="form-textarea w-full rounded-md shadow-sm" rows="3" required${_scopeId}>${ssrInterpolate(unref(editSectionForm).description)}</textarea></div><div class="mb-4"${_scopeId}><label for="edit-order" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.order"))}:</label><input id="edit-order"${ssrRenderAttr("value", unref(editSectionForm).order)} type="number" min="1" class="form-input w-full rounded-md shadow-sm" required${_scopeId}></div><div class="flex justify-end space-x-2"${_scopeId}><button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.cancel"))}</button><button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("sections.update"))}</button></div></form></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("sections.add_new_section")), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(submitSection, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "title",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("sections.title")) + ":", 1),
                          withDirectives(createVNode("input", {
                            id: "title",
                            "onUpdate:modelValue": ($event) => unref(sectionForm).title = $event,
                            type: "text",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(sectionForm).title]
                          ]),
                          unref(sectionForm).errors.title ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(sectionForm).errors.title), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "description",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("sections.description")) + ":", 1),
                          withDirectives(createVNode("textarea", {
                            id: "description",
                            "onUpdate:modelValue": ($event) => unref(sectionForm).description = $event,
                            class: "form-textarea w-full rounded-md shadow-sm",
                            rows: "3",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(sectionForm).description]
                          ]),
                          unref(sectionForm).errors.description ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(sectionForm).errors.description), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "order",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("sections.order")) + ":", 1),
                          withDirectives(createVNode("input", {
                            id: "order",
                            "onUpdate:modelValue": ($event) => unref(sectionForm).order = $event,
                            type: "number",
                            min: "1",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(sectionForm).order]
                          ]),
                          unref(sectionForm).errors.order ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(sectionForm).errors.order), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode("button", {
                            type: "submit",
                            class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                            disabled: unref(sectionForm).processing
                          }, toDisplayString(_ctx.$t("sections.add_section")), 9, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ]),
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("sections.current_sections")), 1),
                      __props.sections.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-gray-500 text-center py-4"
                      }, toDisplayString(_ctx.$t("sections.no_sections_yet")), 1)) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "space-y-4"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                          return openBlock(), createBlock("div", {
                            key: section.id,
                            class: "border rounded-md p-4"
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("div", null, [
                                createVNode("h4", { class: "font-semibold" }, toDisplayString(section.title), 1),
                                createVNode("p", { class: "text-sm text-gray-600" }, toDisplayString(section.description), 1),
                                createVNode("p", { class: "text-xs text-gray-500" }, toDisplayString(_ctx.$t("sections.order")) + ": " + toDisplayString(section.order), 1)
                              ]),
                              createVNode("div", { class: "flex space-x-2" }, [
                                createVNode("button", {
                                  onClick: ($event) => editSection(section),
                                  class: "bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md text-sm"
                                }, toDisplayString(_ctx.$t("sections.edit")), 9, ["onClick"]),
                                createVNode("button", {
                                  onClick: ($event) => deleteSection(section.id),
                                  class: "bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                                }, toDisplayString(_ctx.$t("sections.delete")), 9, ["onClick"])
                              ])
                            ])
                          ]);
                        }), 128))
                      ])),
                      createVNode("div", { class: "mt-6 flex justify-between" }, [
                        createVNode("button", {
                          onClick: goToCourse,
                          class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        }, toDisplayString(_ctx.$t("sections.back_to_course")), 1),
                        createVNode("button", {
                          onClick: goToLectures,
                          class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        }, toDisplayString(_ctx.$t("sections.continue_to_lectures")), 1)
                      ])
                    ])
                  ])
                ])
              ]),
              showEditModal.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
              }, [
                createVNode("div", { class: "bg-white rounded-lg p-6 w-full max-w-md" }, [
                  createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("sections.edit_section")), 1),
                  createVNode("form", {
                    onSubmit: withModifiers(updateSection, ["prevent"])
                  }, [
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "edit-title",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, toDisplayString(_ctx.$t("sections.title")) + ":", 1),
                      withDirectives(createVNode("input", {
                        id: "edit-title",
                        "onUpdate:modelValue": ($event) => unref(editSectionForm).title = $event,
                        type: "text",
                        class: "form-input w-full rounded-md shadow-sm",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(editSectionForm).title]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "edit-description",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, toDisplayString(_ctx.$t("sections.description")) + ":", 1),
                      withDirectives(createVNode("textarea", {
                        id: "edit-description",
                        "onUpdate:modelValue": ($event) => unref(editSectionForm).description = $event,
                        class: "form-textarea w-full rounded-md shadow-sm",
                        rows: "3",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(editSectionForm).description]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "edit-order",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, toDisplayString(_ctx.$t("sections.order")) + ":", 1),
                      withDirectives(createVNode("input", {
                        id: "edit-order",
                        "onUpdate:modelValue": ($event) => unref(editSectionForm).order = $event,
                        type: "number",
                        min: "1",
                        class: "form-input w-full rounded-md shadow-sm",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(editSectionForm).order]
                      ])
                    ]),
                    createVNode("div", { class: "flex justify-end space-x-2" }, [
                      createVNode("button", {
                        type: "button",
                        onClick: ($event) => showEditModal.value = false,
                        class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      }, toDisplayString(_ctx.$t("sections.cancel")), 9, ["onClick"]),
                      createVNode("button", {
                        type: "submit",
                        class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      }, toDisplayString(_ctx.$t("sections.update")), 1)
                    ])
                  ], 32)
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/CreateSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
