import { mergeProps, withCtx, createTextVNode, unref, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$3 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$2 } from "./SecondaryButton-DkF3Mn0U.mjs";
const _sfc_main = {
  __name: "Delete",
  __ssrInlineRender: true,
  props: {
    show: {
      type: Boolean,
      required: true
    },
    quiz: {
      type: Object,
      required: true
    }
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({});
    const close = () => {
      emit("close");
    };
    const submit = () => {
      var _a;
      if (!((_a = props.quiz) == null ? void 0 : _a.id)) {
        console.error("Quiz ID is missing");
        return;
      }
      form.delete(route("quizzes.destroy", props.quiz.id), {
        preserveScroll: true,
        preserveState: false,
        onSuccess: () => close()
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        show: __props.show,
        onClose: close
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Delete Quiz </h2><p class="mt-1 text-sm text-gray-600 dark:text-gray-400"${_scopeId}> Are you sure you want to delete &quot;${ssrInterpolate(__props.quiz.title)}&quot;? This action cannot be undone. </p><div class="mt-6 flex justify-end space-x-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, { onClick: close }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              onClick: submit,
              class: { "opacity-25": unref(form).processing },
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Delete Quiz `);
                } else {
                  return [
                    createTextVNode(" Delete Quiz ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Delete Quiz "),
                createVNode("p", { class: "mt-1 text-sm text-gray-600 dark:text-gray-400" }, ' Are you sure you want to delete "' + toDisplayString(__props.quiz.title) + '"? This action cannot be undone. ', 1),
                createVNode("div", { class: "mt-6 flex justify-end space-x-3" }, [
                  createVNode(_sfc_main$2, { onClick: close }, {
                    default: withCtx(() => [
                      createTextVNode(" Cancel ")
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$3, {
                    onClick: submit,
                    class: { "opacity-25": unref(form).processing },
                    disabled: unref(form).processing
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Delete Quiz ")
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Delete.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
