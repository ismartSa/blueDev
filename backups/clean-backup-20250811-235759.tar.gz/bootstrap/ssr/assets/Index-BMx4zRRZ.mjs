import { ref, computed, watch, resolveComponent, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { router, usePage } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import axios from "axios";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    course: Object,
    sections: Array,
    lectures: Array,
    firstLecture: Object,
    breadcrumbs: Array,
    completionPercentage: Number
  },
  setup(__props) {
    const props = __props;
    ref({});
    const currentLecture = computed(() => {
      return {
        id: props.firstLecture.id,
        title: props.firstLecture.title,
        video_url: props.firstLecture.video_url,
        previous_lecture_id: props.firstLecture.previous_lecture_id,
        next_lecture_id: props.firstLecture.next_lecture_id,
        completed: props.firstLecture.completed
      };
    });
    watch(() => props.firstLecture, (newVal) => {
      if (newVal.id !== currentLecture.value.id) {
        updateLecture(newVal);
      }
    });
    function updateLecture(lecture) {
      currentLecture.value = {
        id: lecture.id,
        video_url: lecture.video_url,
        previous_lecture_id: lecture.previous_lecture_id,
        next_lecture_id: lecture.next_lecture_id,
        completed: lecture.completed
      };
    }
    function onVideoEnded() {
      axios.post("/lectures/mark-completed", {
        lecture_id: currentLecture.value.id
      }).then(() => {
        if (currentLecture.value.next_lecture_id) {
          router.push({
            path: `/courses/${props.course.id}/player/${props.course.slug}/watch/${currentLecture.value.next_lecture_id}`,
            // إضافة تأثير سلس للانتقال
            onComplete: () => {
              window.scrollTo({ top: 0, behavior: "smooth" });
            }
          });
        } else {
          usePage().props.flash.success = "تهانينا! لقد أكملت جميع محاضرات هذه الدورة";
        }
      }).catch((error) => {
        console.error("Error marking lecture as completed:", error);
        usePage().props.flash.error = "حدث خطأ أثناء حفظ تقدمك، يرجى المحاولة مرة أخرى";
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ProgressBar = resolveComponent("ProgressBar");
      const _component_VideoPlayer = resolveComponent("VideoPlayer");
      const _component_NavigationButtons = resolveComponent("NavigationButtons");
      const _component_CourseContentAccordion = resolveComponent("CourseContentAccordion");
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${ssrRenderAttr("dir", _ctx.page.props.locale === "ar" ? "rtl" : "ltr")}${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="mb-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_ProgressBar, { percentage: __props.completionPercentage }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"${_scopeId}><div class="lg:col-span-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VideoPlayer, {
              src: currentLecture.value.video_url,
              title: currentLecture.value.title,
              onEnded: onVideoEnded
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_NavigationButtons, {
              previous: currentLecture.value.previous_lecture_id,
              next: currentLecture.value.next_lecture_id,
              course: __props.course
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="lg:col-span-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CourseContentAccordion, {
              sections: __props.sections,
              lectures: __props.lectures,
              course: __props.course
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", {
                dir: _ctx.page.props.locale === "ar" ? "rtl" : "ltr"
              }, [
                createVNode(_sfc_main$2, {
                  title: __props.title,
                  breadcrumbs: __props.breadcrumbs
                }, null, 8, ["title", "breadcrumbs"]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode(_component_ProgressBar, { percentage: __props.completionPercentage }, null, 8, ["percentage"])
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-6" }, [
                  createVNode("div", { class: "lg:col-span-2" }, [
                    createVNode(_component_VideoPlayer, {
                      src: currentLecture.value.video_url,
                      title: currentLecture.value.title,
                      onEnded: onVideoEnded
                    }, null, 8, ["src", "title"]),
                    createVNode(_component_NavigationButtons, {
                      previous: currentLecture.value.previous_lecture_id,
                      next: currentLecture.value.next_lecture_id,
                      course: __props.course
                    }, null, 8, ["previous", "next", "course"])
                  ]),
                  createVNode("div", { class: "lg:col-span-1" }, [
                    createVNode(_component_CourseContentAccordion, {
                      sections: __props.sections,
                      lectures: __props.lectures,
                      course: __props.course
                    }, null, 8, ["sections", "lectures", "course"])
                  ])
                ])
              ], 8, ["dir"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Player/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
