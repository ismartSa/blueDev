import { mergeProps, useSSRContext, watchEffect, withCtx, unref, createVNode, createBlock, openBlock, Fragment, renderList, toDisplayString, createTextVNode, withModifiers, withDirectives, vModelCheckbox } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$3 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$5 } from "./InputError-C7WpniWA.mjs";
import { _ as _sfc_main$4 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$7 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$6 } from "./SecondaryButton-DkF3Mn0U.mjs";
const _sfc_main$1 = {
  __name: "Select",
  __ssrInlineRender: true,
  props: {
    modelValue: [String, Number],
    options: {
      type: Array,
      required: true
      // [{ value: '1', label: 'Option 1' }, ...]
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<select${ssrRenderAttrs(mergeProps({
        value: __props.modelValue,
        class: "block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
      }, _attrs))}><!--[-->`);
      ssrRenderList(__props.options, (option) => {
        _push(`<option${ssrRenderAttr("value", option.value)}>${ssrInterpolate(option.label)}</option>`);
      });
      _push(`<!--]--></select>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Select.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    show: {
      type: Boolean,
      required: true
    },
    quiz: {
      type: Object,
      required: true
    },
    courses: {
      type: Array,
      required: true
    },
    sections: {
      type: Array,
      required: true
    }
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({
      title: "",
      description: "",
      time_limit: "",
      passing_score: "",
      course_id: "",
      section_id: "",
      allow_retake: true,
      show_correct_answers: true,
      randomize_questions: false
    });
    const update = () => {
      form.put(route("quizzes.update", props.quiz.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
        }
      });
    };
    watchEffect(() => {
      if (props.show && props.quiz) {
        form.errors = {};
        form.title = props.quiz.title;
        form.description = props.quiz.description;
        form.time_limit = props.quiz.time_limit;
        form.passing_score = props.quiz.passing_score;
        form.course_id = props.quiz.course_id;
        form.section_id = props.quiz.section_id;
        form.allow_retake = props.quiz.allow_retake;
        form.show_correct_answers = props.quiz.show_correct_answers;
        form.randomize_questions = props.quiz.randomize_questions;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$2, mergeProps({
        show: __props.show,
        onClose: ($event) => emit("close")
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Edit Quiz </h2><div class="mt-6 space-y-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "title",
              value: "Quiz Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              id: "title",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.title,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              id: "description",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event,
              type: "textarea",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "time_limit",
              value: "Time Limit (minutes)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              id: "time_limit",
              modelValue: unref(form).time_limit,
              "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
              type: "number",
              min: "1",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.time_limit,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "passing_score",
              value: "Passing Score (%)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              id: "passing_score",
              modelValue: unref(form).passing_score,
              "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
              type: "number",
              min: "0",
              max: "100",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.passing_score,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "course_id",
              value: "Course"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              id: "course_id",
              modelValue: unref(form).course_id,
              "onUpdate:modelValue": ($event) => unref(form).course_id = $event,
              class: "mt-1 block w-full",
              required: ""
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option value=""${_scopeId2}>Select a course</option><!--[-->`);
                  ssrRenderList(__props.courses, (course) => {
                    _push3(`<option${ssrRenderAttr("value", course.id)}${_scopeId2}>${ssrInterpolate(course.title)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", { value: "" }, "Select a course"),
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.courses, (course) => {
                      return openBlock(), createBlock("option", {
                        key: course.id,
                        value: course.id
                      }, toDisplayString(course.title), 9, ["value"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.course_id,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "section_id",
              value: "Section"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              id: "section_id",
              modelValue: unref(form).section_id,
              "onUpdate:modelValue": ($event) => unref(form).section_id = $event,
              class: "mt-1 block w-full"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option value=""${_scopeId2}>Select a section (optional)</option><!--[-->`);
                  ssrRenderList(__props.sections, (section) => {
                    _push3(`<option${ssrRenderAttr("value", section.id)}${_scopeId2}>${ssrInterpolate(section.title)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", { value: "" }, "Select a section (optional)"),
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                      return openBlock(), createBlock("option", {
                        key: section.id,
                        value: section.id
                      }, toDisplayString(section.title), 9, ["value"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              message: unref(form).errors.section_id,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="space-y-4"${_scopeId}><div class="flex items-center"${_scopeId}><input id="allow_retake"${ssrIncludeBooleanAttr(Array.isArray(unref(form).allow_retake) ? ssrLooseContain(unref(form).allow_retake, null) : unref(form).allow_retake) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "allow_retake",
              value: "Allow Retake",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center"${_scopeId}><input id="show_correct_answers"${ssrIncludeBooleanAttr(Array.isArray(unref(form).show_correct_answers) ? ssrLooseContain(unref(form).show_correct_answers, null) : unref(form).show_correct_answers) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "show_correct_answers",
              value: "Show Correct Answers After Submission",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center"${_scopeId}><input id="randomize_questions"${ssrIncludeBooleanAttr(Array.isArray(unref(form).randomize_questions) ? ssrLooseContain(unref(form).randomize_questions, null) : unref(form).randomize_questions) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              for: "randomize_questions",
              value: "Randomize Questions",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div class="mt-6 flex justify-end space-x-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              onClick: ($event) => emit("close"),
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              onClick: update,
              disabled: unref(form).processing,
              class: { "opacity-25": unref(form).processing }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? "Saving..." : "Save Changes")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? "Saving..." : "Save Changes"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(update, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Edit Quiz "),
                createVNode("div", { class: "mt-6 space-y-6" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$3, {
                      for: "title",
                      value: "Quiz Title"
                    }),
                    createVNode(_sfc_main$4, {
                      id: "title",
                      modelValue: unref(form).title,
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$5, {
                      message: unref(form).errors.title,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$3, {
                      for: "description",
                      value: "Description"
                    }),
                    createVNode(_sfc_main$4, {
                      id: "description",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      type: "textarea",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$5, {
                      message: unref(form).errors.description,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                    createVNode("div", null, [
                      createVNode(_sfc_main$3, {
                        for: "time_limit",
                        value: "Time Limit (minutes)"
                      }),
                      createVNode(_sfc_main$4, {
                        id: "time_limit",
                        modelValue: unref(form).time_limit,
                        "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
                        type: "number",
                        min: "1",
                        class: "mt-1 block w-full",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$5, {
                        message: unref(form).errors.time_limit,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", null, [
                      createVNode(_sfc_main$3, {
                        for: "passing_score",
                        value: "Passing Score (%)"
                      }),
                      createVNode(_sfc_main$4, {
                        id: "passing_score",
                        modelValue: unref(form).passing_score,
                        "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
                        type: "number",
                        min: "0",
                        max: "100",
                        class: "mt-1 block w-full",
                        required: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$5, {
                        message: unref(form).errors.passing_score,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                    createVNode("div", null, [
                      createVNode(_sfc_main$3, {
                        for: "course_id",
                        value: "Course"
                      }),
                      createVNode(_sfc_main$1, {
                        id: "course_id",
                        modelValue: unref(form).course_id,
                        "onUpdate:modelValue": ($event) => unref(form).course_id = $event,
                        class: "mt-1 block w-full",
                        required: ""
                      }, {
                        default: withCtx(() => [
                          createVNode("option", { value: "" }, "Select a course"),
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.courses, (course) => {
                            return openBlock(), createBlock("option", {
                              key: course.id,
                              value: course.id
                            }, toDisplayString(course.title), 9, ["value"]);
                          }), 128))
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$5, {
                        message: unref(form).errors.course_id,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ]),
                    createVNode("div", null, [
                      createVNode(_sfc_main$3, {
                        for: "section_id",
                        value: "Section"
                      }),
                      createVNode(_sfc_main$1, {
                        id: "section_id",
                        modelValue: unref(form).section_id,
                        "onUpdate:modelValue": ($event) => unref(form).section_id = $event,
                        class: "mt-1 block w-full"
                      }, {
                        default: withCtx(() => [
                          createVNode("option", { value: "" }, "Select a section (optional)"),
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                            return openBlock(), createBlock("option", {
                              key: section.id,
                              value: section.id
                            }, toDisplayString(section.title), 9, ["value"]);
                          }), 128))
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_sfc_main$5, {
                        message: unref(form).errors.section_id,
                        class: "mt-2"
                      }, null, 8, ["message"])
                    ])
                  ]),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode("div", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        id: "allow_retake",
                        "onUpdate:modelValue": ($event) => unref(form).allow_retake = $event,
                        type: "checkbox",
                        class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).allow_retake]
                      ]),
                      createVNode(_sfc_main$3, {
                        for: "allow_retake",
                        value: "Allow Retake",
                        class: "ml-2"
                      })
                    ]),
                    createVNode("div", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        id: "show_correct_answers",
                        "onUpdate:modelValue": ($event) => unref(form).show_correct_answers = $event,
                        type: "checkbox",
                        class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).show_correct_answers]
                      ]),
                      createVNode(_sfc_main$3, {
                        for: "show_correct_answers",
                        value: "Show Correct Answers After Submission",
                        class: "ml-2"
                      })
                    ]),
                    createVNode("div", { class: "flex items-center" }, [
                      withDirectives(createVNode("input", {
                        id: "randomize_questions",
                        "onUpdate:modelValue": ($event) => unref(form).randomize_questions = $event,
                        type: "checkbox",
                        class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(form).randomize_questions]
                      ]),
                      createVNode(_sfc_main$3, {
                        for: "randomize_questions",
                        value: "Randomize Questions",
                        class: "ml-2"
                      })
                    ])
                  ])
                ]),
                createVNode("div", { class: "mt-6 flex justify-end space-x-3" }, [
                  createVNode(_sfc_main$6, {
                    onClick: ($event) => emit("close"),
                    disabled: unref(form).processing
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Cancel ")
                    ]),
                    _: 1
                  }, 8, ["onClick", "disabled"]),
                  createVNode(_sfc_main$7, {
                    onClick: update,
                    disabled: unref(form).processing,
                    class: { "opacity-25": unref(form).processing }
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? "Saving..." : "Save Changes"), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "class"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
