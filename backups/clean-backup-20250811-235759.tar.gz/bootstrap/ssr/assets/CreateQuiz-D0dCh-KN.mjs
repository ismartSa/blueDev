import { unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$6 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$4 } from "./InputError-C7WpniWA.mjs";
import { _ as _sfc_main$2 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$3 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$5 } from "./PrimaryButton-Be3Csrwm.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "CreateQuiz",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      required: true
    },
    breadcrumbs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      title: "",
      description: "",
      time_limit: 10,
      passing_score: 70,
      course_id: props.course.id
    });
    const submitForm = () => {
      form.post(route("quizzes.store"), {
        onSuccess: () => {
          form.reset();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Create Quiz - ${__props.course.title}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$6, {
              title: `Create Quiz - ${__props.course.title}`,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$6, {
                title: `Create Quiz - ${__props.course.title}`,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><form${_scopeId}><div class="mb-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title",
              value: "Quiz Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "title",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              message: unref(form).errors.title,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mb-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(`<textarea id="description" class="mt-1 block w-full border-gray-300 dark:border-slate-700 dark:bg-slate-900 dark:text-white focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" rows="3"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "time_limit",
              value: "Time Limit (minutes)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "time_limit",
              modelValue: unref(form).time_limit,
              "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
              modelModifiers: { number: true },
              type: "number",
              min: "1",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              message: unref(form).errors.time_limit,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "passing_score",
              value: "Passing Score (%)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "passing_score",
              modelValue: unref(form).passing_score,
              "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
              modelModifiers: { number: true },
              type: "number",
              min: "1",
              max: "100",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              message: unref(form).errors.passing_score,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              class: { "opacity-25": unref(form).processing },
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Create Quiz `);
                } else {
                  return [
                    createTextVNode(" Create Quiz ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-4" }, [
                          createVNode(_sfc_main$2, {
                            for: "title",
                            value: "Quiz Title"
                          }),
                          createVNode(_sfc_main$3, {
                            id: "title",
                            modelValue: unref(form).title,
                            "onUpdate:modelValue": ($event) => unref(form).title = $event,
                            type: "text",
                            class: "mt-1 block w-full",
                            required: "",
                            autofocus: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_sfc_main$4, {
                            message: unref(form).errors.title,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode(_sfc_main$2, {
                            for: "description",
                            value: "Description"
                          }),
                          withDirectives(createVNode("textarea", {
                            id: "description",
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            class: "mt-1 block w-full border-gray-300 dark:border-slate-700 dark:bg-slate-900 dark:text-white focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm",
                            rows: "3"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).description]
                          ]),
                          createVNode(_sfc_main$4, {
                            message: unref(form).errors.description,
                            class: "mt-2"
                          }, null, 8, ["message"])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4" }, [
                          createVNode("div", null, [
                            createVNode(_sfc_main$2, {
                              for: "time_limit",
                              value: "Time Limit (minutes)"
                            }),
                            createVNode(_sfc_main$3, {
                              id: "time_limit",
                              modelValue: unref(form).time_limit,
                              "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
                              modelModifiers: { number: true },
                              type: "number",
                              min: "1",
                              class: "mt-1 block w-full",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$4, {
                              message: unref(form).errors.time_limit,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ]),
                          createVNode("div", null, [
                            createVNode(_sfc_main$2, {
                              for: "passing_score",
                              value: "Passing Score (%)"
                            }),
                            createVNode(_sfc_main$3, {
                              id: "passing_score",
                              modelValue: unref(form).passing_score,
                              "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
                              modelModifiers: { number: true },
                              type: "number",
                              min: "1",
                              max: "100",
                              class: "mt-1 block w-full",
                              required: ""
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_sfc_main$4, {
                              message: unref(form).errors.passing_score,
                              class: "mt-2"
                            }, null, 8, ["message"])
                          ])
                        ]),
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode(_sfc_main$5, {
                            class: { "opacity-25": unref(form).processing },
                            disabled: unref(form).processing
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Create Quiz ")
                            ]),
                            _: 1
                          }, 8, ["class", "disabled"])
                        ])
                      ], 32)
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Course/CreateQuiz.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
