import { mergeProps, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$1 } from "./Modal-UKMpWsGi.mjs";
const _sfc_main = {
  __name: "Delete",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    course: Object
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({});
    const deleteCourse = () => {
      form.delete(route("courses.destroy", props.course.id), {
        onSuccess: () => emit("close")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        show: __props.show,
        onClose: ($event) => emit("close")
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900"${_scopeId}>حذف الدورة</h2><p class="mt-1 text-sm text-gray-600"${_scopeId}>هل أنت متأكد من رغبتك في حذف هذه الدورة؟</p><div class="mt-6 flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, { onClick: deleteCourse }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`حذف`);
                } else {
                  return [
                    createTextVNode("حذف")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900" }, "حذف الدورة"),
                createVNode("p", { class: "mt-1 text-sm text-gray-600" }, "هل أنت متأكد من رغبتك في حذف هذه الدورة؟"),
                createVNode("div", { class: "mt-6 flex justify-end" }, [
                  createVNode(_sfc_main$2, { onClick: deleteCourse }, {
                    default: withCtx(() => [
                      createTextVNode("حذف")
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Delete.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
