import { ref, withCtx, createTextVNode, unref, toDisplayString, createVNode, withModifiers, withDirectives, vModelText, createBlock, openBlock, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { useForm, router } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$2 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$4 } from "./SecondaryButton-DkF3Mn0U.mjs";
import { _ as _sfc_main$5 } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$3 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$8 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$7 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$6 } from "./Pagination-BcteoMDy.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "lodash";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    // Simplified props definition
    categories: Object,
    filters: Object
  },
  setup(__props) {
    const props = __props;
    const search = ref(props.filters.search || "");
    const showCreateModal = ref(false);
    const showEditModal = ref(false);
    const editingCategory = ref(null);
    const form = useForm({
      name: "",
      description: ""
    });
    const searchCategories = () => {
      router.get(route("admin.category.index"), { search: search.value }, {
        preserveState: true,
        replace: true
        // Avoids polluting browser history with search queries
      });
    };
    const editCategory = (category) => {
      editingCategory.value = category;
      form.name = category.name;
      form.description = category.description;
      showEditModal.value = true;
    };
    const deleteCategory = (category) => {
      if (confirm("Are you sure you want to delete this category? This action cannot be undone.")) {
        router.delete(route("admin.category.destroy", category.id), {
          preserveScroll: true,
          // Keep scroll position after delete
          onSuccess: () => {
          }
        });
      }
    };
    const submitForm = () => {
      if (editingCategory.value) {
        form.put(route("admin.category.update", editingCategory.value.id), {
          preserveScroll: true,
          onSuccess: () => closeModal()
        });
      } else {
        form.post(route("admin.category.store"), {
          preserveScroll: true,
          onSuccess: () => closeModal()
        });
      }
    };
    const closeModal = () => {
      showCreateModal.value = false;
      showEditModal.value = false;
      editingCategory.value = null;
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><div class="flex justify-between items-center mb-6"${_scopeId}><h1 class="text-2xl font-bold"${_scopeId}>Categories</h1>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              onClick: ($event) => showCreateModal.value = true
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Add Category`);
                } else {
                  return [
                    createTextVNode("Add Category")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mb-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              modelValue: search.value,
              "onUpdate:modelValue": ($event) => search.value = $event,
              placeholder: "Search categories...",
              onInput: searchCategories,
              class: "w-full md:w-1/3"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            if (__props.categories.data && __props.categories.data.length > 0) {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"${_scopeId}><!--[-->`);
              ssrRenderList(__props.categories.data, (category) => {
                _push2(`<div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"${_scopeId}><div class="p-6"${_scopeId}><h3 class="text-xl font-semibold mb-2 text-gray-800"${_scopeId}>${ssrInterpolate(category.name)}</h3><p class="text-gray-600 text-sm mb-3 h-16 overflow-y-auto"${_scopeId}>${ssrInterpolate(category.description || "No description available.")}</p><div class="flex justify-between items-center mb-4"${_scopeId}><span class="text-sm text-gray-500"${_scopeId}>Courses: ${ssrInterpolate(category.courses_count)}</span></div><div class="flex justify-end space-x-2 border-t pt-4 mt-4"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$4, {
                  onClick: ($event) => editCategory(category),
                  class: "text-sm"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`Edit`);
                    } else {
                      return [
                        createTextVNode("Edit")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(_sfc_main$5, {
                  onClick: ($event) => deleteCategory(category),
                  class: "text-sm"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`Delete`);
                    } else {
                      return [
                        createTextVNode("Delete")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div></div>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(`<div class="text-center text-gray-500 py-10"${_scopeId}><p class="text-xl"${_scopeId}>No categories found.</p>`);
              if (search.value) {
                _push2(`<p${_scopeId}>Try adjusting your search terms.</p>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            }
            _push2(ssrRenderComponent(_sfc_main$6, {
              links: ((_a = __props.categories) == null ? void 0 : _a.links) || { data: [], links: [] },
              class: "mt-8"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$7, {
              show: showCreateModal.value || showEditModal.value,
              onClose: closeModal
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto"${_scopeId2}><h2 class="text-xl font-semibold mb-6 text-gray-700"${_scopeId2}>${ssrInterpolate(editingCategory.value ? "Edit" : "Create New")} Category</h2><form${_scopeId2}><div class="mb-5"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    for: "name",
                    value: "Category Name",
                    class: "mb-1"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    id: "name",
                    modelValue: unref(form).name,
                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                    required: "",
                    class: "w-full",
                    placeholder: "e.g., Programming"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="mb-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$8, {
                    for: "description",
                    value: "Description",
                    class: "mb-1"
                  }, null, _parent3, _scopeId2));
                  _push3(`<textarea id="description" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24" placeholder="A brief description of the category"${_scopeId2}>${ssrInterpolate(unref(form).description)}</textarea></div><div class="flex justify-end space-x-3 pt-4 border-t"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$4, { onClick: closeModal }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Cancel`);
                      } else {
                        return [
                          createTextVNode("Cancel")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    type: "submit",
                    disabled: unref(form).processing
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(editingCategory.value ? "Update Category" : "Create Category")}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></form></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto" }, [
                      createVNode("h2", { class: "text-xl font-semibold mb-6 text-gray-700" }, toDisplayString(editingCategory.value ? "Edit" : "Create New") + " Category", 1),
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-5" }, [
                          createVNode(_sfc_main$8, {
                            for: "name",
                            value: "Category Name",
                            class: "mb-1"
                          }),
                          createVNode(_sfc_main$3, {
                            id: "name",
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            required: "",
                            class: "w-full",
                            placeholder: "e.g., Programming"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        createVNode("div", { class: "mb-6" }, [
                          createVNode(_sfc_main$8, {
                            for: "description",
                            value: "Description",
                            class: "mb-1"
                          }),
                          withDirectives(createVNode("textarea", {
                            id: "description",
                            "onUpdate:modelValue": ($event) => unref(form).description = $event,
                            class: "w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24",
                            placeholder: "A brief description of the category"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).description]
                          ])
                        ]),
                        createVNode("div", { class: "flex justify-end space-x-3 pt-4 border-t" }, [
                          createVNode(_sfc_main$4, { onClick: closeModal }, {
                            default: withCtx(() => [
                              createTextVNode("Cancel")
                            ]),
                            _: 1
                          }),
                          createVNode(_sfc_main$2, {
                            type: "submit",
                            disabled: unref(form).processing
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                            ]),
                            _: 1
                          }, 8, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("div", { class: "flex justify-between items-center mb-6" }, [
                  createVNode("h1", { class: "text-2xl font-bold" }, "Categories"),
                  createVNode(_sfc_main$2, {
                    onClick: ($event) => showCreateModal.value = true
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Add Category")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode(_sfc_main$3, {
                    modelValue: search.value,
                    "onUpdate:modelValue": ($event) => search.value = $event,
                    placeholder: "Search categories...",
                    onInput: searchCategories,
                    class: "w-full md:w-1/3"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                __props.categories.data && __props.categories.data.length > 0 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.categories.data, (category) => {
                    return openBlock(), createBlock("div", {
                      key: category.id,
                      class: "bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
                    }, [
                      createVNode("div", { class: "p-6" }, [
                        createVNode("h3", { class: "text-xl font-semibold mb-2 text-gray-800" }, toDisplayString(category.name), 1),
                        createVNode("p", { class: "text-gray-600 text-sm mb-3 h-16 overflow-y-auto" }, toDisplayString(category.description || "No description available."), 1),
                        createVNode("div", { class: "flex justify-between items-center mb-4" }, [
                          createVNode("span", { class: "text-sm text-gray-500" }, "Courses: " + toDisplayString(category.courses_count), 1)
                        ]),
                        createVNode("div", { class: "flex justify-end space-x-2 border-t pt-4 mt-4" }, [
                          createVNode(_sfc_main$4, {
                            onClick: ($event) => editCategory(category),
                            class: "text-sm"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Edit")
                            ]),
                            _: 2
                          }, 1032, ["onClick"]),
                          createVNode(_sfc_main$5, {
                            onClick: ($event) => deleteCategory(category),
                            class: "text-sm"
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Delete")
                            ]),
                            _: 2
                          }, 1032, ["onClick"])
                        ])
                      ])
                    ]);
                  }), 128))
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  class: "text-center text-gray-500 py-10"
                }, [
                  createVNode("p", { class: "text-xl" }, "No categories found."),
                  search.value ? (openBlock(), createBlock("p", { key: 0 }, "Try adjusting your search terms.")) : createCommentVNode("", true)
                ])),
                createVNode(_sfc_main$6, {
                  links: ((_b = __props.categories) == null ? void 0 : _b.links) || { data: [], links: [] },
                  class: "mt-8"
                }, null, 8, ["links"])
              ]),
              createVNode(_sfc_main$7, {
                show: showCreateModal.value || showEditModal.value,
                onClose: closeModal
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto" }, [
                    createVNode("h2", { class: "text-xl font-semibold mb-6 text-gray-700" }, toDisplayString(editingCategory.value ? "Edit" : "Create New") + " Category", 1),
                    createVNode("form", {
                      onSubmit: withModifiers(submitForm, ["prevent"])
                    }, [
                      createVNode("div", { class: "mb-5" }, [
                        createVNode(_sfc_main$8, {
                          for: "name",
                          value: "Category Name",
                          class: "mb-1"
                        }),
                        createVNode(_sfc_main$3, {
                          id: "name",
                          modelValue: unref(form).name,
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          required: "",
                          class: "w-full",
                          placeholder: "e.g., Programming"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("div", { class: "mb-6" }, [
                        createVNode(_sfc_main$8, {
                          for: "description",
                          value: "Description",
                          class: "mb-1"
                        }),
                        withDirectives(createVNode("textarea", {
                          id: "description",
                          "onUpdate:modelValue": ($event) => unref(form).description = $event,
                          class: "w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-24",
                          placeholder: "A brief description of the category"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).description]
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-end space-x-3 pt-4 border-t" }, [
                        createVNode(_sfc_main$4, { onClick: closeModal }, {
                          default: withCtx(() => [
                            createTextVNode("Cancel")
                          ]),
                          _: 1
                        }),
                        createVNode(_sfc_main$2, {
                          type: "submit",
                          disabled: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(editingCategory.value ? "Update Category" : "Create Category"), 1)
                          ]),
                          _: 1
                        }, 8, ["disabled"])
                      ])
                    ], 32)
                  ])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard/Category/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
