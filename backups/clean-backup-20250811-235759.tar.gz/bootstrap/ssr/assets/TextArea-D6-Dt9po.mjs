import { mergeProps, withCtx, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$2 } from "./InputError-C7WpniWA.mjs";
const _sfc_main = {
  __name: "TextArea",
  __ssrInlineRender: true,
  props: {
    modelValue: String,
    label: String,
    error: String,
    id: {
      type: String,
      default: () => `textarea-${Math.random().toString(36).substring(2, 9)}`
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      let _temp0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-1" }, _attrs))}>`);
      if (__props.label) {
        _push(ssrRenderComponent(_sfc_main$1, { for: __props.id }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(__props.label)}`);
            } else {
              return [
                createTextVNode(toDisplayString(__props.label), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<textarea${ssrRenderAttrs(_temp0 = mergeProps({
        id: __props.id,
        class: ["block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary disabled:opacity-50", {
          "border-red-500": __props.error,
          "dark:border-gray-600 dark:bg-slate-800 dark:text-gray-300": _ctx.$page.props.darkMode
        }],
        value: __props.modelValue
      }, _ctx.$attrs), "textarea")}>${ssrInterpolate("value" in _temp0 ? _temp0.value : "")}</textarea>`);
      if (__props.error) {
        _push(ssrRenderComponent(_sfc_main$2, { message: __props.error }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/TextArea.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
