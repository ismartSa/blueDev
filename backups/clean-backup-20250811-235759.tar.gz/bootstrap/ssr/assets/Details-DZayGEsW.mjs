import { mergeProps, useSSRContext, unref, withCtx, createTextVNode, toDisplayString, computed, createVNode } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { Link, usePage, Head, router } from "@inertiajs/vue3";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import { _ as _sfc_main$5 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$6 } from "./Breadcrumb-BsPLZkqL.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main$4 = {
  __name: "CourseInfoItem",
  __ssrInlineRender: true,
  props: {
    icon: {
      type: String,
      required: true
    },
    text: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center space-x-3 mb-3 last:mb-0" }, _attrs))}><svg class="w-5 h-5 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"${ssrRenderAttr("d", __props.icon)}></path></svg><span class="text-gray-700 dark:text-gray-300">${ssrInterpolate(__props.text)}</span></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseInfoItem.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "CourseActionButtons",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      required: true
    },
    isEnrolled: {
      type: Boolean,
      default: false
    }
  },
  emits: ["enroll"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-3" }, _attrs))}>`);
      if (!__props.isEnrolled) {
        _push(`<button class="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200">${ssrInterpolate(((_c = (_b = (_a = _ctx.$page.props.translations) == null ? void 0 : _a.course) == null ? void 0 : _b.label) == null ? void 0 : _c.enroll) || "Enroll Now")}</button>`);
      } else {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("course.learn", { id: __props.course.id, courseSlug: __props.course.slug }),
          class: "block w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200 text-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d, _e, _f;
            if (_push2) {
              _push2(`${ssrInterpolate(((_c2 = (_b2 = (_a2 = _ctx.$page.props.translations) == null ? void 0 : _a2.course) == null ? void 0 : _b2.label) == null ? void 0 : _c2.continue_learning) || "Continue Learning")}`);
            } else {
              return [
                createTextVNode(toDisplayString(((_f = (_e = (_d = _ctx.$page.props.translations) == null ? void 0 : _d.course) == null ? void 0 : _e.label) == null ? void 0 : _f.continue_learning) || "Continue Learning"), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseActionButtons.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "CourseInfoCard",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      required: true
    },
    isEnrolled: {
      type: Boolean,
      default: false
    }
  },
  emits: ["enroll"],
  setup(__props) {
    const page = usePage();
    const translations = computed(() => {
      var _a;
      return ((_a = page.props.translations) == null ? void 0 : _a.course) || {};
    });
    const lang = () => translations.value;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "md:w-1/3 pr-8" }, _attrs))} data-v-dbf7ec06><img${ssrRenderAttr("src", __props.course.image)}${ssrRenderAttr("alt", __props.course.title)} class="w-full h-auto rounded-lg shadow-md mb-6" data-v-dbf7ec06><div class="bg-gray-100 dark:bg-slate-700 rounded-lg p-4 mb-6" data-v-dbf7ec06>`);
      _push(ssrRenderComponent(_sfc_main$4, {
        icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
        text: `${lang().label.duration}: ${__props.course.duration}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        icon: "M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z",
        text: `${lang().label.enrolled}: ${__props.course.enrollments_count}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        icon: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01",
        text: `${lang().label.lectures}: ${__props.course.lectures_count}`
      }, null, _parent));
      _push(`</div><div class="text-center" data-v-dbf7ec06>`);
      if (__props.course.price === 0) {
        _push(`<span class="text-2xl font-bold text-green-600 dark:text-green-400 mb-4 block" data-v-dbf7ec06>FREE</span>`);
      } else {
        _push(`<span class="text-2xl font-bold text-green-600 dark:text-green-400 mb-4 block" data-v-dbf7ec06>$${ssrInterpolate(__props.course.price.toFixed(2))}</span>`);
      }
      _push(ssrRenderComponent(_sfc_main$3, {
        isEnrolled: __props.isEnrolled,
        course: __props.course,
        onEnroll: ($event) => _ctx.$emit("enroll")
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseInfoCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const CourseInfoCard = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-dbf7ec06"]]);
const _sfc_main$1 = {
  __name: "CourseDetailsContent",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    usePage();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "md:w-2/3" }, _attrs))} data-v-0f8815fa><div class="bg-white dark:bg-slate-800 rounded-lg shadow-sm p-6 mb-6" data-v-0f8815fa><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4" data-v-0f8815fa>${ssrInterpolate(((_c = (_b = (_a = _ctx.$page.props.translations) == null ? void 0 : _a.course) == null ? void 0 : _b.label) == null ? void 0 : _c.description) || "Description")}</h3><div class="prose dark:prose-invert max-w-none" data-v-0f8815fa><div data-v-0f8815fa>${__props.course.description ?? ""}</div></div></div><div class="bg-white dark:bg-slate-800 rounded-lg shadow-sm p-6 mb-6" data-v-0f8815fa><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4" data-v-0f8815fa>${ssrInterpolate(((_f = (_e = (_d = _ctx.$page.props.translations) == null ? void 0 : _d.course) == null ? void 0 : _e.label) == null ? void 0 : _f.what_you_will_learn) || "What You Will Learn")}</h3><ul class="space-y-3" data-v-0f8815fa><!--[-->`);
      ssrRenderList(__props.course.learning_outcomes, (item, index) => {
        _push(`<li class="flex items-start bg-gray-50 dark:bg-slate-700 p-3 rounded-lg" data-v-0f8815fa><svg class="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-v-0f8815fa><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" data-v-0f8815fa></path></svg><span class="text-gray-700 dark:text-gray-300" data-v-0f8815fa>${ssrInterpolate(item)}</span></li>`);
      });
      _push(`<!--]--></ul></div><div class="bg-white dark:bg-slate-800 rounded-lg shadow-sm p-6 mb-6" data-v-0f8815fa><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4" data-v-0f8815fa>${ssrInterpolate(((_i = (_h = (_g = _ctx.$page.props.translations) == null ? void 0 : _g.course) == null ? void 0 : _h.label) == null ? void 0 : _i.requirements) || "Requirements")}</h3><ul class="space-y-3" data-v-0f8815fa><!--[-->`);
      ssrRenderList(__props.course.requirements, (requirement, index) => {
        _push(`<li class="flex items-start bg-gray-50 dark:bg-slate-700 p-3 rounded-lg" data-v-0f8815fa><svg class="w-5 h-5 text-blue-500 mt-1 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-v-0f8815fa><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" data-v-0f8815fa></path></svg><span class="text-gray-700 dark:text-gray-300" data-v-0f8815fa>${ssrInterpolate(requirement)}</span></li>`);
      });
      _push(`<!--]--></ul></div><div class="bg-white dark:bg-slate-800 rounded-lg shadow-sm p-6" data-v-0f8815fa><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4" data-v-0f8815fa>${ssrInterpolate(((_l = (_k = (_j = _ctx.$page.props.translations) == null ? void 0 : _j.course) == null ? void 0 : _k.label) == null ? void 0 : _l.who_is_this_course_for) || "Who Is This Course For?")}</h3><ul class="space-y-3" data-v-0f8815fa><!--[-->`);
      ssrRenderList(__props.course.target_audience, (target, index) => {
        _push(`<li class="flex items-start bg-gray-50 dark:bg-slate-700 p-3 rounded-lg" data-v-0f8815fa><svg class="w-5 h-5 text-purple-500 mt-1 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-v-0f8815fa><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" data-v-0f8815fa></path></svg><span class="text-gray-700 dark:text-gray-300" data-v-0f8815fa>${ssrInterpolate(target)}</span></li>`);
      });
      _push(`<!--]--></ul></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseDetailsContent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CourseDetailsContent = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-0f8815fa"]]);
const _sfc_main = {
  __name: "Details",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      required: true
    },
    isEnrolled: {
      type: Boolean,
      default: false
    },
    breadcrumbs: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    const props = __props;
    const enrollCourse = () => {
      router.post(route("course.enroll", { id: props.course.id }), {}, {
        preserveScroll: true,
        onSuccess: () => {
        },
        onError: (errors) => {
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-b041283c>`);
      _push(ssrRenderComponent(unref(Head), {
        title: __props.course.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$6, {
              title: __props.course.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$6, {
                title: __props.course.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12" data-v-b041283c${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8" data-v-b041283c${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-xl sm:rounded-lg" data-v-b041283c${_scopeId}><div class="p-6 sm:p-10" data-v-b041283c${_scopeId}><div class="flex flex-col md:flex-row gap-6" data-v-b041283c${_scopeId}>`);
            _push2(ssrRenderComponent(CourseInfoCard, {
              course: __props.course,
              isEnrolled: __props.isEnrolled,
              onEnroll: enrollCourse
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(CourseDetailsContent, { course: __props.course }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700" data-v-b041283c${_scopeId}><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4" data-v-b041283c${_scopeId}> التعليقات والتقييمات </h3></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-xl sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 sm:p-10" }, [
                      createVNode("div", { class: "flex flex-col md:flex-row gap-6" }, [
                        createVNode(CourseInfoCard, {
                          course: __props.course,
                          isEnrolled: __props.isEnrolled,
                          onEnroll: enrollCourse
                        }, null, 8, ["course", "isEnrolled"]),
                        createVNode(CourseDetailsContent, { course: __props.course }, null, 8, ["course"])
                      ]),
                      createVNode("div", { class: "mt-8 pt-8 border-t border-gray-200 dark:border-gray-700" }, [
                        createVNode("h3", { class: "text-lg font-semibold text-gray-900 dark:text-white mb-4" }, " التعليقات والتقييمات ")
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Details.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Details = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b041283c"]]);
export {
  Details as default
};
