import { reactive, unref, withCtx, createBlock, createTextVNode, openBlock, createVNode, toDisplayString, withModifiers, withDirectives, vModelText, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList } from "vue/server-renderer";
import { router, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$3 } from "./Breadcrumb-BsPLZkqL.mjs";
import { _ as _sfc_main$2 } from "./DangerButton-BPvkamuy.mjs";
import { debounce } from "lodash";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    courses: Object,
    filters: Object,
    breadcrumbs: Array
  },
  setup(__props) {
    const props = __props;
    const data = reactive({
      params: {
        search: props.filters.search || "",
        field: props.filters.field || "created_at",
        order: props.filters.order || "desc",
        perPage: props.filters.perPage || 10
      },
      selectedId: [],
      multipleSelect: false
    });
    const performSearch = debounce(() => {
      router.get(route("courses.index"), pickBy(data.params), {
        preserveState: true,
        preserveScroll: true
      });
    }, 300);
    const editCourse = (id) => router.get(route("courses.edit", id));
    const deleteCourse = (id) => router.delete(route("courses.destroy", id));
    const enrollCourse = async (id) => {
      try {
        await router.post(route("courses.enroll", id));
      } catch (error) {
        console.error("Error enrolling in course:", error);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: __props.title }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$3, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$3, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6"${_scopeId}><div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6"${_scopeId}><div class="flex-1 min-w-0"${_scopeId}><h2 class="text-2xl font-bold text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(__props.title)}</h2></div><div class="flex items-center space-x-2 mt-4 md:mt-0"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("courses.create"),
              class: "bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex items-center gap-2"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId2}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"${_scopeId2}></path></svg> إضافة دورة جديدة `);
                } else {
                  return [
                    (openBlock(), createBlock("svg", {
                      xmlns: "http://www.w3.org/2000/svg",
                      class: "h-5 w-5",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor"
                    }, [
                      createVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        "stroke-width": "2",
                        d: "M12 4v16m8-8H4"
                      })
                    ])),
                    createTextVNode(" إضافة دورة جديدة ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="mb-8"${_scopeId}><form class="flex gap-4"${_scopeId}><div class="flex-1"${_scopeId}><input${ssrRenderAttr("value", data.params.search)} type="text" placeholder="ابحث عن الدورات..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out"${_scopeId}></div><button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg transition duration-150 ease-in-out flex items-center gap-2"${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"${_scopeId}></path></svg> بحث </button></form></div>`);
            if (__props.courses.data.length === 0) {
              _push2(`<div class="bg-white rounded-lg shadow p-8 text-center"${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 12h.01M12 14h.01M12 16h.01M12 18h.01M12 20h.01M12 22h.01"${_scopeId}></path></svg><p class="text-gray-600 text-lg"${_scopeId}>لم يتم العثور على دورات</p></div>`);
            } else {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"${_scopeId}><!--[-->`);
              ssrRenderList(__props.courses, (course) => {
                _push2(`<div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-1"${_scopeId}><div class="relative"${_scopeId}><img${ssrRenderAttr("src", course.image)}${ssrRenderAttr("alt", course.title)} class="w-full h-48 object-cover"${_scopeId}><div class="absolute top-4 right-4"${_scopeId}>`);
                if (course.price) {
                  _push2(`<span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium"${_scopeId}>${ssrInterpolate(course.price)} ريال </span>`);
                } else {
                  _push2(`<span class="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium"${_scopeId}> مجاني </span>`);
                }
                _push2(`</div></div><div class="p-6"${_scopeId}><h4 class="text-xl font-bold mb-3 text-gray-900"${_scopeId}>${ssrInterpolate(course.title)}</h4><p class="text-gray-600 mb-4 line-clamp-2"${_scopeId}>${ssrInterpolate(course.description)}</p><div class="flex flex-col gap-3"${_scopeId}><div class="flex justify-between items-center"${_scopeId}>`);
                if (course.user_enrolled) {
                  _push2(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("courses.show", { id: course.id, slug: course.slug }),
                    class: "bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1 text-center"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(` متابعة التعلم `);
                      } else {
                        return [
                          createTextVNode(" متابعة التعلم ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  _push2(`<button class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1"${_scopeId}> التسجيل في الدورة </button>`);
                }
                _push2(`</div><div class="flex justify-between gap-2"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("courses.details", { id: course.id, slug: course.slug }),
                  class: "bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1 text-center"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` تفاصيل الدورة `);
                    } else {
                      return [
                        createTextVNode(" تفاصيل الدورة ")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<button class="bg-yellow-100 hover:bg-yellow-200 text-yellow-700 font-medium p-2 rounded-lg transition duration-150 ease-in-out"${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"${_scopeId}></path></svg></button>`);
                _push2(ssrRenderComponent(_sfc_main$2, {
                  onClick: ($event) => deleteCourse(course.id),
                  class: "p-2"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"${_scopeId2}><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"${_scopeId2}></path></svg>`);
                    } else {
                      return [
                        (openBlock(), createBlock("svg", {
                          xmlns: "http://www.w3.org/2000/svg",
                          class: "h-5 w-5",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          })
                        ]))
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div></div></div>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6" }, [
                      createVNode("div", { class: "flex flex-col md:flex-row md:items-center md:justify-between mb-6" }, [
                        createVNode("div", { class: "flex-1 min-w-0" }, [
                          createVNode("h2", { class: "text-2xl font-bold text-gray-900 dark:text-white" }, toDisplayString(__props.title), 1)
                        ]),
                        createVNode("div", { class: "flex items-center space-x-2 mt-4 md:mt-0" }, [
                          createVNode(unref(Link), {
                            href: _ctx.route("courses.create"),
                            class: "bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex items-center gap-2"
                          }, {
                            default: withCtx(() => [
                              (openBlock(), createBlock("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                class: "h-5 w-5",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                stroke: "currentColor"
                              }, [
                                createVNode("path", {
                                  "stroke-linecap": "round",
                                  "stroke-linejoin": "round",
                                  "stroke-width": "2",
                                  d: "M12 4v16m8-8H4"
                                })
                              ])),
                              createTextVNode(" إضافة دورة جديدة ")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ])
                      ]),
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("form", {
                          onSubmit: withModifiers(unref(performSearch), ["prevent"]),
                          class: "flex gap-4"
                        }, [
                          createVNode("div", { class: "flex-1" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => data.params.search = $event,
                              type: "text",
                              placeholder: "ابحث عن الدورات...",
                              class: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, data.params.search]
                            ])
                          ]),
                          createVNode("button", {
                            type: "submit",
                            class: "bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg transition duration-150 ease-in-out flex items-center gap-2"
                          }, [
                            (openBlock(), createBlock("svg", {
                              xmlns: "http://www.w3.org/2000/svg",
                              class: "h-5 w-5",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor"
                            }, [
                              createVNode("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                "stroke-width": "2",
                                d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                              })
                            ])),
                            createTextVNode(" بحث ")
                          ])
                        ], 40, ["onSubmit"])
                      ]),
                      __props.courses.data.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "bg-white rounded-lg shadow p-8 text-center"
                      }, [
                        (openBlock(), createBlock("svg", {
                          xmlns: "http://www.w3.org/2000/svg",
                          class: "h-16 w-16 mx-auto text-gray-400 mb-4",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          stroke: "currentColor"
                        }, [
                          createVNode("path", {
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "2",
                            d: "M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 12h.01M12 14h.01M12 16h.01M12 18h.01M12 20h.01M12 22h.01"
                          })
                        ])),
                        createVNode("p", { class: "text-gray-600 text-lg" }, "لم يتم العثور على دورات")
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.courses, (course) => {
                          return openBlock(), createBlock("div", {
                            key: course.id,
                            class: "bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-1"
                          }, [
                            createVNode("div", { class: "relative" }, [
                              createVNode("img", {
                                src: course.image,
                                alt: course.title,
                                class: "w-full h-48 object-cover"
                              }, null, 8, ["src", "alt"]),
                              createVNode("div", { class: "absolute top-4 right-4" }, [
                                course.price ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: "bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium"
                                }, toDisplayString(course.price) + " ريال ", 1)) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium"
                                }, " مجاني "))
                              ])
                            ]),
                            createVNode("div", { class: "p-6" }, [
                              createVNode("h4", { class: "text-xl font-bold mb-3 text-gray-900" }, toDisplayString(course.title), 1),
                              createVNode("p", { class: "text-gray-600 mb-4 line-clamp-2" }, toDisplayString(course.description), 1),
                              createVNode("div", { class: "flex flex-col gap-3" }, [
                                createVNode("div", { class: "flex justify-between items-center" }, [
                                  course.user_enrolled ? (openBlock(), createBlock(unref(Link), {
                                    key: 0,
                                    href: _ctx.route("courses.show", { id: course.id, slug: course.slug }),
                                    class: "bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1 text-center"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" متابعة التعلم ")
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])) : (openBlock(), createBlock("button", {
                                    key: 1,
                                    onClick: ($event) => enrollCourse(course.id),
                                    class: "bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1"
                                  }, " التسجيل في الدورة ", 8, ["onClick"]))
                                ]),
                                createVNode("div", { class: "flex justify-between gap-2" }, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("courses.details", { id: course.id, slug: course.slug }),
                                    class: "bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out flex-1 text-center"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" تفاصيل الدورة ")
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]),
                                  createVNode("button", {
                                    onClick: ($event) => editCourse(course.id),
                                    class: "bg-yellow-100 hover:bg-yellow-200 text-yellow-700 font-medium p-2 rounded-lg transition duration-150 ease-in-out"
                                  }, [
                                    (openBlock(), createBlock("svg", {
                                      xmlns: "http://www.w3.org/2000/svg",
                                      class: "h-5 w-5",
                                      fill: "none",
                                      viewBox: "0 0 24 24",
                                      stroke: "currentColor"
                                    }, [
                                      createVNode("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        "stroke-width": "2",
                                        d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                      })
                                    ]))
                                  ], 8, ["onClick"]),
                                  createVNode(_sfc_main$2, {
                                    onClick: ($event) => deleteCourse(course.id),
                                    class: "p-2"
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(), createBlock("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        class: "h-5 w-5",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor"
                                      }, [
                                        createVNode("path", {
                                          "stroke-linecap": "round",
                                          "stroke-linejoin": "round",
                                          "stroke-width": "2",
                                          d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                        })
                                      ]))
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])
                                ])
                              ])
                            ])
                          ]);
                        }), 128))
                      ]))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
