import { computed, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { A as ApplicationLogo, _ as _sfc_main$1 } from "./SwitchLangNavbar-DZvQeubw.mjs";
import { _ as _sfc_main$2 } from "./SwitchDarkMode-qMtWjm8v.mjs";
import { Head, Link } from "@inertiajs/vue3";
import _sfc_main$3 from "./Footer-BdEBRyFq.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main = {
  __name: "Welcome",
  __ssrInlineRender: true,
  props: {
    canLogin: Boolean,
    canRegister: Boolean,
    laravelVersion: String,
    phpVersion: String,
    courses: {
      type: [Array, Object],
      default: () => []
    }
  },
  setup(__props) {
    const translations = computed(() => ({
      label: {
        welcome: "Welcome",
        dashboard: "Dashboard",
        login: "Login",
        register: "Register",
        explore_courses: "Explore Our Courses",
        view_details: "View Details"
      }
    }));
    const lang = () => translations.value;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: lang().label.welcome
      }, null, _parent));
      _push(`<div class="min-h-screen bg-slate-100 dark:bg-slate-900" data-v-b8cd35a8><header class="bg-white dark:bg-slate-800 shadow" data-v-b8cd35a8><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4" data-v-b8cd35a8><div class="flex items-center justify-between" data-v-b8cd35a8><div class="flex items-center" data-v-b8cd35a8>`);
      _push(ssrRenderComponent(ApplicationLogo, { class: "h-10 w-auto text-primary fill-current" }, null, _parent));
      _push(`<p class="text-2xl ml-4 text-primary" data-v-b8cd35a8>${ssrInterpolate(_ctx.$page.props.app.name)}</p></div><div class="flex items-center space-x-4" data-v-b8cd35a8>`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      if (__props.canLogin) {
        _push(`<div class="flex items-center space-x-4" data-v-b8cd35a8>`);
        if (_ctx.$page.props.auth.user) {
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("dashboard"),
            class: "btn-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(lang().label.dashboard)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(lang().label.dashboard), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!--[-->`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("login"),
            class: "btn-secondary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(lang().label.login)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(lang().label.login), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          if (__props.canRegister) {
            _push(ssrRenderComponent(unref(Link), {
              href: _ctx.route("register"),
              class: "btn-primary"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`${ssrInterpolate(lang().label.register)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(lang().label.register), 1)
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`<!--]-->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></header><main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12" data-v-b8cd35a8><section class="gradient-bg text-white py-24 rounded-lg mb-12" data-v-b8cd35a8><div class="container mx-auto px-4 flex flex-col md:flex-row items-center" data-v-b8cd35a8><div class="md:w-1/2 mb-10 md:mb-0" data-v-b8cd35a8><h2 class="text-4xl md:text-5xl font-bold mb-6 leading-tight" data-v-b8cd35a8> Develop your skills with professional video courses </h2><p class="text-xl mb-8 text-indigo-100 max-w-md" data-v-b8cd35a8> Join thousands of learners who have developed their professional careers through our exclusive courses presented by elite experts </p><div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4" data-v-b8cd35a8><button class="bg-white text-indigo-600 px-8 py-4 rounded-lg font-bold hover:bg-indigo-50 transition duration-300 flex items-center justify-center shadow-lg" data-v-b8cd35a8><i class="fas fa-play-circle mr-2" data-v-b8cd35a8></i> Start Learning Now </button><button class="border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white hover:text-indigo-600 transition duration-300 flex items-center justify-center shadow-lg" data-v-b8cd35a8><i class="fas fa-info-circle mr-2" data-v-b8cd35a8></i> Learn More </button></div></div><div class="md:w-1/2" data-v-b8cd35a8><div class="relative" data-v-b8cd35a8><div class="video-container rounded-xl overflow-hidden shadow-2xl transform hover:scale-105 transition duration-300" data-v-b8cd35a8><iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen data-v-b8cd35a8></iframe></div><div class="absolute -bottom-4 -left-4 bg-yellow-400 text-gray-900 px-6 py-3 rounded-lg font-bold shadow-lg transform rotate-3" data-v-b8cd35a8> Exclusive for Elite members </div></div></div></div></section></main>`);
      _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Index/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Welcome = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b8cd35a8"]]);
export {
  Welcome as default
};
