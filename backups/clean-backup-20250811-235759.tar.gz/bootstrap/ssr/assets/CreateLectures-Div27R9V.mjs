import { withCtx, unref, createVNode, toDisplayString, withModifiers, withDirectives, createBlock, createCommentVNode, vModelText, openBlock, Fragment, renderList, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "CreateLectures",
  __ssrInlineRender: true,
  props: {
    course: Object,
    sections: Array
  },
  setup(__props) {
    const props = __props;
    const lectureForm = useForm({
      title: "",
      description: "",
      video_url: "",
      duration: "",
      order: "",
      section_id: "",
      course_id: props.course.id
    });
    const submitLecture = () => {
      lectureForm.post(route("courses.lectures.store", props.course.id), {
        onSuccess: () => {
          lectureForm.reset();
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.add_lectures"))} - ${ssrInterpolate(__props.course.title)}</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, toDisplayString(_ctx.$t("lectures.add_lectures")) + " - " + toDisplayString(__props.course.title), 1)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.add_new_lecture"))}</h3><form${_scopeId}><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.title"))}:</label><input id="title"${ssrRenderAttr("value", unref(lectureForm).title)} type="text" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(lectureForm).errors.title) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="section_id" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.section"))}:</label><select id="section_id" class="form-select w-full rounded-md shadow-sm" required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(lectureForm).section_id) ? ssrLooseContain(unref(lectureForm).section_id, "") : ssrLooseEqual(unref(lectureForm).section_id, "")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.select_section"))}</option><!--[-->`);
            ssrRenderList(__props.sections, (section) => {
              _push2(`<option${ssrRenderAttr("value", section.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(lectureForm).section_id) ? ssrLooseContain(unref(lectureForm).section_id, section.id) : ssrLooseEqual(unref(lectureForm).section_id, section.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(section.title)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(lectureForm).errors.section_id) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.section_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.description"))}:</label><textarea id="description" class="form-textarea w-full rounded-md shadow-sm" rows="3"${_scopeId}>${ssrInterpolate(unref(lectureForm).description)}</textarea>`);
            if (unref(lectureForm).errors.description) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="video_url" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.video_url"))}:</label><input id="video_url"${ssrRenderAttr("value", unref(lectureForm).video_url)} type="url" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(lectureForm).errors.video_url) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.video_url)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="duration" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.duration"))} (${ssrInterpolate(_ctx.$t("lectures.in_minutes"))}):</label><input id="duration"${ssrRenderAttr("value", unref(lectureForm).duration)} type="number" min="1" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(lectureForm).errors.duration) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.duration)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mb-4"${_scopeId}><label for="order" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.order"))}:</label><input id="order"${ssrRenderAttr("value", unref(lectureForm).order)} type="number" min="1" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
            if (unref(lectureForm).errors.order) {
              _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(lectureForm).errors.order)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex justify-end"${_scopeId}><button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${ssrIncludeBooleanAttr(unref(lectureForm).processing) ? " disabled" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.add_lecture"))}</button></div></form></div></div><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.current_lectures"))}</h3>`);
            if (__props.sections.length === 0) {
              _push2(`<div class="text-gray-500 text-center py-4"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.no_sections_yet"))}</div>`);
            } else {
              _push2(`<div${_scopeId}><!--[-->`);
              ssrRenderList(__props.sections, (section) => {
                _push2(`<div class="mb-6"${_scopeId}><h4 class="font-semibold text-lg border-b pb-2 mb-3"${_scopeId}>${ssrInterpolate(section.title)}</h4>`);
                if (!section.lectures || section.lectures.length === 0) {
                  _push2(`<div class="text-gray-500 text-sm py-2"${_scopeId}>${ssrInterpolate(_ctx.$t("lectures.no_lectures_in_section"))}</div>`);
                } else {
                  _push2(`<div${_scopeId}><ul class="divide-y divide-gray-200"${_scopeId}><!--[-->`);
                  ssrRenderList(section.lectures, (lecture) => {
                    _push2(`<li class="py-3 flex justify-between items-center"${_scopeId}><div${_scopeId}><span class="font-medium"${_scopeId}>${ssrInterpolate(lecture.title)}</span><p class="text-sm text-gray-500"${_scopeId}>${ssrInterpolate(lecture.duration)} ${ssrInterpolate(_ctx.$t("lectures.minutes"))}</p></div></li>`);
                  });
                  _push2(`<!--]--></ul></div>`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("lectures.add_new_lecture")), 1),
                      createVNode("form", {
                        onSubmit: withModifiers(submitLecture, ["prevent"])
                      }, [
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "title",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.title")) + ":", 1),
                          withDirectives(createVNode("input", {
                            id: "title",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).title = $event,
                            type: "text",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(lectureForm).title]
                          ]),
                          unref(lectureForm).errors.title ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.title), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "section_id",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.section")) + ":", 1),
                          withDirectives(createVNode("select", {
                            id: "section_id",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).section_id = $event,
                            class: "form-select w-full rounded-md shadow-sm",
                            required: ""
                          }, [
                            createVNode("option", { value: "" }, toDisplayString(_ctx.$t("lectures.select_section")), 1),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                              return openBlock(), createBlock("option", {
                                key: section.id,
                                value: section.id
                              }, toDisplayString(section.title), 9, ["value"]);
                            }), 128))
                          ], 8, ["onUpdate:modelValue"]), [
                            [vModelSelect, unref(lectureForm).section_id]
                          ]),
                          unref(lectureForm).errors.section_id ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.section_id), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "description",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.description")) + ":", 1),
                          withDirectives(createVNode("textarea", {
                            id: "description",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).description = $event,
                            class: "form-textarea w-full rounded-md shadow-sm",
                            rows: "3"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(lectureForm).description]
                          ]),
                          unref(lectureForm).errors.description ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.description), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "video_url",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.video_url")) + ":", 1),
                          withDirectives(createVNode("input", {
                            id: "video_url",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).video_url = $event,
                            type: "url",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(lectureForm).video_url]
                          ]),
                          unref(lectureForm).errors.video_url ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.video_url), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "duration",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.duration")) + " (" + toDisplayString(_ctx.$t("lectures.in_minutes")) + "):", 1),
                          withDirectives(createVNode("input", {
                            id: "duration",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).duration = $event,
                            type: "number",
                            min: "1",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(lectureForm).duration]
                          ]),
                          unref(lectureForm).errors.duration ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.duration), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mb-4" }, [
                          createVNode("label", {
                            for: "order",
                            class: "block text-gray-700 text-sm font-bold mb-2"
                          }, toDisplayString(_ctx.$t("lectures.order")) + ":", 1),
                          withDirectives(createVNode("input", {
                            id: "order",
                            "onUpdate:modelValue": ($event) => unref(lectureForm).order = $event,
                            type: "number",
                            min: "1",
                            class: "form-input w-full rounded-md shadow-sm",
                            required: ""
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(lectureForm).order]
                          ]),
                          unref(lectureForm).errors.order ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "text-red-500 text-sm mt-1"
                          }, toDisplayString(unref(lectureForm).errors.order), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "flex justify-end" }, [
                          createVNode("button", {
                            type: "submit",
                            class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                            disabled: unref(lectureForm).processing
                          }, toDisplayString(_ctx.$t("lectures.add_lecture")), 9, ["disabled"])
                        ])
                      ], 32)
                    ])
                  ]),
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("lectures.current_lectures")), 1),
                      __props.sections.length === 0 ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-gray-500 text-center py-4"
                      }, toDisplayString(_ctx.$t("lectures.no_sections_yet")), 1)) : (openBlock(), createBlock("div", { key: 1 }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                          return openBlock(), createBlock("div", {
                            key: section.id,
                            class: "mb-6"
                          }, [
                            createVNode("h4", { class: "font-semibold text-lg border-b pb-2 mb-3" }, toDisplayString(section.title), 1),
                            !section.lectures || section.lectures.length === 0 ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-gray-500 text-sm py-2"
                            }, toDisplayString(_ctx.$t("lectures.no_lectures_in_section")), 1)) : (openBlock(), createBlock("div", { key: 1 }, [
                              createVNode("ul", { class: "divide-y divide-gray-200" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(section.lectures, (lecture) => {
                                  return openBlock(), createBlock("li", {
                                    key: lecture.id,
                                    class: "py-3 flex justify-between items-center"
                                  }, [
                                    createVNode("div", null, [
                                      createVNode("span", { class: "font-medium" }, toDisplayString(lecture.title), 1),
                                      createVNode("p", { class: "text-sm text-gray-500" }, toDisplayString(lecture.duration) + " " + toDisplayString(_ctx.$t("lectures.minutes")), 1)
                                    ])
                                  ]);
                                }), 128))
                              ])
                            ]))
                          ]);
                        }), 128))
                      ]))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/CreateLectures.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
