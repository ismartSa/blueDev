import { computed, ref, unref, withCtx, createVNode, createBlock, openBlock, toDisplayString, createTextVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { usePage, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import { ClockIcon, CheckCircleIcon, PlayIcon, DocumentTextIcon } from "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Quizzes",
  __ssrInlineRender: true,
  setup(__props) {
    const page = usePage();
    const course = computed(() => page.props.course);
    const quizzes = ref(page.props.quizzes || []);
    const selectedQuiz = ref(null);
    const quizHistory = ref(page.props.quizHistory || []);
    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
      });
    };
    const selectQuiz = (quiz) => {
      selectedQuiz.value = quiz;
    };
    const startQuiz = () => {
      if (!selectedQuiz.value) return;
      router.visit(route("quizzes.take", {
        quizId: selectedQuiz.value.id,
        courseId: course.value.id
      }));
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: `Quizzes - ${((_a = course.value) == null ? void 0 : _a.title) || "Course"}`
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b, _c, _d, _e, _f, _g, _h;
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: `Quizzes - ${((_a2 = course.value) == null ? void 0 : _a2.title) || "Course"}`,
              breadcrumbs: [
                { label: "Dashboard", href: _ctx.route("dashboard") },
                { label: "Courses", href: _ctx.route("courses.index") },
                { label: ((_b = course.value) == null ? void 0 : _b.title) || "Course", href: _ctx.route("courses.details", { id: (_c = course.value) == null ? void 0 : _c.id, courseSlug: (_d = course.value) == null ? void 0 : _d.slug }) },
                { label: "Quizzes", href: "#" }
              ]
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: `Quizzes - ${((_e = course.value) == null ? void 0 : _e.title) || "Course"}`,
                breadcrumbs: [
                  { label: "Dashboard", href: _ctx.route("dashboard") },
                  { label: "Courses", href: _ctx.route("courses.index") },
                  { label: ((_f = course.value) == null ? void 0 : _f.title) || "Course", href: _ctx.route("courses.details", { id: (_g = course.value) == null ? void 0 : _g.id, courseSlug: (_h = course.value) == null ? void 0 : _h.slug }) },
                  { label: "Quizzes", href: "#" }
                ]
              }, null, 8, ["title", "breadcrumbs"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="flex flex-col lg:flex-row lg:space-x-8"${_scopeId}><div class="lg:w-2/3"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg mb-8"${_scopeId}><div class="px-6 py-5 sm:p-6"${_scopeId}><h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}>Current Quiz</h2>`);
            if (selectedQuiz.value) {
              _push2(`<div class="mb-6"${_scopeId}><h3 class="text-2xl font-bold mb-3 text-gray-800 dark:text-white"${_scopeId}>${ssrInterpolate(selectedQuiz.value.title)}</h3><p class="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed"${_scopeId}>${ssrInterpolate(selectedQuiz.value.description)}</p><div class="flex flex-wrap gap-4 text-sm mb-6"${_scopeId}><span class="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(ClockIcon), { class: "h-4 w-4 mr-1.5" }, null, _parent2, _scopeId));
              _push2(` Time: ${ssrInterpolate(selectedQuiz.value.time_limit)} minutes </span><span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(CheckCircleIcon), { class: "h-4 w-4 mr-1.5" }, null, _parent2, _scopeId));
              _push2(` Passing Score: ${ssrInterpolate(selectedQuiz.value.passing_score)}% </span></div><button class="inline-flex items-center px-5 py-2.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(PlayIcon), { class: "h-5 w-5 mr-2" }, null, _parent2, _scopeId));
              _push2(` Start Quiz </button></div>`);
            } else {
              _push2(`<p class="text-gray-600 dark:text-gray-400 italic"${_scopeId}> Select a quiz from the list to view details and start. </p>`);
            }
            _push2(`</div></div><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg"${_scopeId}><div class="px-6 py-5 sm:p-6"${_scopeId}><h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}>Quiz History</h2>`);
            if (quizHistory.value && quizHistory.value.length > 0) {
              _push2(`<div class="overflow-x-auto"${_scopeId}><table class="min-w-full divide-y divide-gray-200 dark:divide-slate-700"${_scopeId}><thead class="bg-gray-50 dark:bg-slate-700"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"${_scopeId}> Quiz </th><th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"${_scopeId}> Date </th><th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"${_scopeId}> Score </th><th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"${_scopeId}> Status </th></tr></thead><tbody class="bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-slate-700"${_scopeId}><!--[-->`);
              ssrRenderList(quizHistory.value, (attempt) => {
                _push2(`<tr class="hover:bg-gray-50 dark:hover:bg-slate-700 transition duration-150 ease-in-out"${_scopeId}><td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white"${_scopeId}>${ssrInterpolate(attempt.quiz_title)}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(formatDate(attempt.date))}</td><td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(attempt.score)}% </td><td class="px-6 py-4 whitespace-nowrap text-sm"${_scopeId}><span class="${ssrRenderClass([attempt.passed ? "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-200" : "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200", "px-2 inline-flex text-xs leading-5 font-semibold rounded-full"])}"${_scopeId}>${ssrInterpolate(attempt.passed ? "Passed" : "Failed")}</span></td></tr>`);
              });
              _push2(`<!--]--></tbody></table></div>`);
            } else {
              _push2(`<p class="text-gray-600 dark:text-gray-400 italic"${_scopeId}> No quiz attempts yet. </p>`);
            }
            _push2(`</div></div></div><div class="lg:w-1/3 mt-8 lg:mt-0"${_scopeId}><div class="bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg sticky top-6"${_scopeId}><div class="px-6 py-5 sm:p-6"${_scopeId}><h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"${_scopeId}>Available Quizzes</h2>`);
            if (quizzes.value && quizzes.value.length > 0) {
              _push2(`<ul class="divide-y divide-gray-200 dark:divide-slate-700"${_scopeId}><!--[-->`);
              ssrRenderList(quizzes.value, (quiz) => {
                _push2(`<li class="${ssrRenderClass([{ "bg-indigo-50 dark:bg-indigo-900/50": selectedQuiz.value && selectedQuiz.value.id === quiz.id }, "py-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition duration-150 ease-in-out"])}"${_scopeId}><div class="flex items-center space-x-4"${_scopeId}><div class="flex-shrink-0"${_scopeId}><span class="inline-flex items-center justify-center h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-500 dark:text-indigo-300"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(DocumentTextIcon), { class: "h-6 w-6" }, null, _parent2, _scopeId));
                _push2(`</span></div><div class="flex-1 min-w-0"${_scopeId}><p class="text-sm font-medium text-gray-900 dark:text-white truncate"${_scopeId}>${ssrInterpolate(quiz.title)}</p><p class="text-sm text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(quiz.questions_count)} questions </p></div></div></li>`);
              });
              _push2(`<!--]--></ul>`);
            } else {
              _push2(`<p class="text-gray-600 dark:text-gray-400 italic"${_scopeId}> No quizzes available for this course yet. </p>`);
            }
            _push2(`</div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row lg:space-x-8" }, [
                    createVNode("div", { class: "lg:w-2/3" }, [
                      createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg mb-8" }, [
                        createVNode("div", { class: "px-6 py-5 sm:p-6" }, [
                          createVNode("h2", { class: "text-xl font-semibold text-gray-900 dark:text-white mb-4" }, "Current Quiz"),
                          selectedQuiz.value ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "mb-6"
                          }, [
                            createVNode("h3", { class: "text-2xl font-bold mb-3 text-gray-800 dark:text-white" }, toDisplayString(selectedQuiz.value.title), 1),
                            createVNode("p", { class: "text-gray-600 dark:text-gray-300 mb-4 leading-relaxed" }, toDisplayString(selectedQuiz.value.description), 1),
                            createVNode("div", { class: "flex flex-wrap gap-4 text-sm mb-6" }, [
                              createVNode("span", { class: "inline-flex items-center px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200" }, [
                                createVNode(unref(ClockIcon), { class: "h-4 w-4 mr-1.5" }),
                                createTextVNode(" Time: " + toDisplayString(selectedQuiz.value.time_limit) + " minutes ", 1)
                              ]),
                              createVNode("span", { class: "inline-flex items-center px-3 py-1 rounded-full bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200" }, [
                                createVNode(unref(CheckCircleIcon), { class: "h-4 w-4 mr-1.5" }),
                                createTextVNode(" Passing Score: " + toDisplayString(selectedQuiz.value.passing_score) + "% ", 1)
                              ])
                            ]),
                            createVNode("button", {
                              onClick: startQuiz,
                              class: "inline-flex items-center px-5 py-2.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out"
                            }, [
                              createVNode(unref(PlayIcon), { class: "h-5 w-5 mr-2" }),
                              createTextVNode(" Start Quiz ")
                            ])
                          ])) : (openBlock(), createBlock("p", {
                            key: 1,
                            class: "text-gray-600 dark:text-gray-400 italic"
                          }, " Select a quiz from the list to view details and start. "))
                        ])
                      ]),
                      createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg" }, [
                        createVNode("div", { class: "px-6 py-5 sm:p-6" }, [
                          createVNode("h2", { class: "text-xl font-semibold text-gray-900 dark:text-white mb-4" }, "Quiz History"),
                          quizHistory.value && quizHistory.value.length > 0 ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "overflow-x-auto"
                          }, [
                            createVNode("table", { class: "min-w-full divide-y divide-gray-200 dark:divide-slate-700" }, [
                              createVNode("thead", { class: "bg-gray-50 dark:bg-slate-700" }, [
                                createVNode("tr", null, [
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"
                                  }, " Quiz "),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"
                                  }, " Date "),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"
                                  }, " Score "),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"
                                  }, " Status ")
                                ])
                              ]),
                              createVNode("tbody", { class: "bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-slate-700" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(quizHistory.value, (attempt) => {
                                  return openBlock(), createBlock("tr", {
                                    key: attempt.id,
                                    class: "hover:bg-gray-50 dark:hover:bg-slate-700 transition duration-150 ease-in-out"
                                  }, [
                                    createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white" }, toDisplayString(attempt.quiz_title), 1),
                                    createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(formatDate(attempt.date)), 1),
                                    createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(attempt.score) + "% ", 1),
                                    createVNode("td", { class: "px-6 py-4 whitespace-nowrap text-sm" }, [
                                      createVNode("span", {
                                        class: [attempt.passed ? "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-200" : "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200", "px-2 inline-flex text-xs leading-5 font-semibold rounded-full"]
                                      }, toDisplayString(attempt.passed ? "Passed" : "Failed"), 3)
                                    ])
                                  ]);
                                }), 128))
                              ])
                            ])
                          ])) : (openBlock(), createBlock("p", {
                            key: 1,
                            class: "text-gray-600 dark:text-gray-400 italic"
                          }, " No quiz attempts yet. "))
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "lg:w-1/3 mt-8 lg:mt-0" }, [
                      createVNode("div", { class: "bg-white dark:bg-slate-800 overflow-hidden shadow-sm rounded-lg sticky top-6" }, [
                        createVNode("div", { class: "px-6 py-5 sm:p-6" }, [
                          createVNode("h2", { class: "text-xl font-semibold text-gray-900 dark:text-white mb-4" }, "Available Quizzes"),
                          quizzes.value && quizzes.value.length > 0 ? (openBlock(), createBlock("ul", {
                            key: 0,
                            class: "divide-y divide-gray-200 dark:divide-slate-700"
                          }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(quizzes.value, (quiz) => {
                              return openBlock(), createBlock("li", {
                                key: quiz.id,
                                onClick: ($event) => selectQuiz(quiz),
                                class: ["py-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition duration-150 ease-in-out", { "bg-indigo-50 dark:bg-indigo-900/50": selectedQuiz.value && selectedQuiz.value.id === quiz.id }]
                              }, [
                                createVNode("div", { class: "flex items-center space-x-4" }, [
                                  createVNode("div", { class: "flex-shrink-0" }, [
                                    createVNode("span", { class: "inline-flex items-center justify-center h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-500 dark:text-indigo-300" }, [
                                      createVNode(unref(DocumentTextIcon), { class: "h-6 w-6" })
                                    ])
                                  ]),
                                  createVNode("div", { class: "flex-1 min-w-0" }, [
                                    createVNode("p", { class: "text-sm font-medium text-gray-900 dark:text-white truncate" }, toDisplayString(quiz.title), 1),
                                    createVNode("p", { class: "text-sm text-gray-500 dark:text-gray-400" }, toDisplayString(quiz.questions_count) + " questions ", 1)
                                  ])
                                ])
                              ], 10, ["onClick"]);
                            }), 128))
                          ])) : (openBlock(), createBlock("p", {
                            key: 1,
                            class: "text-gray-600 dark:text-gray-400 italic"
                          }, " No quizzes available for this course yet. "))
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Course/Quizzes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
