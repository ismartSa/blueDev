import { mergeProps, withCtx, createTextVNode, unref, createVNode, withModifiers, withDirectives, vModelCheckbox, useSSRContext } from "vue";
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$5 } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$4 } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$6 } from "./InputError-C7WpniWA.mjs";
import { _ as _sfc_main$3 } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$2 } from "./SecondaryButton-DkF3Mn0U.mjs";
const _sfc_main = {
  __name: "CreateModel",
  __ssrInlineRender: true,
  props: {
    show: {
      type: Boolean,
      required: true
    },
    course: {
      type: Object,
      required: true
    }
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({
      title: "",
      description: "",
      course_id: props.course.id,
      section_id: null,
      questions_count: 0,
      time_limit: 30,
      passing_score: 70,
      allow_retake: true,
      show_correct_answers: true,
      randomize_questions: false
    });
    const close = () => {
      form.reset();
      emit("close");
    };
    const submit = () => {
      form.post(route("quizzes.store"), {
        preserveScroll: true,
        onSuccess: () => close()
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, mergeProps({
        show: __props.show,
        onClose: close
      }, _attrs), {
        title: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Create New Quiz </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Create New Quiz ")
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="space-y-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "title",
              value: "Quiz Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "title",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(form).errors.title,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "description",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event,
              type: "textarea",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-2 gap-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "questions_count",
              value: "Number of Questions"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "questions_count",
              modelValue: unref(form).questions_count,
              "onUpdate:modelValue": ($event) => unref(form).questions_count = $event,
              type: "number",
              min: "1",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(form).errors.questions_count,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "time_limit",
              value: "Time Limit (minutes)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "time_limit",
              modelValue: unref(form).time_limit,
              "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
              type: "number",
              min: "1",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(form).errors.time_limit,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "passing_score",
              value: "Passing Score (%)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "passing_score",
              modelValue: unref(form).passing_score,
              "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
              type: "number",
              min: "0",
              max: "100",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              message: unref(form).errors.passing_score,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="space-y-4"${_scopeId}><div class="flex items-center"${_scopeId}><input id="allow_retake"${ssrIncludeBooleanAttr(Array.isArray(unref(form).allow_retake) ? ssrLooseContain(unref(form).allow_retake, null) : unref(form).allow_retake) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "allow_retake",
              value: "Allow Retake",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center"${_scopeId}><input id="show_correct_answers"${ssrIncludeBooleanAttr(Array.isArray(unref(form).show_correct_answers) ? ssrLooseContain(unref(form).show_correct_answers, null) : unref(form).show_correct_answers) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "show_correct_answers",
              value: "Show Correct Answers After Submission",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center"${_scopeId}><input id="randomize_questions"${ssrIncludeBooleanAttr(Array.isArray(unref(form).randomize_questions) ? ssrLooseContain(unref(form).randomize_questions, null) : unref(form).randomize_questions) ? " checked" : ""} type="checkbox" class="rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              for: "randomize_questions",
              value: "Randomize Questions",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(submit, ["prevent"]),
                class: "space-y-6"
              }, [
                createVNode("div", null, [
                  createVNode(_sfc_main$4, {
                    for: "title",
                    value: "Quiz Title"
                  }),
                  createVNode(_sfc_main$5, {
                    id: "title",
                    modelValue: unref(form).title,
                    "onUpdate:modelValue": ($event) => unref(form).title = $event,
                    type: "text",
                    class: "mt-1 block w-full",
                    required: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_sfc_main$6, {
                    message: unref(form).errors.title,
                    class: "mt-2"
                  }, null, 8, ["message"])
                ]),
                createVNode("div", null, [
                  createVNode(_sfc_main$4, {
                    for: "description",
                    value: "Description"
                  }),
                  createVNode(_sfc_main$5, {
                    id: "description",
                    modelValue: unref(form).description,
                    "onUpdate:modelValue": ($event) => unref(form).description = $event,
                    type: "textarea",
                    class: "mt-1 block w-full",
                    required: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_sfc_main$6, {
                    message: unref(form).errors.description,
                    class: "mt-2"
                  }, null, 8, ["message"])
                ]),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 gap-4" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$4, {
                      for: "questions_count",
                      value: "Number of Questions"
                    }),
                    createVNode(_sfc_main$5, {
                      id: "questions_count",
                      modelValue: unref(form).questions_count,
                      "onUpdate:modelValue": ($event) => unref(form).questions_count = $event,
                      type: "number",
                      min: "1",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$6, {
                      message: unref(form).errors.questions_count,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$4, {
                      for: "time_limit",
                      value: "Time Limit (minutes)"
                    }),
                    createVNode(_sfc_main$5, {
                      id: "time_limit",
                      modelValue: unref(form).time_limit,
                      "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
                      type: "number",
                      min: "1",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$6, {
                      message: unref(form).errors.time_limit,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$4, {
                      for: "passing_score",
                      value: "Passing Score (%)"
                    }),
                    createVNode(_sfc_main$5, {
                      id: "passing_score",
                      modelValue: unref(form).passing_score,
                      "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
                      type: "number",
                      min: "0",
                      max: "100",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$6, {
                      message: unref(form).errors.passing_score,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "space-y-4" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    withDirectives(createVNode("input", {
                      id: "allow_retake",
                      "onUpdate:modelValue": ($event) => unref(form).allow_retake = $event,
                      type: "checkbox",
                      class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelCheckbox, unref(form).allow_retake]
                    ]),
                    createVNode(_sfc_main$4, {
                      for: "allow_retake",
                      value: "Allow Retake",
                      class: "ml-2"
                    })
                  ]),
                  createVNode("div", { class: "flex items-center" }, [
                    withDirectives(createVNode("input", {
                      id: "show_correct_answers",
                      "onUpdate:modelValue": ($event) => unref(form).show_correct_answers = $event,
                      type: "checkbox",
                      class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelCheckbox, unref(form).show_correct_answers]
                    ]),
                    createVNode(_sfc_main$4, {
                      for: "show_correct_answers",
                      value: "Show Correct Answers After Submission",
                      class: "ml-2"
                    })
                  ]),
                  createVNode("div", { class: "flex items-center" }, [
                    withDirectives(createVNode("input", {
                      id: "randomize_questions",
                      "onUpdate:modelValue": ($event) => unref(form).randomize_questions = $event,
                      type: "checkbox",
                      class: "rounded border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelCheckbox, unref(form).randomize_questions]
                    ]),
                    createVNode(_sfc_main$4, {
                      for: "randomize_questions",
                      value: "Randomize Questions",
                      class: "ml-2"
                    })
                  ])
                ])
              ], 32)
            ];
          }
        }),
        footer: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-end space-x-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, { onClick: close }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              onClick: submit,
              disabled: unref(form).processing,
              class: { "opacity-25": unref(form).processing }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Create Quiz `);
                } else {
                  return [
                    createTextVNode(" Create Quiz ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-end space-x-3" }, [
                createVNode(_sfc_main$2, { onClick: close }, {
                  default: withCtx(() => [
                    createTextVNode(" Cancel ")
                  ]),
                  _: 1
                }),
                createVNode(_sfc_main$3, {
                  onClick: submit,
                  disabled: unref(form).processing,
                  class: { "opacity-25": unref(form).processing }
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Create Quiz ")
                  ]),
                  _: 1
                }, 8, ["disabled", "class"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/CreateModel.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
