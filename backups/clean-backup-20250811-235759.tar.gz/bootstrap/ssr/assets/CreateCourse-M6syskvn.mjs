import { useSSRContext, ref, withCtx, unref, createVNode, createBlock, openBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, withDirectives, vModelText, vModelSelect } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main$2 = {
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-beae4133></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/LessonTypes/VideoLesson.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-db0ea60b></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/LessonTypes/QuizLesson.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "CreateCourse",
  __ssrInlineRender: true,
  props: {
    categories: Array
  },
  setup(__props) {
    const currentStep = ref(1);
    const sections = ref([]);
    const stepTitles = [
      "الأساسيات",
      "التفاصيل الإضافية",
      "الأقسام والمراجعة"
    ];
    const form = useForm({
      title: "",
      description: "",
      body: "",
      duration: null,
      price: 0,
      image: null,
      status: "draft",
      intro_video: "",
      category_id: ""
    });
    const nextStep = () => {
      if (currentStep.value === 1) {
        if (!form.title || !form.description || !form.category_id) {
          alert("يرجى ملء جميع الحقول المطلوبة");
          return;
        }
      } else if (currentStep.value === 2) {
        if (!form.duration || form.duration <= 0 || form.price < 0) {
          alert("يرجى ملء جميع الحقول المطلوبة بشكل صحيح");
          return;
        }
      }
      currentStep.value++;
    };
    const addSection = () => {
      sections.value.push({
        title: "",
        description: "",
        order: sections.value.length + 1
      });
    };
    const removeSection = (index) => {
      sections.value.splice(index, 1);
      sections.value.forEach((section, idx) => {
        section.order = idx + 1;
      });
    };
    const formatLabel = (key) => {
      const labels = {
        title: lang().label.courses_title,
        description: lang().label.courses_description,
        body: lang().label.courses_body,
        duration: lang().label.courses_duration,
        price: lang().label.courses_price,
        status: lang().label.courses_status,
        intro_video: lang().label.courses_intro_video_url,
        category_id: lang().label.courses_category
      };
      return labels[key] || key;
    };
    const submitForm = () => {
      const formData = new FormData();
      Object.keys(form).forEach((key) => {
        if (key !== "errors" && key !== "processing" && key !== "recentlySuccessful") {
          if (key === "image" && form[key]) {
            formData.append(key, form[key]);
          } else if (form[key] !== null && form[key] !== void 0) {
            formData.append(key, form[key]);
          }
        }
      });
      formData.append("sections", JSON.stringify(sections.value));
      form.post(route("courses.store"), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {
          form.reset();
          sections.value = [];
          currentStep.value = 1;
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$3, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_create_new_course)}</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, toDisplayString(_ctx.lang().label.courses_create_new_course), 1)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12" data-v-90aa6f63${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8" data-v-90aa6f63${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg" data-v-90aa6f63${_scopeId}><div class="p-6 bg-white border-b border-gray-200" data-v-90aa6f63${_scopeId}><div class="mb-8" data-v-90aa6f63${_scopeId}><div class="flex justify-between mb-1" data-v-90aa6f63${_scopeId}><!--[-->`);
            ssrRenderList(3, (step) => {
              _push2(`<span class="${ssrRenderClass({ "text-blue-600 font-bold": currentStep.value >= step, "text-gray-400": currentStep.value < step })}" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_step)} ${ssrInterpolate(step)}: ${ssrInterpolate(stepTitles[step - 1])}</span>`);
            });
            _push2(`<!--]--></div><div class="w-full bg-gray-200 rounded-full h-2.5" data-v-90aa6f63${_scopeId}><div class="bg-blue-600 h-2.5 rounded-full" style="${ssrRenderStyle({ width: `${currentStep.value / 3 * 100}%` })}" data-v-90aa6f63${_scopeId}></div></div></div><form enctype="multipart/form-data" data-v-90aa6f63${_scopeId}>`);
            if (currentStep.value === 1) {
              _push2(`<div data-v-90aa6f63${_scopeId}><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_title)}:</label><input id="title"${ssrRenderAttr("value", unref(form).title)} type="text" class="form-input w-full" required data-v-90aa6f63${_scopeId}>`);
              if (unref(form).errors.title) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_description)}:</label><textarea id="description" class="form-textarea w-full" rows="3" required data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
              if (unref(form).errors.description) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="category_id" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_category)}:</label><select id="category_id" class="form-select w-full" required data-v-90aa6f63${_scopeId}><option value="" data-v-90aa6f63${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, "") : ssrLooseEqual(unref(form).category_id, "")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_select_category)}</option><!--[-->`);
              ssrRenderList(__props.categories, (category) => {
                _push2(`<option${ssrRenderAttr("value", category.id)} data-v-90aa6f63${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, category.id) : ssrLooseEqual(unref(form).category_id, category.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
              });
              _push2(`<!--]--></select>`);
              if (unref(form).errors.category_id) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.category_id)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 2) {
              _push2(`<div data-v-90aa6f63${_scopeId}><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="body" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_body)}:</label><textarea id="body" class="form-textarea w-full" rows="5" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).body)}</textarea>`);
              if (unref(form).errors.body) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.body)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="duration" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_duration)} (${ssrInterpolate(_ctx.lang().label.courses_in_minutes)}):</label><input id="duration"${ssrRenderAttr("value", unref(form).duration)} type="number" class="form-input w-full" required data-v-90aa6f63${_scopeId}>`);
              if (unref(form).errors.duration) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.duration)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="price" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_price)}:</label><input id="price"${ssrRenderAttr("value", unref(form).price)} type="number" step="0.01" class="form-input w-full" required data-v-90aa6f63${_scopeId}>`);
              if (unref(form).errors.price) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.price)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="image" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_image)}:</label><input id="image" type="file" class="form-input w-full" data-v-90aa6f63${_scopeId}>`);
              if (unref(form).errors.image) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.image)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="status" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_status)}:</label><select id="status" class="form-select w-full" required data-v-90aa6f63${_scopeId}><option value="draft" data-v-90aa6f63${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "draft") : ssrLooseEqual(unref(form).status, "draft")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_draft)}</option><option value="active" data-v-90aa6f63${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "active") : ssrLooseEqual(unref(form).status, "active")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_active)}</option></select>`);
              if (unref(form).errors.status) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.status)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4" data-v-90aa6f63${_scopeId}><label for="intro_video" class="block text-gray-700 text-sm font-bold mb-2" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_intro_video_url)}:</label><input id="intro_video"${ssrRenderAttr("value", unref(form).intro_video)} type="url" class="form-input w-full" data-v-90aa6f63${_scopeId}>`);
              if (unref(form).errors.intro_video) {
                _push2(`<div class="text-red-500 text-sm mt-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).errors.intro_video)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 3) {
              _push2(`<div data-v-90aa6f63${_scopeId}><h3 class="text-lg font-semibold mb-4" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_sections_planning)}</h3><div class="mb-6" data-v-90aa6f63${_scopeId}><div class="flex justify-between items-center mb-2" data-v-90aa6f63${_scopeId}><h4 class="font-medium" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_course_sections)}</h4><button type="button" class="bg-blue-500 hover:bg-blue-700 text-white text-sm py-1 px-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_add_section)}</button>`);
              if (currentStep.value > 1) {
                _push2(`<button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-gray-500" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_previous)}</button>`);
              } else {
                _push2(`<!---->`);
              }
              if (currentStep.value < 3) {
                _push2(`<button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_next)}</button>`);
              } else {
                _push2(`<!---->`);
              }
              if (currentStep.value === 3) {
                _push2(`<button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-green-500"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_create_course)}</button>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><!--[-->`);
              ssrRenderList(sections.value, (section, index) => {
                _push2(`<div class="border p-4 mb-4 rounded-lg" data-v-90aa6f63${_scopeId}><div class="flex justify-between items-center mb-2" data-v-90aa6f63${_scopeId}><h5 class="font-medium" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_section)} ${ssrInterpolate(index + 1)}</h5><button type="button" class="text-red-500 hover:text-red-700" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_remove)}</button></div><div class="mb-3" data-v-90aa6f63${_scopeId}><label${ssrRenderAttr("for", `section-title-${index}`)} class="block text-gray-700 text-sm font-bold mb-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_title)}:</label><input${ssrRenderAttr("id", `section-title-${index}`)}${ssrRenderAttr("value", section.title)} type="text" class="form-input w-full text-sm" required data-v-90aa6f63${_scopeId}></div><div class="mb-3" data-v-90aa6f63${_scopeId}><label${ssrRenderAttr("for", `section-description-${index}`)} class="block text-gray-700 text-sm font-bold mb-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_description)}:</label><textarea${ssrRenderAttr("id", `section-description-${index}`)} class="form-textarea w-full text-sm" rows="2" required data-v-90aa6f63${_scopeId}>${ssrInterpolate(section.description)}</textarea></div><div class="mb-3" data-v-90aa6f63${_scopeId}><label${ssrRenderAttr("for", `section-order-${index}`)} class="block text-gray-700 text-sm font-bold mb-1" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_order)}:</label><input${ssrRenderAttr("id", `section-order-${index}`)}${ssrRenderAttr("value", section.order)} type="number" class="form-input w-full text-sm" required data-v-90aa6f63${_scopeId}></div></div>`);
              });
              _push2(`<!--]--></div><div class="bg-gray-50 p-4 rounded-lg mb-4" data-v-90aa6f63${_scopeId}><p class="text-sm text-gray-600" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_sections_note)}</p></div><h3 class="text-lg font-semibold mb-4" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_review_course_info)}</h3>`);
              if (_ctx.key !== "image" && _ctx.key !== "processing" && _ctx.key !== "errors" && _ctx.key !== "recentlySuccessful") {
                _push2(`<!--[-->`);
                ssrRenderList(unref(form), (value, key) => {
                  _push2(`<div class="mb-2" data-v-90aa6f63${_scopeId}><strong data-v-90aa6f63${_scopeId}>${ssrInterpolate(formatLabel(key))}:</strong><span data-v-90aa6f63${_scopeId}>${ssrInterpolate(value)}</span></div>`);
                });
                _push2(`<!--]-->`);
              } else {
                _push2(`<!---->`);
              }
              if (unref(form).image) {
                _push2(`<div class="mb-2" data-v-90aa6f63${_scopeId}><strong data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_image)}:</strong><span data-v-90aa6f63${_scopeId}>${ssrInterpolate(unref(form).image.name)}</span></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between mt-6" data-v-90aa6f63${_scopeId}>`);
            if (currentStep.value > 1) {
              _push2(`<button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_previous)}</button>`);
            } else {
              _push2(`<div data-v-90aa6f63${_scopeId}></div>`);
            }
            if (currentStep.value < 3) {
              _push2(`<button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_next)}</button>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 3) {
              _push2(`<button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} data-v-90aa6f63${_scopeId}>${ssrInterpolate(_ctx.lang().label.courses_create_course)}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></form></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("div", { class: "flex justify-between mb-1" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(3, (step) => {
                            return createVNode("span", {
                              key: step,
                              class: { "text-blue-600 font-bold": currentStep.value >= step, "text-gray-400": currentStep.value < step }
                            }, toDisplayString(_ctx.lang().label.courses_step) + " " + toDisplayString(step) + ": " + toDisplayString(stepTitles[step - 1]), 3);
                          }), 64))
                        ]),
                        createVNode("div", { class: "w-full bg-gray-200 rounded-full h-2.5" }, [
                          createVNode("div", {
                            class: "bg-blue-600 h-2.5 rounded-full",
                            style: { width: `${currentStep.value / 3 * 100}%` }
                          }, null, 4)
                        ])
                      ]),
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"]),
                        enctype: "multipart/form-data"
                      }, [
                        currentStep.value === 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "title",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_title) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "title",
                              "onUpdate:modelValue": ($event) => unref(form).title = $event,
                              type: "text",
                              class: "form-input w-full",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).title]
                            ]),
                            unref(form).errors.title ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "description",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_description) + ":", 1),
                            withDirectives(createVNode("textarea", {
                              id: "description",
                              "onUpdate:modelValue": ($event) => unref(form).description = $event,
                              class: "form-textarea w-full",
                              rows: "3",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).description]
                            ]),
                            unref(form).errors.description ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "category_id",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_category) + ":", 1),
                            withDirectives(createVNode("select", {
                              id: "category_id",
                              "onUpdate:modelValue": ($event) => unref(form).category_id = $event,
                              class: "form-select w-full",
                              required: ""
                            }, [
                              createVNode("option", { value: "" }, toDisplayString(_ctx.lang().label.courses_select_category), 1),
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                                return openBlock(), createBlock("option", {
                                  key: category.id,
                                  value: category.id
                                }, toDisplayString(category.name), 9, ["value"]);
                              }), 128))
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).category_id]
                            ]),
                            unref(form).errors.category_id ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.category_id), 1)) : createCommentVNode("", true)
                          ])
                        ])) : createCommentVNode("", true),
                        currentStep.value === 2 ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "body",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_body) + ":", 1),
                            withDirectives(createVNode("textarea", {
                              id: "body",
                              "onUpdate:modelValue": ($event) => unref(form).body = $event,
                              class: "form-textarea w-full",
                              rows: "5"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).body]
                            ]),
                            unref(form).errors.body ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.body), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "duration",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_duration) + " (" + toDisplayString(_ctx.lang().label.courses_in_minutes) + "):", 1),
                            withDirectives(createVNode("input", {
                              id: "duration",
                              "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                              type: "number",
                              class: "form-input w-full",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).duration]
                            ]),
                            unref(form).errors.duration ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.duration), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "price",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_price) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "price",
                              "onUpdate:modelValue": ($event) => unref(form).price = $event,
                              type: "number",
                              step: "0.01",
                              class: "form-input w-full",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).price]
                            ]),
                            unref(form).errors.price ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.price), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "image",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_image) + ":", 1),
                            createVNode("input", {
                              id: "image",
                              type: "file",
                              onInput: ($event) => unref(form).image = $event.target.files[0],
                              class: "form-input w-full"
                            }, null, 40, ["onInput"]),
                            unref(form).errors.image ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.image), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "status",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_status) + ":", 1),
                            withDirectives(createVNode("select", {
                              id: "status",
                              "onUpdate:modelValue": ($event) => unref(form).status = $event,
                              class: "form-select w-full",
                              required: ""
                            }, [
                              createVNode("option", { value: "draft" }, toDisplayString(_ctx.lang().label.courses_draft), 1),
                              createVNode("option", { value: "active" }, toDisplayString(_ctx.lang().label.courses_active), 1)
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).status]
                            ]),
                            unref(form).errors.status ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.status), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "intro_video",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.lang().label.courses_intro_video_url) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "intro_video",
                              "onUpdate:modelValue": ($event) => unref(form).intro_video = $event,
                              type: "url",
                              class: "form-input w-full"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).intro_video]
                            ]),
                            unref(form).errors.intro_video ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.intro_video), 1)) : createCommentVNode("", true)
                          ])
                        ])) : createCommentVNode("", true),
                        currentStep.value === 3 ? (openBlock(), createBlock("div", { key: 2 }, [
                          createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.lang().label.courses_sections_planning), 1),
                          createVNode("div", { class: "mb-6" }, [
                            createVNode("div", { class: "flex justify-between items-center mb-2" }, [
                              createVNode("h4", { class: "font-medium" }, toDisplayString(_ctx.lang().label.courses_course_sections), 1),
                              createVNode("button", {
                                type: "button",
                                onClick: addSection,
                                class: "bg-blue-500 hover:bg-blue-700 text-white text-sm py-1 px-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              }, toDisplayString(_ctx.lang().label.courses_add_section), 1),
                              currentStep.value > 1 ? (openBlock(), createBlock("button", {
                                key: 0,
                                onClick: ($event) => currentStep.value--,
                                type: "button",
                                class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-gray-500"
                              }, toDisplayString(_ctx.lang().label.courses_previous), 9, ["onClick"])) : createCommentVNode("", true),
                              currentStep.value < 3 ? (openBlock(), createBlock("button", {
                                key: 1,
                                onClick: nextStep,
                                type: "button",
                                class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              }, toDisplayString(_ctx.lang().label.courses_next), 1)) : createCommentVNode("", true),
                              currentStep.value === 3 ? (openBlock(), createBlock("button", {
                                key: 2,
                                type: "submit",
                                class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-green-500",
                                disabled: unref(form).processing
                              }, toDisplayString(_ctx.lang().label.courses_create_course), 9, ["disabled"])) : createCommentVNode("", true)
                            ]),
                            (openBlock(true), createBlock(Fragment, null, renderList(sections.value, (section, index) => {
                              return openBlock(), createBlock("div", {
                                key: index,
                                class: "border p-4 mb-4 rounded-lg"
                              }, [
                                createVNode("div", { class: "flex justify-between items-center mb-2" }, [
                                  createVNode("h5", { class: "font-medium" }, toDisplayString(_ctx.lang().label.courses_section) + " " + toDisplayString(index + 1), 1),
                                  createVNode("button", {
                                    type: "button",
                                    onClick: ($event) => removeSection(index),
                                    class: "text-red-500 hover:text-red-700"
                                  }, toDisplayString(_ctx.lang().label.courses_remove), 9, ["onClick"])
                                ]),
                                createVNode("div", { class: "mb-3" }, [
                                  createVNode("label", {
                                    for: `section-title-${index}`,
                                    class: "block text-gray-700 text-sm font-bold mb-1"
                                  }, toDisplayString(_ctx.lang().label.courses_title) + ":", 9, ["for"]),
                                  withDirectives(createVNode("input", {
                                    id: `section-title-${index}`,
                                    "onUpdate:modelValue": ($event) => section.title = $event,
                                    type: "text",
                                    class: "form-input w-full text-sm",
                                    required: ""
                                  }, null, 8, ["id", "onUpdate:modelValue"]), [
                                    [vModelText, section.title]
                                  ])
                                ]),
                                createVNode("div", { class: "mb-3" }, [
                                  createVNode("label", {
                                    for: `section-description-${index}`,
                                    class: "block text-gray-700 text-sm font-bold mb-1"
                                  }, toDisplayString(_ctx.lang().label.courses_description) + ":", 9, ["for"]),
                                  withDirectives(createVNode("textarea", {
                                    id: `section-description-${index}`,
                                    "onUpdate:modelValue": ($event) => section.description = $event,
                                    class: "form-textarea w-full text-sm",
                                    rows: "2",
                                    required: ""
                                  }, null, 8, ["id", "onUpdate:modelValue"]), [
                                    [vModelText, section.description]
                                  ])
                                ]),
                                createVNode("div", { class: "mb-3" }, [
                                  createVNode("label", {
                                    for: `section-order-${index}`,
                                    class: "block text-gray-700 text-sm font-bold mb-1"
                                  }, toDisplayString(_ctx.lang().label.courses_order) + ":", 9, ["for"]),
                                  withDirectives(createVNode("input", {
                                    id: `section-order-${index}`,
                                    "onUpdate:modelValue": ($event) => section.order = $event,
                                    type: "number",
                                    class: "form-input w-full text-sm",
                                    required: ""
                                  }, null, 8, ["id", "onUpdate:modelValue"]), [
                                    [vModelText, section.order]
                                  ])
                                ])
                              ]);
                            }), 128))
                          ]),
                          createVNode("div", { class: "bg-gray-50 p-4 rounded-lg mb-4" }, [
                            createVNode("p", { class: "text-sm text-gray-600" }, toDisplayString(_ctx.lang().label.courses_sections_note), 1)
                          ]),
                          createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.lang().label.courses_review_course_info), 1),
                          _ctx.key !== "image" && _ctx.key !== "processing" && _ctx.key !== "errors" && _ctx.key !== "recentlySuccessful" ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(unref(form), (value, key) => {
                            return openBlock(), createBlock("div", {
                              key,
                              class: "mb-2"
                            }, [
                              createVNode("strong", null, toDisplayString(formatLabel(key)) + ":", 1),
                              createVNode("span", null, toDisplayString(value), 1)
                            ]);
                          }), 128)) : createCommentVNode("", true),
                          unref(form).image ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "mb-2"
                          }, [
                            createVNode("strong", null, toDisplayString(_ctx.lang().label.courses_image) + ":", 1),
                            createVNode("span", null, toDisplayString(unref(form).image.name), 1)
                          ])) : createCommentVNode("", true)
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "flex justify-between mt-6" }, [
                          currentStep.value > 1 ? (openBlock(), createBlock("button", {
                            key: 0,
                            onClick: ($event) => currentStep.value--,
                            type: "button",
                            class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                          }, toDisplayString(_ctx.lang().label.courses_previous), 9, ["onClick"])) : (openBlock(), createBlock("div", { key: 1 })),
                          currentStep.value < 3 ? (openBlock(), createBlock("button", {
                            key: 2,
                            onClick: nextStep,
                            type: "button",
                            class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                          }, toDisplayString(_ctx.lang().label.courses_next), 1)) : createCommentVNode("", true),
                          currentStep.value === 3 ? (openBlock(), createBlock("button", {
                            key: 3,
                            type: "submit",
                            class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                            disabled: unref(form).processing
                          }, toDisplayString(_ctx.lang().label.courses_create_course), 9, ["disabled"])) : createCommentVNode("", true)
                        ])
                      ], 32)
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard/Course/CreateCourse.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const CreateCourse = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-90aa6f63"]]);
export {
  CreateCourse as default
};
