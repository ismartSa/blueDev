import { useForm } from "@inertiajs/vue3";
import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main = {
  setup() {
    const form = useForm({
      json_content: "",
      table_name: ""
    });
    const submit = () => {
      form.post("/opt/convert");
    };
    const clearForm = () => {
      form.json_content = "";
      form.table_name = "";
    };
    const copySql = () => {
      const sqlOutput = document.querySelector("pre").textContent;
      navigator.clipboard.writeText(sqlOutput).then(() => {
        alert("SQL copied to clipboard!");
      });
    };
    return {
      form,
      submit,
      clearForm,
      copySql
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "container mx-auto p-6" }, _attrs))}><h1 class="text-3xl font-bold mb-6">JSON to PostgreSQL Converter</h1>`);
  if (_ctx.$page.props.flash.success) {
    _push(`<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">${ssrInterpolate(_ctx.$page.props.flash.success)}</div>`);
  } else {
    _push(`<!---->`);
  }
  if (_ctx.$page.props.flash.error) {
    _push(`<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">${ssrInterpolate(_ctx.$page.props.flash.error)}</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<form class="bg-white shadow-lg rounded-lg px-8 pt-6 pb-8 mb-6"><div class="mb-6"><label class="block text-gray-700 text-sm font-bold mb-2"> JSON Content: </label><textarea class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="15" placeholder="Paste your JSON content here..." required>${ssrInterpolate($setup.form.json_content)}</textarea>`);
  if ($setup.form.errors.json_content) {
    _push(`<div class="text-red-500 text-xs mt-1">${ssrInterpolate($setup.form.errors.json_content)}</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<p class="text-gray-600 text-xs mt-1">Paste JSON array or object to convert to PostgreSQL INSERT statements</p></div><div class="mb-6"><label class="block text-gray-700 text-sm font-bold mb-2"> Table Name: </label><input type="text"${ssrRenderAttr("value", $setup.form.table_name)} class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Enter PostgreSQL table name" required>`);
  if ($setup.form.errors.table_name) {
    _push(`<div class="text-red-500 text-xs mt-1">${ssrInterpolate($setup.form.errors.table_name)}</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="flex items-center justify-between"><button type="submit"${ssrIncludeBooleanAttr($setup.form.processing) ? " disabled" : ""} class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded focus:outline-none focus:shadow-outline disabled:opacity-50">`);
  if ($setup.form.processing) {
    _push(`<span>Converting...</span>`);
  } else {
    _push(`<span>Convert to SQL</span>`);
  }
  _push(`</button><button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"> Clear </button></div></form>`);
  if (_ctx.$page.props.flash.sql_output) {
    _push(`<div class="bg-gray-900 text-green-400 p-6 rounded-lg"><div class="flex justify-between items-center mb-4"><h3 class="text-xl font-bold text-white">Generated PostgreSQL:</h3><button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm"> Copy SQL </button></div><pre class="text-sm overflow-x-auto whitespace-pre-wrap">${ssrInterpolate(_ctx.$page.props.flash.sql_output)}</pre></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="bg-blue-50 border border-blue-200 p-4 rounded mt-6"><h3 class="font-bold mb-2 text-blue-800">How to use:</h3><ul class="list-disc list-inside text-sm text-blue-700"><li>Paste your JSON content in the textarea above</li><li>Enter the PostgreSQL table name</li><li>Click &quot;Convert to SQL&quot; to generate PostgreSQL queries</li><li>Copy the generated SQL and run it in your PostgreSQL database</li></ul></div><div class="bg-yellow-50 border border-yellow-200 p-4 rounded mt-4"><h3 class="font-bold mb-2 text-yellow-800">Example JSON:</h3><pre class="text-sm text-yellow-700 overflow-x-auto">  [
    {
      &quot;id&quot;: 1,
      &quot;name&quot;: &quot;John Doe&quot;,
      &quot;email&quot;: &quot;john@example.com&quot;
    },
    {
      &quot;id&quot;: 2,
      &quot;name&quot;: &quot;Jane Smith&quot;,
      &quot;email&quot;: &quot;jane@example.com&quot;
    }
  ]
        </pre></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Opt/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Index as default
};
