import { ref, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import _sfc_main$1 from "./Lecture-BH6Bpz_d.mjs";
import "@inertiajs/vue3";
const _sfc_main = {
  __name: "Section",
  __ssrInlineRender: true,
  props: {
    section: {
      type: Object,
      required: true
    },
    lectures: {
      type: Array,
      default: () => []
    }
  },
  setup(__props) {
    const isCollapsed = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "section mb-8" }, _attrs))}><div class="flex justify-between items-center mb-4"><h3 class="text-xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(__props.section.title)}</h3><button class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">${ssrInterpolate(isCollapsed.value ? "Show" : "Hide")}</button></div>`);
      if (!isCollapsed.value) {
        _push(`<div class="mt-4"><p class="text-gray-600 dark:text-gray-300 mb-4">${ssrInterpolate(__props.section.description)}</p><ul class="space-y-2"><!--[-->`);
        ssrRenderList(__props.lectures, (lecture) => {
          _push(`<li class="bg-white dark:bg-slate-700 rounded-lg shadow-sm p-4">`);
          _push(ssrRenderComponent(_sfc_main$1, { lecture }, null, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Section.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
