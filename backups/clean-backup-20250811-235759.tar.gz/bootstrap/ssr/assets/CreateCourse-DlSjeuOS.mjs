import { ref, withCtx, unref, createVNode, createBlock, openBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, withDirectives, vModelText, vModelSelect, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { useForm, usePage } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "CreateCourse",
  __ssrInlineRender: true,
  props: {
    categories: Array
  },
  setup(__props) {
    const props = __props;
    const currentStep = ref(1);
    const stepLabels = [
      "المعلومات الأساسية",
      "التفاصيل الإضافية",
      "المراجعة"
    ];
    const form = useForm({
      title: "",
      description: "",
      category_id: "",
      price: 0,
      duration: 60,
      image: null,
      status: "draft",
      intro_video: ""
    });
    const getCategoryName = (categoryId) => {
      if (!categoryId) return "غير محدد";
      const category = props.categories.find((cat) => cat.id === categoryId);
      return category ? category.name : "غير محدد";
    };
    const validateStep = () => {
      if (currentStep.value === 1) {
        if (!form.title || !form.description || !form.category_id || form.price === null) {
          return false;
        }
      } else if (currentStep.value === 2) {
        if (!form.duration || !form.status) {
          return false;
        }
      }
      return true;
    };
    const nextStep = () => {
      if (validateStep()) {
        currentStep.value++;
      } else {
        alert("يرجى ملء جميع الحقول المطلوبة");
      }
    };
    const submitForm = () => {
      form.post(route("courses.store"), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {
          window.location.href = route("courses.sections.create", { course: usePage().props.value.course.id });
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.create_new_course"))}</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, toDisplayString(_ctx.$t("courses.create_new_course")), 1)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><div class="mb-8"${_scopeId}><div class="flex justify-between mb-1"${_scopeId}><!--[-->`);
            ssrRenderList(3, (step) => {
              _push2(`<span class="${ssrRenderClass({ "text-blue-600 font-bold": currentStep.value >= step, "text-gray-400": currentStep.value < step })}"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.step"))} ${ssrInterpolate(step)}: ${ssrInterpolate(stepLabels[step - 1])}</span>`);
            });
            _push2(`<!--]--></div><div class="w-full bg-gray-200 rounded-full h-2.5"${_scopeId}><div class="bg-blue-600 h-2.5 rounded-full" style="${ssrRenderStyle({ width: `${currentStep.value / 3 * 100}%` })}"${_scopeId}></div></div></div><form enctype="multipart/form-data"${_scopeId}>`);
            if (currentStep.value === 1) {
              _push2(`<div${_scopeId}><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.title"))}:</label><input id="title"${ssrRenderAttr("value", unref(form).title)} type="text" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
              if (unref(form).errors.title) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.description"))}:</label><textarea id="description" class="form-textarea w-full rounded-md shadow-sm" rows="3" required${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
              if (unref(form).errors.description) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="category_id" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.category"))}:</label><select id="category_id" class="form-select w-full rounded-md shadow-sm" required${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, "") : ssrLooseEqual(unref(form).category_id, "")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("courses.select_category"))}</option><!--[-->`);
              ssrRenderList(__props.categories, (category) => {
                _push2(`<option${ssrRenderAttr("value", category.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).category_id) ? ssrLooseContain(unref(form).category_id, category.id) : ssrLooseEqual(unref(form).category_id, category.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(category.name)}</option>`);
              });
              _push2(`<!--]--></select>`);
              if (unref(form).errors.category_id) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.category_id)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="price" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.price"))}:</label><input id="price"${ssrRenderAttr("value", unref(form).price)} type="number" min="0" step="0.01" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
              if (unref(form).errors.price) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.price)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 2) {
              _push2(`<div${_scopeId}><div class="mb-4"${_scopeId}><label for="duration" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.duration"))} (${ssrInterpolate(_ctx.$t("courses.in_minutes"))}):</label><input id="duration"${ssrRenderAttr("value", unref(form).duration)} type="number" min="1" class="form-input w-full rounded-md shadow-sm" required${_scopeId}>`);
              if (unref(form).errors.duration) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.duration)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="image" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.image"))}:</label><input id="image" type="file" class="form-input w-full rounded-md shadow-sm" accept="image/*"${_scopeId}>`);
              if (unref(form).errors.image) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.image)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="status" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.status"))}:</label><select id="status" class="form-select w-full rounded-md shadow-sm" required${_scopeId}><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "draft") : ssrLooseEqual(unref(form).status, "draft")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("courses.draft"))}</option><option value="active"${ssrIncludeBooleanAttr(Array.isArray(unref(form).status) ? ssrLooseContain(unref(form).status, "active") : ssrLooseEqual(unref(form).status, "active")) ? " selected" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("courses.active"))}</option></select>`);
              if (unref(form).errors.status) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.status)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="mb-4"${_scopeId}><label for="intro_video" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.intro_video_url"))}:</label><input id="intro_video"${ssrRenderAttr("value", unref(form).intro_video)} type="url" class="form-input w-full rounded-md shadow-sm"${_scopeId}>`);
              if (unref(form).errors.intro_video) {
                _push2(`<div class="text-red-500 text-sm mt-1"${_scopeId}>${ssrInterpolate(unref(form).errors.intro_video)}</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 3) {
              _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.review_information"))}</h3><div class="bg-gray-50 p-4 rounded-md mb-4"${_scopeId}><div class="grid grid-cols-2 gap-4"${_scopeId}><div${_scopeId}><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.title"))}:</strong> ${ssrInterpolate(unref(form).title)}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.description"))}:</strong> ${ssrInterpolate(unref(form).description)}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.category"))}:</strong> ${ssrInterpolate(getCategoryName(unref(form).category_id))}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.price"))}:</strong> ${ssrInterpolate(unref(form).price)}</p></div><div${_scopeId}><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.duration"))}:</strong> ${ssrInterpolate(unref(form).duration)} ${ssrInterpolate(_ctx.$t("courses.minutes"))}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.image"))}:</strong> ${ssrInterpolate(unref(form).image ? unref(form).image.name : _ctx.$t("courses.no_image"))}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.status"))}:</strong> ${ssrInterpolate(unref(form).status)}</p><p${_scopeId}><strong${_scopeId}>${ssrInterpolate(_ctx.$t("courses.intro_video_url"))}:</strong> ${ssrInterpolate(unref(form).intro_video || _ctx.$t("courses.none"))}</p></div></div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex justify-between mt-6"${_scopeId}>`);
            if (currentStep.value > 1) {
              _push2(`<button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.previous"))}</button>`);
            } else {
              _push2(`<div${_scopeId}></div>`);
            }
            if (currentStep.value < 3) {
              _push2(`<button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate(_ctx.$t("courses.next"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            if (currentStep.value === 3) {
              _push2(`<button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>${ssrInterpolate(_ctx.$t("courses.create_course"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></form></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                      createVNode("div", { class: "mb-8" }, [
                        createVNode("div", { class: "flex justify-between mb-1" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(3, (step) => {
                            return createVNode("span", {
                              key: step,
                              class: { "text-blue-600 font-bold": currentStep.value >= step, "text-gray-400": currentStep.value < step }
                            }, toDisplayString(_ctx.$t("courses.step")) + " " + toDisplayString(step) + ": " + toDisplayString(stepLabels[step - 1]), 3);
                          }), 64))
                        ]),
                        createVNode("div", { class: "w-full bg-gray-200 rounded-full h-2.5" }, [
                          createVNode("div", {
                            class: "bg-blue-600 h-2.5 rounded-full",
                            style: { width: `${currentStep.value / 3 * 100}%` }
                          }, null, 4)
                        ])
                      ]),
                      createVNode("form", {
                        onSubmit: withModifiers(submitForm, ["prevent"]),
                        enctype: "multipart/form-data"
                      }, [
                        currentStep.value === 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "title",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.title")) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "title",
                              "onUpdate:modelValue": ($event) => unref(form).title = $event,
                              type: "text",
                              class: "form-input w-full rounded-md shadow-sm",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).title]
                            ]),
                            unref(form).errors.title ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "description",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.description")) + ":", 1),
                            withDirectives(createVNode("textarea", {
                              id: "description",
                              "onUpdate:modelValue": ($event) => unref(form).description = $event,
                              class: "form-textarea w-full rounded-md shadow-sm",
                              rows: "3",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).description]
                            ]),
                            unref(form).errors.description ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "category_id",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.category")) + ":", 1),
                            withDirectives(createVNode("select", {
                              id: "category_id",
                              "onUpdate:modelValue": ($event) => unref(form).category_id = $event,
                              class: "form-select w-full rounded-md shadow-sm",
                              required: ""
                            }, [
                              createVNode("option", { value: "" }, toDisplayString(_ctx.$t("courses.select_category")), 1),
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.categories, (category) => {
                                return openBlock(), createBlock("option", {
                                  key: category.id,
                                  value: category.id
                                }, toDisplayString(category.name), 9, ["value"]);
                              }), 128))
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).category_id]
                            ]),
                            unref(form).errors.category_id ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.category_id), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "price",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.price")) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "price",
                              "onUpdate:modelValue": ($event) => unref(form).price = $event,
                              type: "number",
                              min: "0",
                              step: "0.01",
                              class: "form-input w-full rounded-md shadow-sm",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).price]
                            ]),
                            unref(form).errors.price ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.price), 1)) : createCommentVNode("", true)
                          ])
                        ])) : createCommentVNode("", true),
                        currentStep.value === 2 ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "duration",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.duration")) + " (" + toDisplayString(_ctx.$t("courses.in_minutes")) + "):", 1),
                            withDirectives(createVNode("input", {
                              id: "duration",
                              "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                              type: "number",
                              min: "1",
                              class: "form-input w-full rounded-md shadow-sm",
                              required: ""
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).duration]
                            ]),
                            unref(form).errors.duration ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.duration), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "image",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.image")) + ":", 1),
                            createVNode("input", {
                              id: "image",
                              type: "file",
                              onInput: ($event) => unref(form).image = $event.target.files[0],
                              class: "form-input w-full rounded-md shadow-sm",
                              accept: "image/*"
                            }, null, 40, ["onInput"]),
                            unref(form).errors.image ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.image), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "status",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.status")) + ":", 1),
                            withDirectives(createVNode("select", {
                              id: "status",
                              "onUpdate:modelValue": ($event) => unref(form).status = $event,
                              class: "form-select w-full rounded-md shadow-sm",
                              required: ""
                            }, [
                              createVNode("option", { value: "draft" }, toDisplayString(_ctx.$t("courses.draft")), 1),
                              createVNode("option", { value: "active" }, toDisplayString(_ctx.$t("courses.active")), 1)
                            ], 8, ["onUpdate:modelValue"]), [
                              [vModelSelect, unref(form).status]
                            ]),
                            unref(form).errors.status ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.status), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mb-4" }, [
                            createVNode("label", {
                              for: "intro_video",
                              class: "block text-gray-700 text-sm font-bold mb-2"
                            }, toDisplayString(_ctx.$t("courses.intro_video_url")) + ":", 1),
                            withDirectives(createVNode("input", {
                              id: "intro_video",
                              "onUpdate:modelValue": ($event) => unref(form).intro_video = $event,
                              type: "url",
                              class: "form-input w-full rounded-md shadow-sm"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(form).intro_video]
                            ]),
                            unref(form).errors.intro_video ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-red-500 text-sm mt-1"
                            }, toDisplayString(unref(form).errors.intro_video), 1)) : createCommentVNode("", true)
                          ])
                        ])) : createCommentVNode("", true),
                        currentStep.value === 3 ? (openBlock(), createBlock("div", { key: 2 }, [
                          createVNode("h3", { class: "text-lg font-semibold mb-4" }, toDisplayString(_ctx.$t("courses.review_information")), 1),
                          createVNode("div", { class: "bg-gray-50 p-4 rounded-md mb-4" }, [
                            createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                              createVNode("div", null, [
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.title")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).title), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.description")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).description), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.category")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(getCategoryName(unref(form).category_id)), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.price")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).price), 1)
                                ])
                              ]),
                              createVNode("div", null, [
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.duration")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).duration) + " " + toDisplayString(_ctx.$t("courses.minutes")), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.image")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).image ? unref(form).image.name : _ctx.$t("courses.no_image")), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.status")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).status), 1)
                                ]),
                                createVNode("p", null, [
                                  createVNode("strong", null, toDisplayString(_ctx.$t("courses.intro_video_url")) + ":", 1),
                                  createTextVNode(" " + toDisplayString(unref(form).intro_video || _ctx.$t("courses.none")), 1)
                                ])
                              ])
                            ])
                          ])
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "flex justify-between mt-6" }, [
                          currentStep.value > 1 ? (openBlock(), createBlock("button", {
                            key: 0,
                            onClick: ($event) => currentStep.value--,
                            type: "button",
                            class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                          }, toDisplayString(_ctx.$t("courses.previous")), 9, ["onClick"])) : (openBlock(), createBlock("div", { key: 1 })),
                          currentStep.value < 3 ? (openBlock(), createBlock("button", {
                            key: 2,
                            onClick: nextStep,
                            type: "button",
                            class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                          }, toDisplayString(_ctx.$t("courses.next")), 1)) : createCommentVNode("", true),
                          currentStep.value === 3 ? (openBlock(), createBlock("button", {
                            key: 3,
                            type: "submit",
                            class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                            disabled: unref(form).processing
                          }, toDisplayString(_ctx.$t("courses.create_course")), 9, ["disabled"])) : createCommentVNode("", true)
                        ])
                      ], 32)
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/CreateCourse.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
