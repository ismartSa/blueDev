import { Link, Head } from "@inertiajs/vue3";
import { resolveComponent, mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderStyle, ssrRenderClass } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main = {
  components: { Head, Link },
  props: {
    course: Object,
    statistics: Object,
    enrollmentStatus: Object,
    progress: Number,
    meta: Object
  },
  data() {
    return {
      activeTab: "overview",
      openSections: []
    };
  },
  methods: {
    tabClasses(tabName) {
      return [
        "tab-button py-4 px-6 text-sm font-medium text-center border-b-2",
        this.activeTab === tabName ? "border-indigo-500 text-indigo-600" : "border-transparent hover:text-gray-700 hover:border-gray-300"
      ];
    },
    toggleSection(sectionId) {
      const index = this.openSections.indexOf(sectionId);
      if (index > -1) {
        this.openSections.splice(index, 1);
      } else {
        this.openSections.push(sectionId);
      }
    },
    formatDuration(minutes) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h ${mins}m`;
    },
    formatSectionDuration(section) {
      const totalMinutes = section.lectures.reduce((sum, lecture) => sum + lecture.duration, 0);
      return this.formatDuration(totalMinutes);
    },
    enrollCourse() {
      if (this.enrollmentStatus.enrolled) ;
      else {
        this.$inertia.post(route("enrollments.store", { course_id: this.course.id }));
      }
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  var _a, _b, _c;
  const _component_Head = resolveComponent("Head");
  const _component_Link = resolveComponent("Link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-gray-50" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Head, {
    title: $props.meta.title,
    description: $props.meta.description
  }, null, _parent));
  _push(`<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><nav class="flex mb-6" aria-label="Breadcrumb"><ol class="inline-flex items-center space-x-1 md:space-x-3"><li class="inline-flex items-center">`);
  _push(ssrRenderComponent(_component_Link, {
    href: "/",
    class: "inline-flex items-center text-sm font-medium text-gray-700 hover:text-indigo-600"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fas fa-home mr-2"${_scopeId}></i> Home `);
      } else {
        return [
          createVNode("i", { class: "fas fa-home mr-2" }),
          createTextVNode(" Home ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li><div class="flex items-center"><i class="fas fa-chevron-right text-gray-400"></i>`);
  _push(ssrRenderComponent(_component_Link, {
    href: "/courses",
    class: "ml-1 text-sm font-medium text-gray-700 hover:text-indigo-600 md:ml-2"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Courses`);
      } else {
        return [
          createTextVNode("Courses")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></li><li aria-current="page"><div class="flex items-center"><i class="fas fa-chevron-right text-gray-400"></i><span class="ml-1 text-sm font-medium text-indigo-600 md:ml-2">${ssrInterpolate($props.course.title)}</span></div></li></ol></nav><div class="bg-white rounded-xl shadow-md overflow-hidden mb-8"><div class="md:flex"><div class="md:w-2/3 p-8"><div class="flex items-center mb-2"><span class="bg-indigo-100 text-indigo-800 text-xs font-semibold px-2.5 py-0.5 rounded">${ssrInterpolate($props.course.level)}</span><span class="ml-2 text-sm text-gray-500"><i class="fas fa-star text-yellow-400"></i> ${ssrInterpolate($props.course.rating)} (${ssrInterpolate($props.course.reviews_count)} reviews) </span></div><h1 class="text-3xl font-bold text-gray-900 mb-4">${ssrInterpolate($props.course.title)}</h1><p class="text-gray-600 mb-6">${ssrInterpolate($props.course.description)}</p>`);
  if ($props.course.instructors) {
    _push(`<div class="flex items-center mb-4"><div class="flex -space-x-2"><!--[-->`);
    ssrRenderList($props.course.instructors, (instructor) => {
      _push(`<img class="w-8 h-8 rounded-full border-2 border-white"${ssrRenderAttr("src", instructor.avatar)}${ssrRenderAttr("alt", instructor.name)}>`);
    });
    _push(`<!--]--></div>`);
    if ($props.course.instructors.length > 3) {
      _push(`<span class="ml-3 text-sm text-gray-500">+${ssrInterpolate($props.course.instructors.length - 3)} instructors</span>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="flex flex-wrap gap-4"><div class="flex items-center text-gray-600"><i class="fas fa-clock mr-2 text-indigo-500"></i><span>${ssrInterpolate($props.statistics.durationFormatted)}</span></div><div class="flex items-center text-gray-600"><i class="fas fa-layer-group mr-2 text-indigo-500"></i><span>${ssrInterpolate($props.course.sections_count)} modules</span></div>`);
  if ($props.course.certificate) {
    _push(`<div class="flex items-center text-gray-600"><i class="fas fa-certificate mr-2 text-indigo-500"></i><span>Certificate</span></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div><div class="md:w-1/3 bg-gray-50 p-8 border-l border-gray-200"><div class="sticky top-8"><div class="video-container mb-6 rounded-lg overflow-hidden"><iframe${ssrRenderAttr("src", $props.course.preview_video)} frameborder="0" allowfullscreen></iframe></div>`);
  if ((_a = $props.enrollmentStatus) == null ? void 0 : _a.enrolled) {
    _push(`<div class="bg-indigo-50 p-4 rounded-lg mb-6"><div class="flex justify-between items-center mb-2"><span class="text-sm font-medium text-gray-700">Course Progress</span><span class="text-sm font-medium text-indigo-600">${ssrInterpolate($props.progress || 0)}%</span></div><div class="progress-bar"><div class="progress-value" style="${ssrRenderStyle(`width: ${$props.progress || 0}%`)}"></div></div>`);
    if ($props.progress >= 80) {
      _push(`<div class="mt-2 text-xs text-gray-500"><i class="fas fa-certificate text-yellow-500 mr-1"></i> Eligible for certificate </div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="mb-6"><div class="flex items-center justify-between mb-2"><span class="text-2xl font-bold text-gray-900">$${ssrInterpolate($props.course.price)}</span>`);
  if ($props.course.original_price) {
    _push(`<span class="text-sm text-gray-500 line-through">$${ssrInterpolate($props.course.original_price)}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><button class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200">${ssrInterpolate($props.enrollmentStatus.enrolled ? "Continue Course" : "Enroll Now")}</button></div><div class="border-t border-gray-200 pt-4"><h3 class="text-sm font-medium text-gray-700 mb-3">This course includes:</h3><ul class="space-y-2"><!--[-->`);
  ssrRenderList($props.course.features, (feature) => {
    _push(`<li class="flex items-center text-sm text-gray-600"><i class="fas fa-video mr-3 text-indigo-500"></i><span>${ssrInterpolate(feature)}</span></li>`);
  });
  _push(`<!--]--></ul></div></div></div></div></div><div class="bg-white rounded-xl shadow-sm overflow-hidden mb-8"><div class="border-b border-gray-200"><nav class="flex -mb-px"><button class="${ssrRenderClass($options.tabClasses("overview"))}"> Overview </button><button class="${ssrRenderClass($options.tabClasses("curriculum"))}"> Curriculum </button><button class="${ssrRenderClass($options.tabClasses("instructors"))}"> Instructors </button><button class="${ssrRenderClass($options.tabClasses("reviews"))}"> Reviews </button></nav></div><div class="p-8"><div style="${ssrRenderStyle($data.activeTab === "overview" ? null : { display: "none" })}" class="tab-content"><h2 class="text-2xl font-bold text-gray-900 mb-6">About This Course</h2><p class="text-gray-600 mb-6">${ssrInterpolate($props.course.long_description)}</p><div class="mb-8"><h3 class="text-xl font-semibold text-gray-900 mb-4">What You&#39;ll Learn</h3><div class="grid md:grid-cols-2 gap-4"><!--[-->`);
  ssrRenderList($props.course.learnings, (learning, index) => {
    _push(`<div class="flex items-start"><i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i><span class="text-gray-600">${ssrInterpolate(learning)}</span></div>`);
  });
  _push(`<!--]--></div></div></div><div style="${ssrRenderStyle($data.activeTab === "curriculum" ? null : { display: "none" })}" class="tab-content"><div class="flex justify-between items-center mb-6"><h2 class="text-2xl font-bold text-gray-900">Course Curriculum</h2><div class="text-sm text-gray-500">${ssrInterpolate($props.course.sections_count || 0)} modules • ${ssrInterpolate(((_b = $props.statistics) == null ? void 0 : _b.lecturesCount) || 0)} lessons • ${ssrInterpolate(((_c = $props.statistics) == null ? void 0 : _c.durationFormatted) || "0h 0m")}</div></div><div class="space-y-4">`);
  if ($props.course.sections && $props.course.sections.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($props.course.sections, (section) => {
      _push(`<div class="border border-gray-200 rounded-lg overflow-hidden"><button class="module-toggle w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100"><div class="flex items-center"><i class="fas fa-folder-open text-indigo-500 mr-3"></i><span class="font-medium">${ssrInterpolate(section.title)}</span></div><div class="flex items-center"><span class="text-sm text-gray-500 mr-4">${ssrInterpolate(section.lectures_count || 0)} lessons • ${ssrInterpolate($options.formatSectionDuration(section))}</span><i class="${ssrRenderClass([{ "rotate-180": $data.openSections.includes(section.id) }, "fas fa-chevron-down text-gray-400 transition-transform duration-200"])}"></i></div></button><div style="${ssrRenderStyle($data.openSections.includes(section.id) ? null : { display: "none" })}" class="module-content"><div class="divide-y divide-gray-200">`);
      if (section.lectures && section.lectures.length > 0) {
        _push(`<!--[-->`);
        ssrRenderList(section.lectures, (lecture) => {
          _push(`<div class="module-item p-4 hover:bg-indigo-50 cursor-pointer flex items-center"><i class="fas fa-play-circle text-indigo-500 mr-4"></i><div class="flex-grow"><div class="flex justify-between"><span>${ssrInterpolate(lecture.title)}</span><span class="text-sm text-gray-500">${ssrInterpolate($options.formatDuration(lecture.duration || 0))}</span></div>`);
          if (lecture.is_preview) {
            _push(`<div class="text-sm text-gray-500 mt-1">Free preview</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<div class="p-4 text-center text-gray-500"> لا توجد محاضرات متاحة في هذا القسم حتى الآن. </div>`);
      }
      _push(`</div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<div class="text-center py-8 bg-white rounded-lg border border-gray-200"><i class="fas fa-book-open text-indigo-400 text-4xl mb-4"></i><p class="text-gray-500">لا توجد أقسام منهج دراسي متاحة لهذه الدورة حتى الآن.</p></div>`);
  }
  _push(`</div></div><div style="${ssrRenderStyle($data.activeTab === "instructors" ? null : { display: "none" })}" class="tab-content"><h2 class="text-2xl font-bold text-gray-900 mb-6">Meet Your Instructors</h2><div class="grid md:grid-cols-2 gap-8"><!--[-->`);
  ssrRenderList($props.course.instructors, (instructor) => {
    _push(`<div class="flex items-start"><img class="w-16 h-16 rounded-full object-cover mr-4"${ssrRenderAttr("src", instructor.avatar)}${ssrRenderAttr("alt", instructor.name)}><div><h3 class="text-lg font-semibold text-gray-900">${ssrInterpolate(instructor.name)}</h3><p class="text-sm text-indigo-600 mb-2">${ssrInterpolate(instructor.position)}</p><p class="text-gray-600 text-sm">${ssrInterpolate(instructor.bio)}</p></div></div>`);
  });
  _push(`<!--]--></div></div><div style="${ssrRenderStyle($data.activeTab === "reviews" ? null : { display: "none" })}" class="tab-content"><div class="flex justify-between items-center mb-6"><div><h2 class="text-2xl font-bold text-gray-900">Student Reviews</h2><div class="flex items-center mt-2"><div class="flex items-center"><!--[-->`);
  ssrRenderList(5, (star) => {
    _push(`<i class="${ssrRenderClass([star <= $props.course.rating ? "text-yellow-400" : "text-gray-300", "fas fa-star"])}"></i>`);
  });
  _push(`<!--]--></div><span class="ml-2 text-sm text-gray-500">${ssrInterpolate($props.course.rating)} out of 5 (${ssrInterpolate($props.course.reviews_count)} reviews) </span></div></div>`);
  if ($props.enrollmentStatus.enrolled) {
    _push(`<button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200"> Write a Review </button>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="space-y-6"><!--[-->`);
  ssrRenderList($props.course.reviews, (review) => {
    _push(`<div class="border-b border-gray-200 pb-6"></div>`);
  });
  _push(`<!--]--></div></div></div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Index/Course/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Show = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Show as default
};
