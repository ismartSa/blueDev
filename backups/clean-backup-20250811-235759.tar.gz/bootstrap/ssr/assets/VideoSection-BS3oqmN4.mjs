import { computed, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
const _sfc_main = {
  __name: "VideoSection",
  __ssrInlineRender: true,
  props: {
    videoUrl: {
      type: String,
      required: true,
      validator: (value) => value.startsWith("http") || value.startsWith("/")
    },
    lectureTitle: {
      type: String,
      required: true,
      default: "Untitled Lecture"
    }
  },
  emits: ["videoEnded", "timeUpdate"],
  setup(__props, { emit: __emit }) {
    const videoClasses = computed(() => [
      "w-full",
      "h-auto",
      "rounded-lg",
      "shadow-lg",
      "focus:outline-none"
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lg:col-span-2 space-y-4" }, _attrs))}><div class="relative aspect-video"><video class="${ssrRenderClass(videoClasses.value)}" controls><source${ssrRenderAttr("src", __props.videoUrl)} type="video/mp4"><track kind="captions" src="" label="English" srclang="en" default> Your browser does not support HTML5 video. </video></div><h3 class="text-xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(__props.lectureTitle)}</h3></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Player/VideoSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
