import { mergeProps, unref, withCtx, createVNode, withModifiers, withDirectives, vModelText, createBlock, openBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { _ as _sfc_main$2 } from "./Breadcrumb-BsPLZkqL.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "CreateLecture",
  __ssrInlineRender: true,
  props: {
    title: String,
    course: Object,
    sections: Array,
    breadcrumbs: Object
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      title: "",
      section_id: null,
      video_url: "",
      duration: 0
    });
    const submitForm = () => {
      form.post(route("course.create.lecture", { courseId: props.course.id }), {
        preserveScroll: true,
        onSuccess: () => {
          form.reset();
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(Head), { title: "Create New Lecture" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="p-4"${_scopeId}><header${_scopeId}><h2 class="text-xl font-bold"${_scopeId}>Create New Lecture</h2></header><form${_scopeId}><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 font-bold mb-2"${_scopeId}>Lecture Title:</label><input type="text" id="title"${ssrRenderAttr("value", unref(form).title)} class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="section_id" class="block text-gray-700 font-bold mb-2"${_scopeId}>Section:</label><select id="section_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}><!--[-->`);
            ssrRenderList(__props.sections, (section) => {
              _push2(`<option${ssrRenderAttr("value", section.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).section_id) ? ssrLooseContain(unref(form).section_id, section.id) : ssrLooseEqual(unref(form).section_id, section.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(section.title)}</option>`);
            });
            _push2(`<!--]--></select></div><div class="mb-4"${_scopeId}><label for="video_url" class="block text-gray-700 font-bold mb-2"${_scopeId}>Video URL:</label><input type="text" id="video_url"${ssrRenderAttr("value", unref(form).video_url)} class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="duration" class="block text-gray-700 font-bold mb-2"${_scopeId}>Video Duration (in minutes):</label><input type="number" id="duration"${ssrRenderAttr("value", unref(form).duration)} class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus-shadow-outline"${_scopeId}> Create Lecture </button></form></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"]),
              createVNode("div", { class: "p-4" }, [
                createVNode("header", null, [
                  createVNode("h2", { class: "text-xl font-bold" }, "Create New Lecture")
                ]),
                createVNode("form", {
                  onSubmit: withModifiers(submitForm, ["prevent"])
                }, [
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("label", {
                      for: "title",
                      class: "block text-gray-700 font-bold mb-2"
                    }, "Lecture Title:"),
                    withDirectives(createVNode("input", {
                      type: "text",
                      id: "title",
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).title]
                    ])
                  ]),
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("label", {
                      for: "section_id",
                      class: "block text-gray-700 font-bold mb-2"
                    }, "Section:"),
                    withDirectives(createVNode("select", {
                      id: "section_id",
                      "onUpdate:modelValue": ($event) => unref(form).section_id = $event,
                      class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.sections, (section) => {
                        return openBlock(), createBlock("option", {
                          key: section.id,
                          value: section.id
                        }, toDisplayString(section.title), 9, ["value"]);
                      }), 128))
                    ], 8, ["onUpdate:modelValue"]), [
                      [vModelSelect, unref(form).section_id]
                    ])
                  ]),
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("label", {
                      for: "video_url",
                      class: "block text-gray-700 font-bold mb-2"
                    }, "Video URL:"),
                    withDirectives(createVNode("input", {
                      type: "text",
                      id: "video_url",
                      "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
                      class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).video_url]
                    ])
                  ]),
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("label", {
                      for: "duration",
                      class: "block text-gray-700 font-bold mb-2"
                    }, "Video Duration (in minutes):"),
                    withDirectives(createVNode("input", {
                      type: "number",
                      id: "duration",
                      "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                      class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [
                        vModelText,
                        unref(form).duration,
                        void 0,
                        { number: true }
                      ]
                    ])
                  ]),
                  createVNode("button", {
                    type: "submit",
                    class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus-shadow-outline"
                  }, " Create Lecture ")
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/CreateLecture.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
