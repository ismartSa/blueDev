import { useSSRContext, ref, watch, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, withModifiers, computed, createBlock, createCommentVNode, openBlock, reactive, nextTick, withDirectives, vModelSelect, vShow, onMounted, onUnmounted, Transition } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrRenderStyle, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _sfc_main$q } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { Link, useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$l } from "./PrimaryButton-Be3Csrwm.mjs";
import { _ as _sfc_main$i } from "./Modal-UKMpWsGi.mjs";
import { _ as _sfc_main$m } from "./InputLabel-CUhtyl2S.mjs";
import { _ as _sfc_main$j } from "./TextInput-BXI4L1ZJ.mjs";
import { _ as _sfc_main$n } from "./TextArea-D6-Dt9po.mjs";
import { _ as _sfc_main$o } from "./SelectInput-BcLpPrB1.mjs";
import { _ as _sfc_main$g } from "./SecondaryButton-DkF3Mn0U.mjs";
import { _ as _sfc_main$k } from "./InputError-C7WpniWA.mjs";
import { ClockIcon, BookOpenIcon, ChartBarIcon, PencilIcon, UsersIcon, AcademicCapIcon, EyeIcon, StarIcon, PlayIcon, TrashIcon, PauseIcon, BackwardIcon, ForwardIcon, SpeakerWaveIcon, SpeakerXMarkIcon, XMarkIcon, PlusIcon, ArrowLeftIcon } from "@heroicons/vue/24/solid";
import { _ as _sfc_main$h } from "./DangerButton-BPvkamuy.mjs";
import { _ as _sfc_main$p } from "./Checkbox-C7w3fFTm.mjs";
import { _ as _sfc_main$r } from "./Breadcrumb-BsPLZkqL.mjs";
import { UsersIcon as UsersIcon$1, EyeIcon as EyeIcon$1, ClockIcon as ClockIcon$1 } from "@heroicons/vue/24/outline";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main$f = {
  setup(__props, { emit: __emit }) {
    const props = __props;
    ref(null);
    const previewUrl = ref(null);
    const fileName = ref("");
    watch(() => props.modelValue, (newValue) => {
      if (newValue instanceof File) {
        fileName.value = newValue.name;
        if (props.preview && newValue.type.startsWith("image/")) {
          const reader = new FileReader();
          reader.onload = (e) => {
            previewUrl.value = e.target.result;
          };
          reader.readAsDataURL(newValue);
        }
      } else if (typeof newValue === "string" && newValue) {
        fileName.value = newValue.split("/").pop();
        if (props.preview) {
          previewUrl.value = newValue;
        }
      } else {
        fileName.value = "";
        previewUrl.value = null;
      }
    }, { immediate: true });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "file-input-container" }, _attrs))} data-v-5e60cee0><input type="file"${ssrRenderAttr("accept", __props.accept)} class="hidden" data-v-5e60cee0><div class="file-input-wrapper" data-v-5e60cee0><div class="${ssrRenderClass([{ "border-red-300": __props.error }, "file-input-button"])}" data-v-5e60cee0><div class="flex items-center justify-between" data-v-5e60cee0><span class="text-gray-500 truncate" data-v-5e60cee0>${ssrInterpolate(fileName.value || __props.placeholder)}</span><div class="flex items-center space-x-2" data-v-5e60cee0><svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-v-5e60cee0><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" data-v-5e60cee0></path></svg><span class="text-sm text-blue-600 hover:text-blue-800" data-v-5e60cee0>Browse</span></div></div></div>`);
      if (fileName.value) {
        _push(`<button type="button" class="clear-button" data-v-5e60cee0><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-v-5e60cee0><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" data-v-5e60cee0></path></svg></button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (__props.error) {
        _push(`<div class="mt-1 text-sm text-red-600" data-v-5e60cee0>${ssrInterpolate(__props.error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.preview && previewUrl.value) {
        _push(`<div class="mt-3" data-v-5e60cee0><img${ssrRenderAttr("src", previewUrl.value)} alt="Preview" class="w-32 h-32 object-cover rounded-lg border border-gray-200" data-v-5e60cee0></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FileInput.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const _sfc_main$e = {
  __name: "CourseTabs",
  __ssrInlineRender: true,
  props: {
    activeTab: { type: String, required: true },
    lessonsCount: { type: Number, default: 0 },
    quizzesCount: { type: Number, default: 0 }
  },
  emits: ["update:activeTab"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const tabs = [
      { id: "lessons", name: `Lessons (${props.lessonsCount})`, icon: "VideoCameraIcon" },
      { id: "quizzes", name: `Quizzes (${props.quizzesCount})`, icon: "AcademicCapIcon" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-750" }, _attrs))}><nav class="flex space-x-8 px-6" dir="ltr"><!--[-->`);
      ssrRenderList(tabs, (tab) => {
        _push(`<button class="${ssrRenderClass([
          __props.activeTab === tab.id ? "border-blue-500 text-blue-600 dark:text-blue-400 bg-white dark:bg-gray-800" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300",
          "whitespace-nowrap py-3 px-4 border-b-2 font-medium text-sm transition-all duration-200 rounded-t-lg"
        ])}">${ssrInterpolate(tab.name)}</button>`);
      });
      _push(`<!--]--></nav></div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseTabs.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const _sfc_main$d = {
  __name: "CourseOverview",
  __ssrInlineRender: true,
  props: {
    course: { type: Object, required: true },
    stats: { type: Object, default: () => ({}) },
    courseProgress: { type: Number, default: 0 },
    lessonsCount: { type: Number, default: 0 }
  },
  setup(__props) {
    const props = __props;
    const formatDate = (date) => {
      if (!date) return "N/A";
      return new Date(date).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
      });
    };
    const getStatusColor = (status) => {
      const colors = {
        active: "text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/30",
        inactive: "text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/30",
        draft: "text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/30"
      };
      return colors[status] || "text-gray-600 bg-gray-100 dark:text-gray-400 dark:bg-gray-700";
    };
    const getCourseImage = () => {
      if (props.course.thumbnail) {
        return props.course.thumbnail;
      }
      if (props.course.image) {
        return props.course.image;
      }
      const courseId = props.course.id || 1;
      return `https://picsum.photos/seed/${courseId}/800/450`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-8" }, _attrs))}><div class="relative bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-800 dark:to-gray-700 rounded-2xl overflow-hidden"><div class="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-indigo-600/10 dark:from-blue-900/20 dark:to-indigo-900/20"></div><div class="relative p-8"><div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center"><div class="lg:col-span-1"><div class="relative group"><img${ssrRenderAttr("src", getCourseImage())}${ssrRenderAttr("alt", __props.course.title)} class="w-full h-64 lg:h-48 object-cover rounded-xl shadow-lg transition-transform duration-300 group-hover:scale-105"><div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div></div></div><div class="lg:col-span-2 space-y-4"><div><div class="flex items-center gap-3 mb-3"><span class="${ssrRenderClass([getStatusColor(__props.course.status), "px-3 py-1 rounded-full text-sm font-medium"])}">${ssrInterpolate(__props.course.status)}</span><span class="text-sm text-gray-500 dark:text-gray-400">${ssrInterpolate(((_a = __props.course.category) == null ? void 0 : _a.name) || "Course")}</span></div><h1 class="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-3">${ssrInterpolate(__props.course.title)}</h1><p class="text-lg text-gray-600 dark:text-gray-300 leading-relaxed mb-4">${ssrInterpolate(__props.course.description || "Comprehensive course designed to enhance your skills and knowledge.")}</p></div><div class="flex flex-wrap items-center gap-6 text-sm text-gray-500 dark:text-gray-400"><div class="flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(ClockIcon), { class: "h-4 w-4" }, null, _parent));
      _push(`<span>Created ${ssrInterpolate(formatDate(__props.course.created_at))}</span></div><div class="flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(BookOpenIcon), { class: "h-4 w-4" }, null, _parent));
      _push(`<span>Course ID: ${ssrInterpolate(__props.course.id)}</span></div></div></div></div></div></div><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-lg"><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-6 flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(ChartBarIcon), { class: "h-5 w-5 text-blue-600 dark:text-blue-400" }, null, _parent));
      _push(` Quick Actions </h3><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">`);
      _push(ssrRenderComponent(unref(Link), {
        href: `/dashboard/courses/${__props.course.id}/edit`,
        class: "bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-105"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(PencilIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(` Edit Course `);
          } else {
            return [
              createVNode(unref(PencilIcon), { class: "h-5 w-5" }),
              createTextVNode(" Edit Course ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-105">`);
      _push(ssrRenderComponent(unref(ChartBarIcon), { class: "h-5 w-5" }, null, _parent));
      _push(` View Analytics </button><button class="bg-green-600 hover:bg-green-700 text-white px-6 py-4 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-105">`);
      _push(ssrRenderComponent(unref(BookOpenIcon), { class: "h-5 w-5" }, null, _parent));
      _push(` Export Data </button><button class="bg-purple-600 hover:bg-purple-700 text-white px-6 py-4 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-105">`);
      _push(ssrRenderComponent(unref(UsersIcon), { class: "h-5 w-5" }, null, _parent));
      _push(` Manage Enrollments </button><button class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-4 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-105">`);
      _push(ssrRenderComponent(unref(AcademicCapIcon), { class: "h-5 w-5" }, null, _parent));
      _push(` Course Settings </button></div></div><div class="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 shadow-lg"><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(ChartBarIcon), { class: "h-5 w-5 text-blue-600" }, null, _parent));
      _push(` Course Progress </h3><div class="flex justify-between mb-4"><div class="text-center"><div class="text-2xl font-bold text-blue-600">${ssrInterpolate(props.courseProgress)}%</div><div class="text-xs text-gray-500">Complete</div></div><div class="text-center"><div class="text-2xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(props.lessonsCount)}</div><div class="text-xs text-gray-500">Lessons</div></div><div class="text-center"><div class="text-2xl font-bold text-green-600">${ssrInterpolate(Math.ceil(props.lessonsCount * props.courseProgress / 100))}</div><div class="text-xs text-gray-500">Done</div></div></div><div class="bg-gray-200 dark:bg-gray-600 rounded-full h-2 mb-3"><div class="bg-blue-500 h-2 rounded-full transition-all duration-500" style="${ssrRenderStyle({ width: `${props.courseProgress}%` })}"></div></div><div class="flex gap-1 text-xs">`);
      if (props.courseProgress >= 25) {
        _push(`<span class="bg-blue-100 text-blue-800 px-2 py-1 rounded">🌟</span>`);
      } else {
        _push(`<!---->`);
      }
      if (props.courseProgress >= 50) {
        _push(`<span class="bg-green-100 text-green-800 px-2 py-1 rounded">🔥</span>`);
      } else {
        _push(`<!---->`);
      }
      if (props.courseProgress >= 75) {
        _push(`<span class="bg-purple-100 text-purple-800 px-2 py-1 rounded">💪</span>`);
      } else {
        _push(`<!---->`);
      }
      if (props.courseProgress >= 100) {
        _push(`<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">🏆</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group"><div class="flex items-center justify-between mb-4"><div class="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg group-hover:bg-blue-200 dark:group-hover:bg-blue-800/50 transition-colors">`);
      _push(ssrRenderComponent(unref(UsersIcon), { class: "h-6 w-6 text-blue-600 dark:text-blue-400" }, null, _parent));
      _push(`</div><div class="text-right"><p class="text-2xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(__props.stats.enrolled_students || 0)}</p><p class="text-sm text-gray-500 dark:text-gray-400">Students</p></div></div><div class="flex items-center justify-between"><span class="text-sm font-medium text-gray-600 dark:text-gray-300">Enrolled Students</span><span class="text-xs text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/30 px-2 py-1 rounded-full">Active</span></div></div><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group"><div class="flex items-center justify-between mb-4"><div class="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg group-hover:bg-green-200 dark:group-hover:bg-green-800/50 transition-colors">`);
      _push(ssrRenderComponent(unref(EyeIcon), { class: "h-6 w-6 text-green-600 dark:text-green-400" }, null, _parent));
      _push(`</div><div class="text-right"><p class="text-2xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(__props.stats.total_views || 0)}</p><p class="text-sm text-gray-500 dark:text-gray-400">Views</p></div></div><div class="flex items-center justify-between"><span class="text-sm font-medium text-gray-600 dark:text-gray-300">Total Views</span><span class="text-xs text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30 px-2 py-1 rounded-full">Trending</span></div></div><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group"><div class="flex items-center justify-between mb-4"><div class="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg group-hover:bg-purple-200 dark:group-hover:bg-purple-800/50 transition-colors">`);
      _push(ssrRenderComponent(unref(BookOpenIcon), { class: "h-6 w-6 text-purple-600 dark:text-purple-400" }, null, _parent));
      _push(`</div><div class="text-right"><p class="text-2xl font-bold text-gray-900 dark:text-white">$${ssrInterpolate(__props.course.price || 0)}</p><p class="text-sm text-gray-500 dark:text-gray-400">Price</p></div></div><div class="flex items-center justify-between"><span class="text-sm font-medium text-gray-600 dark:text-gray-300">Course Price</span><span class="text-xs text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/30 px-2 py-1 rounded-full">Premium</span></div></div><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group"><div class="flex items-center justify-between mb-4"><div class="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg group-hover:bg-orange-200 dark:group-hover:bg-orange-800/50 transition-colors">`);
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-6 w-6 text-orange-600 dark:text-orange-400" }, null, _parent));
      _push(`</div><div class="text-right"><p class="text-2xl font-bold text-gray-900 dark:text-white">4.8</p><p class="text-sm text-gray-500 dark:text-gray-400">Rating</p></div></div><div class="flex items-center justify-between"><span class="text-sm font-medium text-gray-600 dark:text-gray-300">Course Rating</span><div class="flex items-center gap-1">`);
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-3 w-3 text-orange-400" }, null, _parent));
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-3 w-3 text-orange-400" }, null, _parent));
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-3 w-3 text-orange-400" }, null, _parent));
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-3 w-3 text-orange-400" }, null, _parent));
      _push(ssrRenderComponent(unref(StarIcon), { class: "h-3 w-3 text-orange-400" }, null, _parent));
      _push(`</div></div></div></div><div class="grid grid-cols-1 lg:grid-cols-3 gap-8"><div class="lg:col-span-3 space-y-6"><div class="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700"><h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-6 flex items-center gap-2">`);
      _push(ssrRenderComponent(unref(AcademicCapIcon), { class: "h-5 w-5 text-blue-600 dark:text-blue-400" }, null, _parent));
      _push(` Course Details </h3><div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div class="space-y-4"><div class="flex justify-between items-center py-3 border-b border-gray-100 dark:border-gray-700"><span class="text-gray-600 dark:text-gray-400 font-medium">Description </span><span class="text-gray-900 dark:text-white font-semibold">${ssrInterpolate(__props.course.description || "Comprehensive course designed to enhance your skills and knowledge.")}</span></div><div class="flex justify-between items-center py-3 border-b border-gray-100 dark:border-gray-700"><span class="text-gray-600 dark:text-gray-400 font-medium">Category</span><span class="text-gray-900 dark:text-white font-semibold">${ssrInterpolate(((_b = __props.course.category) == null ? void 0 : _b.name) || "Uncategorized")}</span></div><div class="flex justify-between items-center py-3"><span class="text-gray-600 dark:text-gray-400 font-medium">Status</span><span class="${ssrRenderClass([getStatusColor(__props.course.status), "px-3 py-1 rounded-full text-sm font-medium"])}">${ssrInterpolate(__props.course.status)}</span></div></div><div class="space-y-4"><div class="flex justify-between items-center py-3 border-b border-gray-100 dark:border-gray-700"><span class="text-gray-600 dark:text-gray-400 font-medium">Created</span><span class="text-gray-900 dark:text-white font-semibold">${ssrInterpolate(formatDate(__props.course.created_at))}</span></div><div class="flex justify-between items-center py-3 border-b border-gray-100 dark:border-gray-700"><span class="text-gray-600 dark:text-gray-400 font-medium">Last Updated</span><span class="text-gray-900 dark:text-white font-semibold">${ssrInterpolate(formatDate(__props.course.updated_at))}</span></div><div class="flex justify-between items-center py-3"><span class="text-gray-600 dark:text-gray-400 font-medium">Price</span><span class="text-gray-900 dark:text-white font-semibold">$${ssrInterpolate(__props.course.price || 0)}</span></div></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseOverview.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const _sfc_main$c = {
  __name: "LessonList",
  __ssrInlineRender: true,
  props: {
    lessons: { type: Array, default: () => [] }
  },
  emits: ["edit", "play", "delete", "success"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const formatDuration = (seconds) => {
      if (!seconds) return "0:00";
      const minutes = Math.floor(seconds / 60);
      const remainingSeconds = seconds % 60;
      return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4" }, _attrs))}>`);
      if (!__props.lessons || __props.lessons.length === 0) {
        _push(`<div class="text-center py-8"><p class="text-gray-500 dark:text-gray-400">No lessons available yet.</p><p class="text-sm text-gray-400 dark:text-gray-500 mt-2">Click &quot;Add Lesson&quot; to create your first lesson.</p></div>`);
      } else {
        _push(`<div class="space-y-3"><!--[-->`);
        ssrRenderList(__props.lessons, (lesson, index) => {
          _push(`<div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 border border-gray-200 dark:border-gray-600"><div class="flex items-center justify-between"><div class="flex items-center space-x-4 flex-1"><div class="flex-shrink-0"><span class="inline-flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm font-medium">${ssrInterpolate(index + 1)}</span></div><div class="flex-1 min-w-0"><h3 class="text-lg font-medium text-gray-900 dark:text-white truncate">${ssrInterpolate(lesson.title)}</h3>`);
          if (lesson.description) {
            _push(`<p class="text-sm text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">${ssrInterpolate(lesson.description)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="flex items-center space-x-4 mt-2 text-sm text-gray-500 dark:text-gray-400">`);
          if (lesson.duration) {
            _push(`<span> Duration: ${ssrInterpolate(formatDuration(lesson.duration))}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (lesson.type) {
            _push(`<span class="capitalize"> Type: ${ssrInterpolate(lesson.type)}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (lesson.is_free) {
            _push(`<span class="text-green-600 dark:text-green-400"> Free </span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div></div><div class="flex items-center space-x-2 ml-4">`);
          _push(ssrRenderComponent(_sfc_main$g, {
            onClick: ($event) => emit("play", lesson, index),
            class: "!p-2",
            title: "Play Lesson"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(PlayIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(PlayIcon), { class: "h-4 w-4" })
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(ssrRenderComponent(_sfc_main$g, {
            onClick: ($event) => emit("edit", lesson),
            class: "!p-2",
            title: "Edit Lesson"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(PencilIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(PencilIcon), { class: "h-4 w-4" })
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(ssrRenderComponent(_sfc_main$h, {
            onClick: ($event) => emit("delete", lesson),
            class: "!p-2",
            title: "Delete Lesson"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(TrashIcon), { class: "h-4 w-4" })
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div></div>`);
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/LessonList.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const _sfc_main$b = {
  __name: "QuickSectionModal",
  __ssrInlineRender: true,
  props: {
    show: { type: Boolean, default: false },
    courseId: { type: [Number, String], required: true }
  },
  emits: ["close", "success"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({
      title: "",
      description: "",
      course_id: props.courseId
    });
    const submit = () => {
      form.post(route("course.sections.store"), {
        onSuccess: () => {
          emit("success");
          closeModal();
        }
      });
    };
    const closeModal = () => {
      emit("close");
      form.reset();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$i, mergeProps({
        show: __props.show,
        onClose: closeModal
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-4"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4"${_scopeId}> Quick Add Section </h2><form class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$j, {
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              placeholder: "Section title...",
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.title
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex justify-end space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$g, { onClick: closeModal }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Cancel`);
                } else {
                  return [
                    createTextVNode("Cancel")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$l, {
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? "Adding..." : "Add")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? "Adding..." : "Add"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "p-4" }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100 mb-4" }, " Quick Add Section "),
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"]),
                  class: "space-y-4"
                }, [
                  createVNode(_sfc_main$j, {
                    modelValue: unref(form).title,
                    "onUpdate:modelValue": ($event) => unref(form).title = $event,
                    placeholder: "Section title...",
                    required: "",
                    autofocus: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_sfc_main$k, {
                    message: unref(form).errors.title
                  }, null, 8, ["message"]),
                  createVNode("div", { class: "flex justify-end space-x-2" }, [
                    createVNode(_sfc_main$g, { onClick: closeModal }, {
                      default: withCtx(() => [
                        createTextVNode("Cancel")
                      ]),
                      _: 1
                    }),
                    createVNode(_sfc_main$l, {
                      disabled: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(unref(form).processing ? "Adding..." : "Add"), 1)
                      ]),
                      _: 1
                    }, 8, ["disabled"])
                  ])
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/QuickSectionModal.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  __name: "LessonModal",
  __ssrInlineRender: true,
  props: {
    show: { type: Boolean, default: false },
    lesson: { type: Object, default: null },
    course: { type: Object, required: true }
  },
  emits: ["close", "success"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({
      name: "",
      title: "",
      description: "",
      type: "video",
      video_url: "",
      duration: 0,
      order: "1",
      is_free: false,
      section_id: null
    });
    const lessonTypes = [
      { value: "video", label: "Video" },
      { value: "text", label: "Text" },
      { value: "quiz", label: "Quiz" }
    ];
    const sectionOptions = computed(() => {
      var _a, _b;
      const options = ((_b = (_a = props.course) == null ? void 0 : _a.sections) == null ? void 0 : _b.map((section) => ({
        value: section.id,
        label: section.title
      }))) || [];
      options.push({ value: "new", label: "+ Create New Section" });
      return options;
    });
    watch(() => props.lesson, (newLesson) => {
      if (newLesson) {
        form.name = newLesson.name || "";
        form.title = newLesson.title || "";
        form.description = newLesson.description || "";
        form.type = newLesson.type || "video";
        form.video_url = newLesson.video_url || "";
        form.duration = newLesson.duration || 0;
        form.order = newLesson.order || 1;
        form.is_free = newLesson.is_free || false;
        form.section_id = newLesson.section_id || null;
      }
    }, { immediate: true });
    watch(() => props.show, (show) => {
      if (!show) {
        form.reset();
        form.clearErrors();
      }
    });
    const submit = () => {
      const url = props.lesson ? route("courses.lecture.update", { course: props.course.id, lesson: props.lesson.id }) : route("courses.lecture.store", { course: props.course.id });
      const method = props.lesson ? "put" : "post";
      form[method](url, {
        onSuccess: (response) => {
          emit("success", props.lesson ? "Lesson updated successfully!" : "Lesson created successfully!");
        },
        onError: (errors) => {
          console.error("Form errors:", errors);
        }
      });
    };
    const closeModal = () => {
      emit("close");
    };
    watch(() => {
      var _a;
      return (_a = props.course) == null ? void 0 : _a.sections;
    }, (sections) => {
      if ((sections == null ? void 0 : sections.length) === 1 && !form.section_id) {
        form.section_id = sections[0].id;
      }
    }, { immediate: true });
    const showQuickSection = ref(false);
    const handleSectionCreated = () => {
      showQuickSection.value = false;
    };
    watch(() => form.section_id, (newValue) => {
      if (newValue === "new") {
        showQuickSection.value = true;
        form.section_id = null;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_sfc_main$i, {
        show: __props.show,
        onClose: closeModal,
        "max-width": "2xl"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-white mb-6"${_scopeId}>${ssrInterpolate(__props.lesson ? "Edit Lesson" : "Create New Lesson")}</h2><form class="space-y-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "name",
              value: "Lesson Name"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "name",
              modelValue: unref(form).name,
              "onUpdate:modelValue": ($event) => unref(form).name = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.name,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "title",
              value: "Lesson Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "title",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.title,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$n, {
              id: "description",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event,
              class: "mt-1 block w-full",
              rows: "3"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "type",
              value: "Lesson Type"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$o, {
              id: "type",
              modelValue: unref(form).type,
              "onUpdate:modelValue": ($event) => unref(form).type = $event,
              class: "mt-1 block w-full",
              options: lessonTypes
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.type,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "section_id",
              value: "Section"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$o, {
              id: "section_id",
              modelValue: unref(form).section_id,
              "onUpdate:modelValue": ($event) => unref(form).section_id = $event,
              class: "mt-1 block w-full",
              dataSet: sectionOptions.value,
              placeholder: "Select a section...",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.section_id,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$b, {
              show: showQuickSection.value,
              "course-id": __props.course.id,
              onClose: ($event) => showQuickSection.value = false,
              onSuccess: handleSectionCreated
            }, null, _parent2, _scopeId));
            if (unref(form).type === "video") {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$m, {
                for: "video_url",
                value: "Video URL"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$j, {
                id: "video_url",
                modelValue: unref(form).video_url,
                "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
                type: "url",
                class: "mt-1 block w-full",
                placeholder: "https://example.com/video.mp4"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$k, {
                message: unref(form).errors.video_url,
                class: "mt-2"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "duration",
              value: "Duration (in seconds)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "duration",
              modelValue: unref(form).duration,
              "onUpdate:modelValue": ($event) => unref(form).duration = $event,
              type: "number",
              class: "mt-1 block w-full",
              min: "0"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.duration,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "order",
              value: "Lesson Order"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "order",
              modelValue: unref(form).order,
              "onUpdate:modelValue": ($event) => unref(form).order = $event,
              type: "number",
              class: "mt-1 block w-full",
              min: "1"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.order,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$p, {
              id: "is_free",
              checked: unref(form).is_free,
              "onUpdate:checked": ($event) => unref(form).is_free = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "is_free",
              value: "Free Lesson",
              class: "ml-2"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.is_free,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center justify-end space-x-4 pt-4 border-t border-gray-200 dark:border-gray-600"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$g, {
              onClick: closeModal,
              type: "button"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$l, {
              class: { "opacity-25": unref(form).processing },
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? "Saving..." : __props.lesson ? "Update Lesson" : "Create Lesson")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? "Saving..." : __props.lesson ? "Update Lesson" : "Create Lesson"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-white mb-6" }, toDisplayString(__props.lesson ? "Edit Lesson" : "Create New Lesson"), 1),
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"]),
                  class: "space-y-6"
                }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "name",
                      value: "Lesson Name"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "name",
                      modelValue: unref(form).name,
                      "onUpdate:modelValue": ($event) => unref(form).name = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.name,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "title",
                      value: "Lesson Title"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "title",
                      modelValue: unref(form).title,
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      required: "",
                      autofocus: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.title,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "description",
                      value: "Description"
                    }),
                    createVNode(_sfc_main$n, {
                      id: "description",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      class: "mt-1 block w-full",
                      rows: "3"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.description,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "type",
                      value: "Lesson Type"
                    }),
                    createVNode(_sfc_main$o, {
                      id: "type",
                      modelValue: unref(form).type,
                      "onUpdate:modelValue": ($event) => unref(form).type = $event,
                      class: "mt-1 block w-full",
                      options: lessonTypes
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.type,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "section_id",
                      value: "Section"
                    }),
                    createVNode(_sfc_main$o, {
                      id: "section_id",
                      modelValue: unref(form).section_id,
                      "onUpdate:modelValue": ($event) => unref(form).section_id = $event,
                      class: "mt-1 block w-full",
                      dataSet: sectionOptions.value,
                      placeholder: "Select a section...",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.section_id,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode(_sfc_main$b, {
                    show: showQuickSection.value,
                    "course-id": __props.course.id,
                    onClose: ($event) => showQuickSection.value = false,
                    onSuccess: handleSectionCreated
                  }, null, 8, ["show", "course-id", "onClose"]),
                  unref(form).type === "video" ? (openBlock(), createBlock("div", { key: 0 }, [
                    createVNode(_sfc_main$m, {
                      for: "video_url",
                      value: "Video URL"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "video_url",
                      modelValue: unref(form).video_url,
                      "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
                      type: "url",
                      class: "mt-1 block w-full",
                      placeholder: "https://example.com/video.mp4"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.video_url,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ])) : createCommentVNode("", true),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "duration",
                      value: "Duration (in seconds)"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "duration",
                      modelValue: unref(form).duration,
                      "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      min: "0"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.duration,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "order",
                      value: "Lesson Order"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "order",
                      modelValue: unref(form).order,
                      "onUpdate:modelValue": ($event) => unref(form).order = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      min: "1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.order,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode(_sfc_main$p, {
                      id: "is_free",
                      checked: unref(form).is_free,
                      "onUpdate:checked": ($event) => unref(form).is_free = $event
                    }, null, 8, ["checked", "onUpdate:checked"]),
                    createVNode(_sfc_main$m, {
                      for: "is_free",
                      value: "Free Lesson",
                      class: "ml-2"
                    }),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.is_free,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "flex items-center justify-end space-x-4 pt-4 border-t border-gray-200 dark:border-gray-600" }, [
                    createVNode(_sfc_main$g, {
                      onClick: closeModal,
                      type: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Cancel ")
                      ]),
                      _: 1
                    }),
                    createVNode(_sfc_main$l, {
                      class: { "opacity-25": unref(form).processing },
                      disabled: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(unref(form).processing ? "Saving..." : __props.lesson ? "Update Lesson" : "Create Lesson"), 1)
                      ]),
                      _: 1
                    }, 8, ["class", "disabled"])
                  ])
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (!sectionOptions.value.length) {
        _push(`<div class="text-yellow-600"> ⚠️ No sections available. Create a section first. </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/LessonModal.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const _sfc_main$9 = {
  __name: "VideoPlayer",
  __ssrInlineRender: true,
  props: {
    show: { type: Boolean, default: false },
    lesson: { type: Object, default: null },
    lessons: { type: Array, default: () => [] },
    currentIndex: { type: Number, default: 0 }
  },
  emits: ["close", "next", "previous"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const videoPlayer = ref(null);
    const videoContainer = ref(null);
    const data = reactive({
      isPlaying: false,
      currentTime: 0,
      duration: 0,
      volume: 1,
      isMuted: false,
      isFullscreen: false,
      showControls: true,
      playbackRate: 1,
      controlsTimeout: null
    });
    const progressPercentage = computed(() => {
      return data.duration > 0 ? data.currentTime / data.duration * 100 : 0;
    });
    const volumePercentage = computed(() => {
      return data.isMuted ? 0 : data.volume * 100;
    });
    const formatTime = (seconds) => {
      const mins = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    };
    const togglePlay = () => {
      if (!videoPlayer.value) return;
      if (data.isPlaying) {
        videoPlayer.value.pause();
      } else {
        videoPlayer.value.play();
      }
    };
    const updateTime = () => {
      if (!videoPlayer.value) return;
      data.currentTime = videoPlayer.value.currentTime;
      data.duration = videoPlayer.value.duration || 0;
    };
    const seekTo = (event) => {
      if (!videoPlayer.value) return;
      const rect = event.target.getBoundingClientRect();
      const percent = (event.clientX - rect.left) / rect.width;
      const time = percent * data.duration;
      videoPlayer.value.currentTime = time;
      data.currentTime = time;
    };
    const changeVolume = (event) => {
      if (!videoPlayer.value) return;
      const rect = event.target.getBoundingClientRect();
      const volume = (event.clientX - rect.left) / rect.width;
      data.volume = Math.max(0, Math.min(1, volume));
      videoPlayer.value.volume = data.volume;
      data.isMuted = data.volume === 0;
    };
    const toggleMute = () => {
      if (!videoPlayer.value) return;
      data.isMuted = !data.isMuted;
      videoPlayer.value.muted = data.isMuted;
    };
    const skipTime = (seconds) => {
      if (!videoPlayer.value) return;
      videoPlayer.value.currentTime += seconds;
    };
    const changePlaybackRate = (rate) => {
      if (!videoPlayer.value) return;
      data.playbackRate = rate;
      videoPlayer.value.playbackRate = rate;
    };
    const showControlsTemporarily = () => {
      data.showControls = true;
      if (data.controlsTimeout) {
        clearTimeout(data.controlsTimeout);
      }
      data.controlsTimeout = setTimeout(() => {
        if (data.isPlaying) {
          data.showControls = false;
        }
      }, 3e3);
    };
    const closePlayer = () => {
      if (videoPlayer.value) {
        videoPlayer.value.pause();
      }
      data.isPlaying = false;
      emit("close");
    };
    watch(() => props.show, (newVal) => {
      var _a;
      if (newVal && ((_a = props.lesson) == null ? void 0 : _a.video_url)) {
        nextTick(() => {
          if (videoPlayer.value) {
            videoPlayer.value.src = props.lesson.video_url;
            videoPlayer.value.load();
          }
        });
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$i, mergeProps({
        show: __props.show,
        onClose: closePlayer,
        "max-width": "6xl"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="bg-black relative"${_scopeId}><video class="w-full h-auto max-h-[70vh]"${_scopeId}> Your browser does not support the video tag. </video><div style="${ssrRenderStyle(data.showControls ? null : { display: "none" })}" class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4"${_scopeId}><div class="mb-4"${_scopeId}><div class="w-full h-1 bg-gray-600 rounded cursor-pointer"${_scopeId}><div class="h-full bg-red-500 rounded" style="${ssrRenderStyle({ width: progressPercentage.value + "%" })}"${_scopeId}></div></div></div><div class="flex items-center justify-between text-white"${_scopeId}><div class="flex items-center space-x-4"${_scopeId}><button class="hover:text-red-500 transition-colors"${_scopeId}>`);
            if (!data.isPlaying) {
              _push2(ssrRenderComponent(unref(PlayIcon), { class: "h-6 w-6" }, null, _parent2, _scopeId));
            } else {
              _push2(ssrRenderComponent(unref(PauseIcon), { class: "h-6 w-6" }, null, _parent2, _scopeId));
            }
            _push2(`</button><button class="hover:text-red-500 transition-colors"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(BackwardIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(`</button><button class="hover:text-red-500 transition-colors"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ForwardIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            _push2(`</button><div class="flex items-center space-x-2"${_scopeId}><button class="hover:text-red-500 transition-colors"${_scopeId}>`);
            if (!data.isMuted && data.volume > 0) {
              _push2(ssrRenderComponent(unref(SpeakerWaveIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            } else {
              _push2(ssrRenderComponent(unref(SpeakerXMarkIcon), { class: "h-5 w-5" }, null, _parent2, _scopeId));
            }
            _push2(`</button><div class="w-20 h-1 bg-gray-600 rounded cursor-pointer"${_scopeId}><div class="h-full bg-white rounded" style="${ssrRenderStyle({ width: volumePercentage.value + "%" })}"${_scopeId}></div></div></div><span class="text-sm"${_scopeId}>${ssrInterpolate(formatTime(data.currentTime))} / ${ssrInterpolate(formatTime(data.duration))}</span></div><div class="flex items-center space-x-4"${_scopeId}><select class="bg-transparent text-white text-sm border-none focus:ring-0"${_scopeId}><option value="0.5"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "0.5") : ssrLooseEqual(data.playbackRate, "0.5")) ? " selected" : ""}${_scopeId}>0.5x</option><option value="0.75"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "0.75") : ssrLooseEqual(data.playbackRate, "0.75")) ? " selected" : ""}${_scopeId}>0.75x</option><option value="1"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "1") : ssrLooseEqual(data.playbackRate, "1")) ? " selected" : ""}${_scopeId}>1x</option><option value="1.25"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "1.25") : ssrLooseEqual(data.playbackRate, "1.25")) ? " selected" : ""}${_scopeId}>1.25x</option><option value="1.5"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "1.5") : ssrLooseEqual(data.playbackRate, "1.5")) ? " selected" : ""}${_scopeId}>1.5x</option><option value="2"${ssrIncludeBooleanAttr(Array.isArray(data.playbackRate) ? ssrLooseContain(data.playbackRate, "2") : ssrLooseEqual(data.playbackRate, "2")) ? " selected" : ""}${_scopeId}>2x</option></select><button class="hover:text-red-500 transition-colors"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(XMarkIcon), { class: "h-6 w-6" }, null, _parent2, _scopeId));
            _push2(`</button></div></div></div><div class="absolute top-4 left-4 bg-black/60 text-white p-3 rounded-lg"${_scopeId}><h3 class="font-semibold"${_scopeId}>${ssrInterpolate((_a = __props.lesson) == null ? void 0 : _a.title)}</h3><p class="text-sm text-gray-300"${_scopeId}>Lesson ${ssrInterpolate(__props.currentIndex + 1)} of ${ssrInterpolate(__props.lessons.length)}</p></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: "bg-black relative",
                ref_key: "videoContainer",
                ref: videoContainer
              }, [
                createVNode("video", {
                  ref_key: "videoPlayer",
                  ref: videoPlayer,
                  class: "w-full h-auto max-h-[70vh]",
                  onPlay: ($event) => data.isPlaying = true,
                  onPause: ($event) => data.isPlaying = false,
                  onTimeupdate: updateTime,
                  onLoadedmetadata: updateTime,
                  onMousemove: showControlsTemporarily,
                  onClick: togglePlay
                }, " Your browser does not support the video tag. ", 40, ["onPlay", "onPause"]),
                withDirectives(createVNode("div", { class: "absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4" }, [
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("div", {
                      class: "w-full h-1 bg-gray-600 rounded cursor-pointer",
                      onClick: seekTo
                    }, [
                      createVNode("div", {
                        class: "h-full bg-red-500 rounded",
                        style: { width: progressPercentage.value + "%" }
                      }, null, 4)
                    ])
                  ]),
                  createVNode("div", { class: "flex items-center justify-between text-white" }, [
                    createVNode("div", { class: "flex items-center space-x-4" }, [
                      createVNode("button", {
                        onClick: togglePlay,
                        class: "hover:text-red-500 transition-colors"
                      }, [
                        !data.isPlaying ? (openBlock(), createBlock(unref(PlayIcon), {
                          key: 0,
                          class: "h-6 w-6"
                        })) : (openBlock(), createBlock(unref(PauseIcon), {
                          key: 1,
                          class: "h-6 w-6"
                        }))
                      ]),
                      createVNode("button", {
                        onClick: ($event) => skipTime(-10),
                        class: "hover:text-red-500 transition-colors"
                      }, [
                        createVNode(unref(BackwardIcon), { class: "h-5 w-5" })
                      ], 8, ["onClick"]),
                      createVNode("button", {
                        onClick: ($event) => skipTime(10),
                        class: "hover:text-red-500 transition-colors"
                      }, [
                        createVNode(unref(ForwardIcon), { class: "h-5 w-5" })
                      ], 8, ["onClick"]),
                      createVNode("div", { class: "flex items-center space-x-2" }, [
                        createVNode("button", {
                          onClick: toggleMute,
                          class: "hover:text-red-500 transition-colors"
                        }, [
                          !data.isMuted && data.volume > 0 ? (openBlock(), createBlock(unref(SpeakerWaveIcon), {
                            key: 0,
                            class: "h-5 w-5"
                          })) : (openBlock(), createBlock(unref(SpeakerXMarkIcon), {
                            key: 1,
                            class: "h-5 w-5"
                          }))
                        ]),
                        createVNode("div", {
                          class: "w-20 h-1 bg-gray-600 rounded cursor-pointer",
                          onClick: changeVolume
                        }, [
                          createVNode("div", {
                            class: "h-full bg-white rounded",
                            style: { width: volumePercentage.value + "%" }
                          }, null, 4)
                        ])
                      ]),
                      createVNode("span", { class: "text-sm" }, toDisplayString(formatTime(data.currentTime)) + " / " + toDisplayString(formatTime(data.duration)), 1)
                    ]),
                    createVNode("div", { class: "flex items-center space-x-4" }, [
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => data.playbackRate = $event,
                        onChange: ($event) => changePlaybackRate(data.playbackRate),
                        class: "bg-transparent text-white text-sm border-none focus:ring-0"
                      }, [
                        createVNode("option", { value: "0.5" }, "0.5x"),
                        createVNode("option", { value: "0.75" }, "0.75x"),
                        createVNode("option", { value: "1" }, "1x"),
                        createVNode("option", { value: "1.25" }, "1.25x"),
                        createVNode("option", { value: "1.5" }, "1.5x"),
                        createVNode("option", { value: "2" }, "2x")
                      ], 40, ["onUpdate:modelValue", "onChange"]), [
                        [vModelSelect, data.playbackRate]
                      ]),
                      createVNode("button", {
                        onClick: closePlayer,
                        class: "hover:text-red-500 transition-colors"
                      }, [
                        createVNode(unref(XMarkIcon), { class: "h-6 w-6" })
                      ])
                    ])
                  ])
                ], 512), [
                  [vShow, data.showControls]
                ]),
                createVNode("div", { class: "absolute top-4 left-4 bg-black/60 text-white p-3 rounded-lg" }, [
                  createVNode("h3", { class: "font-semibold" }, toDisplayString((_b = __props.lesson) == null ? void 0 : _b.title), 1),
                  createVNode("p", { class: "text-sm text-gray-300" }, "Lesson " + toDisplayString(__props.currentIndex + 1) + " of " + toDisplayString(__props.lessons.length), 1)
                ])
              ], 512)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/VideoPlayer.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const _sfc_main$8 = {
  __name: "LessonManager",
  __ssrInlineRender: true,
  props: {
    course: { type: Object, required: true },
    lessons: { type: Object, required: true }
  },
  emits: ["success"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const data = reactive({
      lessonModalOpen: false,
      videoPlayerOpen: false,
      currentLesson: null,
      currentLessonIndex: 0
    });
    const totalDuration = computed(() => {
      var _a, _b;
      return ((_b = (_a = props.lessons) == null ? void 0 : _a.data) == null ? void 0 : _b.reduce((total, lesson) => {
        return total + (lesson.duration || 0);
      }, 0)) || 0;
    });
    const openLessonModal = (lesson = null) => {
      if (data.lessonModalOpen) return;
      data.currentLesson = lesson;
      data.lessonModalOpen = true;
    };
    const playLesson = (lesson, index) => {
      data.currentLesson = lesson;
      data.currentLessonIndex = index;
      data.videoPlayerOpen = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6"><div class="flex justify-between items-center mb-6"><div><h2 class="text-xl font-semibold text-gray-900 dark:text-white"> Course Lessons </h2><p class="text-sm text-gray-600 dark:text-gray-400"> Total Duration: ${ssrInterpolate(Math.floor(totalDuration.value / 60))} hours ${ssrInterpolate(totalDuration.value % 60)} minutes </p></div>`);
      _push(ssrRenderComponent(_sfc_main$l, {
        onClick: ($event) => openLessonModal()
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(PlusIcon), { class: "h-4 w-4 mr-2" }, null, _parent2, _scopeId));
            _push2(` Add Lesson `);
          } else {
            return [
              createVNode(unref(PlusIcon), { class: "h-4 w-4 mr-2" }),
              createTextVNode(" Add Lesson ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_sfc_main$c, {
        lessons: __props.lessons.data,
        onEdit: openLessonModal,
        onPlay: playLesson,
        onSuccess: ($event) => emit("success", $event)
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_sfc_main$a, {
        show: data.lessonModalOpen,
        lesson: data.currentLesson,
        course: __props.course,
        onClose: ($event) => data.lessonModalOpen = false,
        onSuccess: (msg) => {
          data.lessonModalOpen = false;
          emit("success", msg);
        }
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$9, {
        show: data.videoPlayerOpen,
        lesson: data.currentLesson,
        lessons: __props.lessons.data,
        "current-index": data.currentLessonIndex,
        onClose: ($event) => data.videoPlayerOpen = false
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/LessonManager.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "QuizSelector",
  __ssrInlineRender: true,
  props: {
    selectedDomain: { type: String, default: "" },
    selectedChapter: { type: String, default: "" },
    selectedQuiz: { type: Object, default: null },
    availableDomains: { type: Array, default: () => [] },
    availableChapters: { type: Array, default: () => [] },
    availableQuizzes: { type: Array, default: () => [] }
  },
  emits: [
    "update:selectedDomain",
    "update:selectedChapter",
    "update:selectedQuiz",
    "start-quiz"
  ],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const domainOptions = computed(() => {
      return props.availableDomains.map((domain) => ({
        value: domain,
        label: domain
      }));
    });
    const chapterOptions = computed(() => {
      return props.availableChapters.map((chapter) => ({
        value: chapter,
        label: chapter
      }));
    });
    const updateDomain = (value) => {
      emit("update:selectedDomain", value);
      emit("update:selectedChapter", "");
      emit("update:selectedQuiz", null);
    };
    const updateChapter = (value) => {
      emit("update:selectedChapter", value);
      emit("update:selectedQuiz", null);
    };
    const startQuiz = () => {
      if (props.selectedQuiz) {
        emit("start-quiz");
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}><div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"> Select Domain </label>`);
      _push(ssrRenderComponent(_sfc_main$o, {
        "model-value": __props.selectedDomain,
        "onUpdate:modelValue": updateDomain,
        options: domainOptions.value,
        placeholder: "Choose a domain...",
        class: "w-full"
      }, null, _parent));
      _push(`</div>`);
      if (__props.selectedDomain) {
        _push(`<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"> Select Chapter </label>`);
        _push(ssrRenderComponent(_sfc_main$o, {
          "model-value": __props.selectedChapter,
          "onUpdate:modelValue": updateChapter,
          options: chapterOptions.value,
          placeholder: "Choose a chapter...",
          class: "w-full"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.selectedChapter && __props.availableQuizzes.length > 0) {
        _push(`<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"> Available Quizzes </label><div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3"><!--[-->`);
        ssrRenderList(__props.availableQuizzes, (quiz) => {
          var _a;
          _push(`<div class="${ssrRenderClass([
            "p-4 border rounded-lg cursor-pointer transition-all duration-200",
            ((_a = __props.selectedQuiz) == null ? void 0 : _a.id) === quiz.id ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20" : "border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500"
          ])}"><h3 class="font-medium text-gray-900 dark:text-white mb-2">${ssrInterpolate(quiz.title)}</h3>`);
          if (quiz.description) {
            _push(`<p class="text-sm text-gray-600 dark:text-gray-300 mb-3">${ssrInterpolate(quiz.description)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">`);
          if (quiz.questions_count) {
            _push(`<span>${ssrInterpolate(quiz.questions_count)} questions </span>`);
          } else {
            _push(`<!---->`);
          }
          if (quiz.time_limit) {
            _push(`<span>${ssrInterpolate(quiz.time_limit)} min </span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div>`);
        });
        _push(`<!--]--></div></div>`);
      } else if (__props.selectedChapter && __props.availableQuizzes.length === 0) {
        _push(`<div class="text-center py-8"><p class="text-gray-500 dark:text-gray-400">No quizzes available for this chapter.</p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.selectedQuiz) {
        _push(`<div class="flex justify-center pt-4">`);
        _push(ssrRenderComponent(_sfc_main$l, {
          onClick: startQuiz,
          class: "flex items-center gap-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(PlayIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
              _push2(` Start Quiz: ${ssrInterpolate(__props.selectedQuiz.title)}`);
            } else {
              return [
                createVNode(unref(PlayIcon), { class: "h-4 w-4" }),
                createTextVNode(" Start Quiz: " + toDisplayString(__props.selectedQuiz.title), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/QuizSelector.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "QuizInterface",
  __ssrInlineRender: true,
  props: {
    quiz: { type: Object, required: true }
  },
  emits: ["complete", "back"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const data = reactive({
      currentQuestionIndex: 0,
      timeRemaining: props.quiz.time_limit ? props.quiz.time_limit * 60 : null,
      quizStarted: false,
      quizCompleted: false
    });
    const form = useForm({
      answers: {}
    });
    let timer = null;
    const currentQuestion = computed(() => {
      var _a;
      return ((_a = props.quiz.questions) == null ? void 0 : _a[data.currentQuestionIndex]) || null;
    });
    const progress = computed(() => {
      var _a;
      if (!((_a = props.quiz.questions) == null ? void 0 : _a.length)) return 0;
      return (data.currentQuestionIndex + 1) / props.quiz.questions.length * 100;
    });
    const formattedTime = computed(() => {
      if (!data.timeRemaining) return null;
      const minutes = Math.floor(data.timeRemaining / 60);
      const seconds = data.timeRemaining % 60;
      return `${minutes}:${seconds.toString().padStart(2, "0")}`;
    });
    const canProceed = computed(() => {
      var _a;
      return form.answers[(_a = currentQuestion.value) == null ? void 0 : _a.id] !== void 0;
    });
    const isLastQuestion = computed(() => {
      var _a;
      return data.currentQuestionIndex === ((_a = props.quiz.questions) == null ? void 0 : _a.length) - 1;
    });
    const startTimer = () => {
      if (!data.timeRemaining) return;
      timer = setInterval(() => {
        data.timeRemaining--;
        if (data.timeRemaining <= 0) {
          submitQuiz();
        }
      }, 1e3);
    };
    const stopTimer = () => {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    };
    const nextQuestion = () => {
      if (data.currentQuestionIndex < props.quiz.questions.length - 1) {
        data.currentQuestionIndex++;
      }
    };
    const previousQuestion = () => {
      if (data.currentQuestionIndex > 0) {
        data.currentQuestionIndex--;
      }
    };
    const submitQuiz = () => {
      stopTimer();
      form.post(route("quiz.submit", props.quiz.id), {
        onSuccess: () => {
          data.quizCompleted = true;
          emit("complete");
        },
        onError: (errors) => {
          console.error("Quiz submission failed:", errors);
        }
      });
    };
    const startQuiz = () => {
      data.quizStarted = true;
      startTimer();
    };
    const goBack = () => {
      stopTimer();
      emit("back");
    };
    onMounted(() => {
      var _a;
      if (((_a = props.quiz.questions) == null ? void 0 : _a.length) > 0) {
        startQuiz();
      }
    });
    onUnmounted(() => {
      stopTimer();
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-4xl mx-auto" }, _attrs))}><div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 mb-6"><div class="flex items-center justify-between mb-4"><div><h1 class="text-2xl font-bold text-gray-900 dark:text-white">${ssrInterpolate(__props.quiz.title)}</h1>`);
      if (__props.quiz.description) {
        _push(`<p class="text-gray-600 dark:text-gray-300 mt-1">${ssrInterpolate(__props.quiz.description)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_sfc_main$g, {
        onClick: goBack,
        class: "flex items-center gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(ArrowLeftIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
            _push2(` Back `);
          } else {
            return [
              createVNode(unref(ArrowLeftIcon), { class: "h-4 w-4" }),
              createTextVNode(" Back ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex items-center justify-between"><div class="flex-1"><div class="flex items-center justify-between text-sm text-gray-600 dark:text-gray-300 mb-2"><span>Question ${ssrInterpolate(_ctx.currentQuestionIndex + 1)} of ${ssrInterpolate(((_a = __props.quiz.questions) == null ? void 0 : _a.length) || 0)}</span><span>${ssrInterpolate(Math.round(progress.value))}% Complete</span></div><div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2"><div class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="${ssrRenderStyle({ width: progress.value + "%" })}"></div></div></div>`);
      if (formattedTime.value) {
        _push(`<div class="ml-6 flex items-center gap-2 text-lg font-mono">`);
        _push(ssrRenderComponent(unref(ClockIcon), { class: "h-5 w-5 text-red-500" }, null, _parent));
        _push(`<span class="${ssrRenderClass(data.timeRemaining < 300 ? "text-red-500" : "text-gray-700 dark:text-gray-300")}">${ssrInterpolate(formattedTime.value)}</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (currentQuestion.value) {
        _push(`<div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"><h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">${ssrInterpolate(currentQuestion.value.question)}</h2><div class="space-y-3 mb-8"><!--[-->`);
        ssrRenderList(currentQuestion.value.answers, (answer) => {
          _push(`<div class="${ssrRenderClass([
            "p-4 border rounded-lg cursor-pointer transition-all duration-200",
            unref(form).answers[currentQuestion.value.id] === answer.id ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20" : "border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500"
          ])}"><div class="flex items-center"><div class="${ssrRenderClass([
            "w-4 h-4 rounded-full border-2 mr-3",
            unref(form).answers[currentQuestion.value.id] === answer.id ? "border-blue-500 bg-blue-500" : "border-gray-300 dark:border-gray-600"
          ])}">`);
          if (unref(form).answers[currentQuestion.value.id] === answer.id) {
            _push(`<div class="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div><span class="text-gray-900 dark:text-white">${ssrInterpolate(answer.answer)}</span></div></div>`);
        });
        _push(`<!--]--></div><div class="flex items-center justify-between">`);
        _push(ssrRenderComponent(_sfc_main$g, {
          onClick: previousQuestion,
          disabled: _ctx.currentQuestionIndex === 0
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Previous `);
            } else {
              return [
                createTextVNode(" Previous ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="flex gap-3">`);
        if (!isLastQuestion.value) {
          _push(ssrRenderComponent(_sfc_main$g, { onClick: nextQuestion }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Skip `);
              } else {
                return [
                  createTextVNode(" Skip ")
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (isLastQuestion.value) {
          _push(ssrRenderComponent(_sfc_main$l, {
            onClick: submitQuiz,
            disabled: unref(form).processing
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(unref(form).processing ? "Submitting..." : "Submit Quiz")}`);
              } else {
                return [
                  createTextVNode(toDisplayString(unref(form).processing ? "Submitting..." : "Submit Quiz"), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(ssrRenderComponent(_sfc_main$l, {
            onClick: nextQuestion,
            disabled: !canProceed.value
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Next `);
              } else {
                return [
                  createTextVNode(" Next ")
                ];
              }
            }),
            _: 1
          }, _parent));
        }
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 text-center"><p class="text-gray-500 dark:text-gray-400">No questions available for this quiz.</p></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/QuizInterface.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "CreateQuizModal",
  __ssrInlineRender: true,
  props: {
    show: { type: Boolean, default: false },
    course: { type: Object, required: true }
  },
  emits: ["close", "success"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const form = useForm({
      title: "",
      description: "",
      domain: "",
      chapter: "",
      time_limit: 30,
      passing_score: 70,
      max_attempts: 3
    });
    const domainOptions = [
      { value: "Mathematics", label: "Mathematics" },
      { value: "Science", label: "Science" },
      { value: "Programming", label: "Programming" },
      { value: "Language", label: "Language" },
      { value: "History", label: "History" },
      { value: "Other", label: "Other" }
    ];
    watch(() => props.show, (show) => {
      if (!show) {
        form.reset();
        form.clearErrors();
      }
    });
    const submit = () => {
      form.post(route("courses.quizzes.store", props.course.id), {
        onSuccess: () => {
          emit("success", "Quiz created successfully!");
        },
        onError: (errors) => {
          console.error("Form errors:", errors);
        }
      });
    };
    const closeModal = () => {
      emit("close");
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$i, mergeProps({
        show: __props.show,
        onClose: closeModal,
        "max-width": "2xl"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-white mb-6"${_scopeId}> Create New Quiz </h2><form class="space-y-6"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "title",
              value: "Quiz Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "title",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              type: "text",
              class: "mt-1 block w-full",
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.title,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$n, {
              id: "description",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event,
              class: "mt-1 block w-full",
              rows: "3"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.description,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "domain",
              value: "Domain"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$o, {
              id: "domain",
              modelValue: unref(form).domain,
              "onUpdate:modelValue": ($event) => unref(form).domain = $event,
              class: "mt-1 block w-full",
              options: domainOptions,
              placeholder: "Select a domain...",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.domain,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "chapter",
              value: "Chapter"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "chapter",
              modelValue: unref(form).chapter,
              "onUpdate:modelValue": ($event) => unref(form).chapter = $event,
              type: "text",
              class: "mt-1 block w-full",
              placeholder: "e.g., Chapter 1, Introduction, etc.",
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.chapter,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "time_limit",
              value: "Time Limit (minutes)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "time_limit",
              modelValue: unref(form).time_limit,
              "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
              type: "number",
              class: "mt-1 block w-full",
              min: "1",
              max: "180"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.time_limit,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "passing_score",
              value: "Passing Score (%)"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "passing_score",
              modelValue: unref(form).passing_score,
              "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
              type: "number",
              class: "mt-1 block w-full",
              min: "0",
              max: "100"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.passing_score,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$m, {
              for: "max_attempts",
              value: "Maximum Attempts"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$j, {
              id: "max_attempts",
              modelValue: unref(form).max_attempts,
              "onUpdate:modelValue": ($event) => unref(form).max_attempts = $event,
              type: "number",
              class: "mt-1 block w-full",
              min: "1",
              max: "10"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$k, {
              message: unref(form).errors.max_attempts,
              class: "mt-2"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center justify-end space-x-4 pt-4 border-t border-gray-200 dark:border-gray-600"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$g, {
              onClick: closeModal,
              type: "button"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Cancel `);
                } else {
                  return [
                    createTextVNode(" Cancel ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$l, {
              class: { "opacity-25": unref(form).processing },
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? "Creating..." : "Create Quiz")}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? "Creating..." : "Create Quiz"), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "p-6" }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-white mb-6" }, " Create New Quiz "),
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"]),
                  class: "space-y-6"
                }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "title",
                      value: "Quiz Title"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "title",
                      modelValue: unref(form).title,
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      required: "",
                      autofocus: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.title,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "description",
                      value: "Description"
                    }),
                    createVNode(_sfc_main$n, {
                      id: "description",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      class: "mt-1 block w-full",
                      rows: "3"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.description,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "domain",
                      value: "Domain"
                    }),
                    createVNode(_sfc_main$o, {
                      id: "domain",
                      modelValue: unref(form).domain,
                      "onUpdate:modelValue": ($event) => unref(form).domain = $event,
                      class: "mt-1 block w-full",
                      options: domainOptions,
                      placeholder: "Select a domain...",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.domain,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "chapter",
                      value: "Chapter"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "chapter",
                      modelValue: unref(form).chapter,
                      "onUpdate:modelValue": ($event) => unref(form).chapter = $event,
                      type: "text",
                      class: "mt-1 block w-full",
                      placeholder: "e.g., Chapter 1, Introduction, etc.",
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.chapter,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "time_limit",
                      value: "Time Limit (minutes)"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "time_limit",
                      modelValue: unref(form).time_limit,
                      "onUpdate:modelValue": ($event) => unref(form).time_limit = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      min: "1",
                      max: "180"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.time_limit,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "passing_score",
                      value: "Passing Score (%)"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "passing_score",
                      modelValue: unref(form).passing_score,
                      "onUpdate:modelValue": ($event) => unref(form).passing_score = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      min: "0",
                      max: "100"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.passing_score,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$m, {
                      for: "max_attempts",
                      value: "Maximum Attempts"
                    }),
                    createVNode(_sfc_main$j, {
                      id: "max_attempts",
                      modelValue: unref(form).max_attempts,
                      "onUpdate:modelValue": ($event) => unref(form).max_attempts = $event,
                      type: "number",
                      class: "mt-1 block w-full",
                      min: "1",
                      max: "10"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$k, {
                      message: unref(form).errors.max_attempts,
                      class: "mt-2"
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "flex items-center justify-end space-x-4 pt-4 border-t border-gray-200 dark:border-gray-600" }, [
                    createVNode(_sfc_main$g, {
                      onClick: closeModal,
                      type: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Cancel ")
                      ]),
                      _: 1
                    }),
                    createVNode(_sfc_main$l, {
                      class: { "opacity-25": unref(form).processing },
                      disabled: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(unref(form).processing ? "Creating..." : "Create Quiz"), 1)
                      ]),
                      _: 1
                    }, 8, ["class", "disabled"])
                  ])
                ], 32)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CreateQuizModal.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "QuizManager",
  __ssrInlineRender: true,
  props: {
    course: { type: Object, required: true },
    quizzes: { type: Object, default: () => ({}) },
    quizDomains: { type: Array, default: () => [] }
  },
  emits: ["success"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const data = reactive({
      selectedDomain: "",
      selectedChapter: "",
      selectedQuiz: null,
      createQuizModalOpen: false,
      quizStarted: false
    });
    const availableDomains = computed(() => {
      return Object.keys(props.quizzes || {});
    });
    const availableChapters = computed(() => {
      if (!data.selectedDomain || !props.quizzes[data.selectedDomain]) {
        return [];
      }
      return Object.keys(props.quizzes[data.selectedDomain]);
    });
    const availableQuizzes = computed(() => {
      if (!data.selectedDomain || !data.selectedChapter || !props.quizzes[data.selectedDomain] || !props.quizzes[data.selectedDomain][data.selectedChapter]) {
        return [];
      }
      return props.quizzes[data.selectedDomain][data.selectedChapter];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6"><div class="flex justify-between items-center mb-6"><h2 class="text-xl font-semibold text-gray-900 dark:text-white"> Course Quizzes </h2>`);
      _push(ssrRenderComponent(_sfc_main$l, {
        onClick: ($event) => data.createQuizModalOpen = true
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(PlusIcon), { class: "h-4 w-4 mr-2" }, null, _parent2, _scopeId));
            _push2(` Create Quiz `);
          } else {
            return [
              createVNode(unref(PlusIcon), { class: "h-4 w-4 mr-2" }),
              createTextVNode(" Create Quiz ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (!data.quizStarted) {
        _push(`<div>`);
        _push(ssrRenderComponent(_sfc_main$7, {
          selectedDomain: data.selectedDomain,
          "onUpdate:selectedDomain": ($event) => data.selectedDomain = $event,
          selectedChapter: data.selectedChapter,
          "onUpdate:selectedChapter": ($event) => data.selectedChapter = $event,
          selectedQuiz: data.selectedQuiz,
          "onUpdate:selectedQuiz": ($event) => data.selectedQuiz = $event,
          "available-domains": availableDomains.value,
          "available-chapters": availableChapters.value,
          "available-quizzes": availableQuizzes.value,
          onStartQuiz: ($event) => data.quizStarted = true
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div>`);
        _push(ssrRenderComponent(_sfc_main$6, {
          quiz: data.selectedQuiz,
          onComplete: ($event) => data.quizStarted = false,
          onBack: ($event) => data.quizStarted = false
        }, null, _parent));
        _push(`</div>`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        show: data.createQuizModalOpen,
        course: __props.course,
        onClose: ($event) => data.createQuizModalOpen = false,
        onSuccess: (msg) => {
          data.createQuizModalOpen = false;
          emit("success", msg);
        }
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/QuizManager.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "SuccessNotification",
  __ssrInlineRender: true,
  props: {
    show: { type: Boolean, default: false },
    message: { type: String, default: "" }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.show) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 max-w-sm" }, _attrs))}><div class="flex items-center"><svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg><span class="text-sm font-medium">${ssrInterpolate(__props.message)}</span></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SuccessNotification.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "LoadingSpinner",
  __ssrInlineRender: true,
  props: {
    size: {
      type: String,
      default: "h-12 w-12"
    },
    color: {
      type: String,
      default: "border-indigo-600"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-center" }, _attrs))}><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/LoadingSpinner.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "CourseStatistics",
  __ssrInlineRender: true,
  props: {
    stats: { type: Object, default: () => ({}) }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden" }, _attrs))}><div class="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-700 dark:to-gray-600 px-6 py-4 border-b border-gray-200 dark:border-gray-600"><h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2"><div class="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div> Course Statistics </h3></div><div class="p-6 space-y-4"><div class="group hover:bg-blue-50 dark:hover:bg-blue-900/20 p-4 rounded-lg transition-all border border-transparent hover:border-blue-200"><div class="flex items-center justify-between"><div class="flex items-center gap-3"><div class="p-2 bg-blue-100 rounded-lg">`);
      _push(ssrRenderComponent(unref(UsersIcon$1), { class: "h-5 w-5 text-blue-600" }, null, _parent));
      _push(`</div><div><p class="text-sm font-medium">Enrolled Students</p><p class="text-xs text-gray-500">Active learners</p></div></div><div class="text-2xl font-bold text-blue-600">${ssrInterpolate(__props.stats.enrolled_students || 0)}</div></div></div><div class="group hover:bg-green-50 p-4 rounded-lg transition-all border border-transparent hover:border-green-200"><div class="flex items-center justify-between"><div class="flex items-center gap-3"><div class="p-2 bg-green-100 rounded-lg">`);
      _push(ssrRenderComponent(unref(EyeIcon$1), { class: "h-5 w-5 text-green-600" }, null, _parent));
      _push(`</div><div><p class="text-sm font-medium">Total Views</p><p class="text-xs text-gray-500">Course visibility</p></div></div><div class="text-2xl font-bold text-green-600">${ssrInterpolate(__props.stats.total_views || 0)}</div></div></div><div class="group hover:bg-purple-50 p-4 rounded-lg transition-all border border-transparent hover:border-purple-200"><div class="flex items-center justify-between"><div class="flex items-center gap-3"><div class="p-2 bg-purple-100 rounded-lg">`);
      _push(ssrRenderComponent(unref(ClockIcon$1), { class: "h-5 w-5 text-purple-600" }, null, _parent));
      _push(`</div><div><p class="text-sm font-medium">Completion Rate</p><p class="text-xs text-gray-500">Student progress</p></div></div><div class="text-2xl font-bold text-purple-600">${ssrInterpolate(__props.stats.completion_rate || 0)}%</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Course/CourseStatistics.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "DetailsCourse",
  __ssrInlineRender: true,
  props: {
    course: { type: Object, required: true },
    lessons: { type: Object, required: true },
    stats: { type: Object, default: () => ({}) },
    breadcrumbs: { type: Array, default: () => [] },
    quizzes: { type: Object, default: () => ({}) },
    quizDomains: { type: Array, default: () => [] }
  },
  setup(__props) {
    const props = __props;
    const data = reactive({
      activeTab: "overview",
      showSuccess: false,
      successMessage: "",
      isLoading: false
    });
    const courseProgress = computed(() => {
      var _a, _b, _c, _d, _e;
      const totalLessons = ((_b = (_a = props.lessons) == null ? void 0 : _a.data) == null ? void 0 : _b.length) || 0;
      const completedLessons = ((_e = (_d = (_c = props.lessons) == null ? void 0 : _c.data) == null ? void 0 : _d.filter((lesson) => lesson.completed)) == null ? void 0 : _e.length) || 0;
      return totalLessons > 0 ? Math.round(completedLessons / totalLessons * 100) : 0;
    });
    const lessonsCount = computed(() => {
      var _a, _b;
      return ((_b = (_a = props.lessons) == null ? void 0 : _a.data) == null ? void 0 : _b.length) || 0;
    });
    const quizzesCount = computed(() => Object.keys(props.quizzes).length);
    const showSuccessMessage = (message) => {
      data.successMessage = message;
      data.showSuccess = true;
      setTimeout(() => {
        data.showSuccess = false;
      }, 5e3);
    };
    const handleTabChange = (newTab) => {
      data.activeTab = newTab;
    };
    onMounted(() => {
      var _a, _b;
      console.log("Course data:", props.course);
      console.log("Course title:", (_a = props.course) == null ? void 0 : _a.data.title);
      console.log("Course name:", (_b = props.course) == null ? void 0 : _b.data.name);
      console.log("All props:", props);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$q, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), {
              title: `Course: ${props.course.data.title}`
            }, null, _parent2, _scopeId));
            _push2(`<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4" data-v-f5e7c579${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$r, {
              breadcrumbs: props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="fixed top-20 right-5 z-50" data-v-f5e7c579${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              show: data.showSuccess,
              message: data.successMessage,
              onClose: ($event) => data.showSuccess = false
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            if (data.isLoading) {
              _push2(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50" data-v-f5e7c579${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (!props.course.data.slug) {
              _push2(`<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" data-v-f5e7c579${_scopeId}> Course title not available </div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="min-h-screen bg-gray-50 dark:bg-gray-900" data-v-f5e7c579${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$d, {
              course: props.course.data,
              stats: props.stats,
              "course-progress": courseProgress.value,
              "lessons-count": lessonsCount.value
            }, null, _parent2, _scopeId));
            _push2(`<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" data-v-f5e7c579${_scopeId}><div class="flex flex-col lg:flex-row gap-8" data-v-f5e7c579${_scopeId}><div class="flex-1" data-v-f5e7c579${_scopeId}><div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 mb-6 overflow-hidden" data-v-f5e7c579${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$e, {
              "active-tab": data.activeTab,
              "lessons-count": lessonsCount.value,
              "quizzes-count": quizzesCount.value,
              "onUpdate:activeTab": handleTabChange
            }, null, _parent2, _scopeId));
            _push2(`<div class="p-6" data-v-f5e7c579${_scopeId}>`);
            if (data.activeTab === "lessons") {
              _push2(ssrRenderComponent(_sfc_main$8, {
                course: __props.course.data,
                lessons: __props.lessons,
                onSuccess: showSuccessMessage,
                key: "lessons"
              }, null, _parent2, _scopeId));
            } else if (data.activeTab === "quizzes") {
              _push2(ssrRenderComponent(_sfc_main$4, {
                course: __props.course,
                quizzes: __props.quizzes,
                "quiz-domains": __props.quizDomains,
                onSuccess: showSuccessMessage,
                key: "quizzes"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<div class="text-center py-8 text-gray-500 dark:text-gray-400" data-v-f5e7c579${_scopeId}> Course overview is displayed above </div>`);
            }
            _push2(`</div></div></div><div class="lg:w-80" data-v-f5e7c579${_scopeId}><div class="sticky top-8 space-y-6" data-v-f5e7c579${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, { stats: __props.stats }, null, _parent2, _scopeId));
            _push2(`</div></div></div></div></div>`);
          } else {
            return [
              createVNode(unref(Head), {
                title: `Course: ${props.course.data.title}`
              }, null, 8, ["title"]),
              createVNode("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4" }, [
                createVNode(_sfc_main$r, {
                  breadcrumbs: props.breadcrumbs
                }, null, 8, ["breadcrumbs"])
              ]),
              createVNode("div", { class: "fixed top-20 right-5 z-50" }, [
                createVNode(_sfc_main$3, {
                  show: data.showSuccess,
                  message: data.successMessage,
                  onClose: ($event) => data.showSuccess = false
                }, null, 8, ["show", "message", "onClose"])
              ]),
              data.isLoading ? (openBlock(), createBlock("div", {
                key: 0,
                class: "fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
              }, [
                createVNode(_sfc_main$2)
              ])) : createCommentVNode("", true),
              !props.course.data.slug ? (openBlock(), createBlock("div", {
                key: 1,
                class: "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"
              }, " Course title not available ")) : createCommentVNode("", true),
              createVNode("div", { class: "min-h-screen bg-gray-50 dark:bg-gray-900" }, [
                createVNode(_sfc_main$d, {
                  course: props.course.data,
                  stats: props.stats,
                  "course-progress": courseProgress.value,
                  "lessons-count": lessonsCount.value
                }, null, 8, ["course", "stats", "course-progress", "lessons-count"]),
                createVNode("div", { class: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row gap-8" }, [
                    createVNode("div", { class: "flex-1" }, [
                      createVNode("div", { class: "bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 mb-6 overflow-hidden" }, [
                        createVNode(_sfc_main$e, {
                          "active-tab": data.activeTab,
                          "lessons-count": lessonsCount.value,
                          "quizzes-count": quizzesCount.value,
                          "onUpdate:activeTab": handleTabChange
                        }, null, 8, ["active-tab", "lessons-count", "quizzes-count"]),
                        createVNode("div", { class: "p-6" }, [
                          createVNode(Transition, {
                            name: "fade",
                            mode: "out-in"
                          }, {
                            default: withCtx(() => [
                              data.activeTab === "lessons" ? (openBlock(), createBlock(_sfc_main$8, {
                                course: __props.course.data,
                                lessons: __props.lessons,
                                onSuccess: showSuccessMessage,
                                key: "lessons"
                              }, null, 8, ["course", "lessons"])) : data.activeTab === "quizzes" ? (openBlock(), createBlock(_sfc_main$4, {
                                course: __props.course,
                                quizzes: __props.quizzes,
                                "quiz-domains": __props.quizDomains,
                                onSuccess: showSuccessMessage,
                                key: "quizzes"
                              }, null, 8, ["course", "quizzes", "quiz-domains"])) : (openBlock(), createBlock("div", {
                                key: 2,
                                class: "text-center py-8 text-gray-500 dark:text-gray-400"
                              }, " Course overview is displayed above "))
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "lg:w-80" }, [
                      createVNode("div", { class: "sticky top-8 space-y-6" }, [
                        createVNode(_sfc_main$1, { stats: __props.stats }, null, 8, ["stats"])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard/Course/DetailsCourse.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const DetailsCourse = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f5e7c579"]]);
export {
  DetailsCourse as default
};
