import { defineComponent, resolveComponent, withCtx, createVNode, createBlock, openBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, withDirectives, vModelText, vModelSelect, ref, useSSRContext } from "vue";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = defineComponent({
  components: {
    AuthenticatedLayout: _sfc_main$1
  },
  setup() {
    const currentStep = ref(1);
    const form = useForm({
      title: "",
      name: "",
      description: "",
      body: "",
      duration: null,
      image: null,
      status: "draft",
      intro_video: ""
    });
    const submitForm = () => {
      form.post(route("courses.store"), {
        preserveState: true,
        preserveScroll: true
      });
    };
    return { form, submitForm, currentStep };
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  _push(ssrRenderComponent(_component_AuthenticatedLayout, _attrs, {
    header: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>Create New Course</h2>`);
      } else {
        return [
          createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, "Create New Course")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><div class="mb-8"${_scopeId}><div class="flex justify-between mb-1"${_scopeId}><!--[-->`);
        ssrRenderList(3, (step) => {
          _push2(`<span class="${ssrRenderClass({ "text-blue-600 font-bold": _ctx.currentStep >= step, "text-gray-400": _ctx.currentStep < step })}"${_scopeId}> Step ${ssrInterpolate(step)}</span>`);
        });
        _push2(`<!--]--></div><div class="w-full bg-gray-200 rounded-full h-2.5"${_scopeId}><div class="bg-blue-600 h-2.5 rounded-full" style="${ssrRenderStyle({ width: `${_ctx.currentStep / 3 * 100}%` })}"${_scopeId}></div></div></div><form enctype="multipart/form-data"${_scopeId}>`);
        if (_ctx.currentStep === 1) {
          _push2(`<div${_scopeId}><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Title:</label><input id="title"${ssrRenderAttr("value", _ctx.form.title)} type="text" class="form-input w-full" required${_scopeId}></div><div class="mb-4"${_scopeId}><label for="name" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Name:</label><input id="name"${ssrRenderAttr("value", _ctx.form.name)} type="text" class="form-input w-full" required${_scopeId}></div><div class="mb-4"${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Description:</label><textarea id="description" class="form-textarea w-full" rows="3"${_scopeId}>${ssrInterpolate(_ctx.form.description)}</textarea></div></div>`);
        } else {
          _push2(`<!---->`);
        }
        if (_ctx.currentStep === 2) {
          _push2(`<div${_scopeId}><div class="mb-4"${_scopeId}><label for="body" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Body:</label><textarea id="body" class="form-textarea w-full" rows="5"${_scopeId}>${ssrInterpolate(_ctx.form.body)}</textarea></div><div class="mb-4"${_scopeId}><label for="duration" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Duration (in minutes):</label><input id="duration"${ssrRenderAttr("value", _ctx.form.duration)} type="number" class="form-input w-full"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="image" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Image:</label><input id="image" type="file" class="form-input w-full"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="status" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Status:</label><select id="status" class="form-select w-full" required${_scopeId}><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(_ctx.form.status) ? ssrLooseContain(_ctx.form.status, "draft") : ssrLooseEqual(_ctx.form.status, "draft")) ? " selected" : ""}${_scopeId}>Draft</option><option value="published"${ssrIncludeBooleanAttr(Array.isArray(_ctx.form.status) ? ssrLooseContain(_ctx.form.status, "published") : ssrLooseEqual(_ctx.form.status, "published")) ? " selected" : ""}${_scopeId}>Published</option></select></div><div class="mb-4"${_scopeId}><label for="intro_video" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Intro Video URL:</label><input id="intro_video"${ssrRenderAttr("value", _ctx.form.intro_video)} type="url" class="form-input w-full"${_scopeId}></div></div>`);
        } else {
          _push2(`<!---->`);
        }
        if (_ctx.currentStep === 3) {
          _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Review Your Course Information</h3><!--[-->`);
          ssrRenderList(_ctx.form, (value, key) => {
            _push2(`<div class="mb-2"${_scopeId}><strong${_scopeId}>${ssrInterpolate(key.charAt(0).toUpperCase() + key.slice(1))}:</strong>`);
            if (key !== "image") {
              _push2(`<span${_scopeId}>${ssrInterpolate(value)}</span>`);
            } else {
              _push2(`<span${_scopeId}>${ssrInterpolate(value ? value.name : "No image selected")}</span>`);
            }
            _push2(`</div>`);
          });
          _push2(`<!--]--></div>`);
        } else {
          _push2(`<!---->`);
        }
        _push2(`<div class="flex justify-between mt-6"${_scopeId}>`);
        if (_ctx.currentStep > 1) {
          _push2(`<button type="button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}> Previous </button>`);
        } else {
          _push2(`<!---->`);
        }
        if (_ctx.currentStep < 3) {
          _push2(`<button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}> Next </button>`);
        } else {
          _push2(`<!---->`);
        }
        if (_ctx.currentStep === 3) {
          _push2(`<button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${ssrIncludeBooleanAttr(_ctx.form.processing) ? " disabled" : ""}${_scopeId}> Create Course </button>`);
        } else {
          _push2(`<!---->`);
        }
        _push2(`</div></form></div></div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-12" }, [
            createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                  createVNode("div", { class: "mb-8" }, [
                    createVNode("div", { class: "flex justify-between mb-1" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(3, (step) => {
                        return createVNode("span", {
                          key: step,
                          class: { "text-blue-600 font-bold": _ctx.currentStep >= step, "text-gray-400": _ctx.currentStep < step }
                        }, " Step " + toDisplayString(step), 3);
                      }), 64))
                    ]),
                    createVNode("div", { class: "w-full bg-gray-200 rounded-full h-2.5" }, [
                      createVNode("div", {
                        class: "bg-blue-600 h-2.5 rounded-full",
                        style: { width: `${_ctx.currentStep / 3 * 100}%` }
                      }, null, 4)
                    ])
                  ]),
                  createVNode("form", {
                    onSubmit: withModifiers(_ctx.submitForm, ["prevent"]),
                    enctype: "multipart/form-data"
                  }, [
                    _ctx.currentStep === 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "title",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Title:"),
                        withDirectives(createVNode("input", {
                          id: "title",
                          "onUpdate:modelValue": ($event) => _ctx.form.title = $event,
                          type: "text",
                          class: "form-input w-full",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.title]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "name",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Name:"),
                        withDirectives(createVNode("input", {
                          id: "name",
                          "onUpdate:modelValue": ($event) => _ctx.form.name = $event,
                          type: "text",
                          class: "form-input w-full",
                          required: ""
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.name]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "description",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Description:"),
                        withDirectives(createVNode("textarea", {
                          id: "description",
                          "onUpdate:modelValue": ($event) => _ctx.form.description = $event,
                          class: "form-textarea w-full",
                          rows: "3"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.description]
                        ])
                      ])
                    ])) : createCommentVNode("", true),
                    _ctx.currentStep === 2 ? (openBlock(), createBlock("div", { key: 1 }, [
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "body",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Body:"),
                        withDirectives(createVNode("textarea", {
                          id: "body",
                          "onUpdate:modelValue": ($event) => _ctx.form.body = $event,
                          class: "form-textarea w-full",
                          rows: "5"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.body]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "duration",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Duration (in minutes):"),
                        withDirectives(createVNode("input", {
                          id: "duration",
                          "onUpdate:modelValue": ($event) => _ctx.form.duration = $event,
                          type: "number",
                          class: "form-input w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.duration]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "image",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Image:"),
                        createVNode("input", {
                          id: "image",
                          type: "file",
                          onInput: ($event) => _ctx.form.image = $event.target.files[0],
                          class: "form-input w-full"
                        }, null, 40, ["onInput"])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "status",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Status:"),
                        withDirectives(createVNode("select", {
                          id: "status",
                          "onUpdate:modelValue": ($event) => _ctx.form.status = $event,
                          class: "form-select w-full",
                          required: ""
                        }, [
                          createVNode("option", { value: "draft" }, "Draft"),
                          createVNode("option", { value: "published" }, "Published")
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, _ctx.form.status]
                        ])
                      ]),
                      createVNode("div", { class: "mb-4" }, [
                        createVNode("label", {
                          for: "intro_video",
                          class: "block text-gray-700 text-sm font-bold mb-2"
                        }, "Intro Video URL:"),
                        withDirectives(createVNode("input", {
                          id: "intro_video",
                          "onUpdate:modelValue": ($event) => _ctx.form.intro_video = $event,
                          type: "url",
                          class: "form-input w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, _ctx.form.intro_video]
                        ])
                      ])
                    ])) : createCommentVNode("", true),
                    _ctx.currentStep === 3 ? (openBlock(), createBlock("div", { key: 2 }, [
                      createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Review Your Course Information"),
                      (openBlock(true), createBlock(Fragment, null, renderList(_ctx.form, (value, key) => {
                        return openBlock(), createBlock("div", {
                          key,
                          class: "mb-2"
                        }, [
                          createVNode("strong", null, toDisplayString(key.charAt(0).toUpperCase() + key.slice(1)) + ":", 1),
                          key !== "image" ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(value), 1)) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(value ? value.name : "No image selected"), 1))
                        ]);
                      }), 128))
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "flex justify-between mt-6" }, [
                      _ctx.currentStep > 1 ? (openBlock(), createBlock("button", {
                        key: 0,
                        onClick: ($event) => _ctx.currentStep--,
                        type: "button",
                        class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      }, " Previous ", 8, ["onClick"])) : createCommentVNode("", true),
                      _ctx.currentStep < 3 ? (openBlock(), createBlock("button", {
                        key: 1,
                        onClick: ($event) => _ctx.currentStep++,
                        type: "button",
                        class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      }, " Next ", 8, ["onClick"])) : createCommentVNode("", true),
                      _ctx.currentStep === 3 ? (openBlock(), createBlock("button", {
                        key: 2,
                        type: "submit",
                        class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                        disabled: _ctx.form.processing
                      }, " Create Course ", 8, ["disabled"])) : createCommentVNode("", true)
                    ])
                  ], 40, ["onSubmit"])
                ])
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
