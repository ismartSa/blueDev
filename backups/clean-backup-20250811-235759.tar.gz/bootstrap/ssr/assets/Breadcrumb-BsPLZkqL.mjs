import { mergeProps, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { ChevronRightIcon } from "@heroicons/vue/24/outline";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Breadcrumb",
  __ssrInlineRender: true,
  props: {
    title: String,
    breadcrumbs: { type: Array, default: () => [] }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between py-4 px-4 sm:px-0 text-slate-500 dark:text-slate-300" }, _attrs))}><p>${ssrInterpolate(__props.title)}</p>`);
      if (__props.breadcrumbs.length) {
        _push(`<div class="hidden sm:flex space-x-2 items-center">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("dashboard")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Dashboard`);
            } else {
              return [
                createTextVNode("Dashboard")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<!--[-->`);
        ssrRenderList(__props.breadcrumbs, (breadcrumb, index) => {
          _push(`<!--[-->`);
          _push(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-3 h-3" }, null, _parent));
          _push(ssrRenderComponent(unref(Link), {
            href: breadcrumb.href
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(breadcrumb.label)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(breadcrumb.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<!--]-->`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Breadcrumb.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
