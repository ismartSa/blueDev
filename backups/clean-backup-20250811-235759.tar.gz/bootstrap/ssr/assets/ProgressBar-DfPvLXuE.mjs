import { ssrRenderStyle, ssrInterpolate } from "vue/server-renderer";
import { useSSRContext } from "vue";
const _sfc_main = {
  __name: "ProgressBar",
  __ssrInlineRender: true,
  props: {
    progress: {
      type: Number,
      required: true,
      default: 0
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2.5"><div class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style="${ssrRenderStyle({ width: `${__props.progress}%` })}"></div></div><div class="mt-2 text-sm text-gray-600 dark:text-gray-300">${ssrInterpolate(Math.round(__props.progress))}% Complete </div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Player/ProgressBar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
