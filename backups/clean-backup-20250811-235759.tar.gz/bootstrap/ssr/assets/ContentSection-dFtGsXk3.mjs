import { mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "ContentSection",
  __ssrInlineRender: true,
  props: {
    sections: {
      type: Array,
      required: true
    },
    currentLectureId: {
      type: Number,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white dark:bg-slate-800 rounded-lg shadow-sm" }, _attrs))}><div class="p-4"><h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Course Content</h3><div class="space-y-4"><!--[-->`);
      ssrRenderList(__props.sections, (section) => {
        _push(`<div class="border-b dark:border-slate-700 pb-4 last:border-0"><h4 class="font-medium text-gray-800 dark:text-gray-200 mb-2">${ssrInterpolate(section.title)}</h4><ul class="space-y-2"><!--[-->`);
        ssrRenderList(section.lectures, (lecture) => {
          _push(`<li>`);
          _push(ssrRenderComponent(unref(Link), {
            href: _ctx.route("courses.watch", { courseId: lecture.course_id, courseSlug: lecture.course_slug, lectureID: lecture.id }),
            class: ["flex items-center justify-between p-2 rounded hover:bg-gray-50 dark:hover:bg-slate-700", { "bg-blue-50 dark:bg-blue-900": lecture.id === __props.currentLectureId }]
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<span class="text-sm text-gray-600 dark:text-gray-300"${_scopeId}>${ssrInterpolate(lecture.title)}</span><span class="text-xs text-gray-500 dark:text-gray-400"${_scopeId}>${ssrInterpolate(lecture.duration)} min</span>`);
              } else {
                return [
                  createVNode("span", { class: "text-sm text-gray-600 dark:text-gray-300" }, toDisplayString(lecture.title), 1),
                  createVNode("span", { class: "text-xs text-gray-500 dark:text-gray-400" }, toDisplayString(lecture.duration) + " min", 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Player/ContentSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
