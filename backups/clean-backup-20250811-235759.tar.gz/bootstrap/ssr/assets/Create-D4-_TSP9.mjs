import { resolveComponent, withCtx, createVNode, createBlock, createCommentVNode, openBlock, Fragment, renderList, toDisplayString, withDirectives, vModelText, createTextVNode, vModelCheckbox, vModelSelect, ref, computed, useSSRContext } from "vue";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { useForm } from "@inertiajs/vue3";
import { ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1
  },
  props: {
    courses: Array
  },
  setup(props) {
    const steps = ["Basic Information", "Quiz Settings", "Course Section", "Review"];
    const currentStep = ref(1);
    const form = useForm({
      title: "",
      description: "",
      time_limit: null,
      passing_score: null,
      is_active: true,
      course_id: "",
      section_id: ""
    });
    const currentCourseSections = computed(() => {
      if (!form.course_id) return [];
      const course = props.courses.find((c) => c.id === form.course_id);
      return course ? course.sections : [];
    });
    function nextStep() {
      if (currentStep.value < steps.length) {
        currentStep.value++;
      }
    }
    function previousStep() {
      if (currentStep.value > 1) {
        currentStep.value--;
      }
    }
    function submit() {
      form.post(route("quizzes.store"));
    }
    function getCourseTitle(courseId) {
      if (!courseId) return "Not specified";
      const course = props.courses.find((c) => c.id === courseId);
      return course ? course.title : "Unknown Course";
    }
    function getSectionTitle(sectionId) {
      if (!sectionId) return "Not specified";
      const course = props.courses.find((c) => c.id === form.course_id);
      if (!course) return "Unknown Section";
      const section = course.sections.find((s) => s.id === sectionId);
      return section ? section.title : "Unknown Section";
    }
    return {
      steps,
      currentStep,
      form,
      nextStep,
      previousStep,
      submit,
      courses: props.courses,
      currentCourseSections,
      getCourseTitle,
      getSectionTitle
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  _push(ssrRenderComponent(_component_AuthenticatedLayout, _attrs, {
    header: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}> Create New Quiz </h2>`);
      } else {
        return [
          createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, " Create New Quiz ")
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><div class="mb-4"${_scopeId}><div class="flex justify-between mb-1"${_scopeId}><!--[-->`);
        ssrRenderList($setup.steps, (step, index) => {
          _push2(`<span class="${ssrRenderClass({ "font-bold": $setup.currentStep === index + 1 })}"${_scopeId}> Step ${ssrInterpolate(index + 1)}</span>`);
        });
        _push2(`<!--]--></div><div class="w-full bg-gray-200 rounded-full h-2.5"${_scopeId}><div class="bg-blue-600 h-2.5 rounded-full" style="${ssrRenderStyle({ width: `${$setup.currentStep / $setup.steps.length * 100}%` })}"${_scopeId}></div></div></div>`);
        if ($setup.currentStep === 1) {
          _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Basic Information</h3><div class="mb-4"${_scopeId}><label for="title" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Title</label><input${ssrRenderAttr("value", $setup.form.title)} type="text" id="title" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="description" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Description</label><textarea id="description" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}>${ssrInterpolate($setup.form.description)}</textarea></div></div>`);
        } else {
          _push2(`<!---->`);
        }
        if ($setup.currentStep === 2) {
          _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Quiz Settings</h3><div class="mb-4"${_scopeId}><label for="time_limit" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Time Limit (minutes)</label><input${ssrRenderAttr("value", $setup.form.time_limit)} type="number" id="time_limit" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="passing_score" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Passing Score (%)</label><input${ssrRenderAttr("value", $setup.form.passing_score)} type="number" id="passing_score" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="is_active" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray($setup.form.is_active) ? ssrLooseContain($setup.form.is_active, null) : $setup.form.is_active) ? " checked" : ""} type="checkbox" id="is_active" class="mr-2"${_scopeId}> Active Quiz </label></div></div>`);
        } else {
          _push2(`<!---->`);
        }
        if ($setup.currentStep === 3) {
          _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Course Section (Optional)</h3><div class="mb-4"${_scopeId}><label for="course_id" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Course (Optional)</label><select id="course_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray($setup.form.course_id) ? ssrLooseContain($setup.form.course_id, "") : ssrLooseEqual($setup.form.course_id, "")) ? " selected" : ""}${_scopeId}>Select a course (optional)</option><!--[-->`);
          ssrRenderList($setup.courses, (course) => {
            _push2(`<option${ssrRenderAttr("value", course.id)}${ssrIncludeBooleanAttr(Array.isArray($setup.form.course_id) ? ssrLooseContain($setup.form.course_id, course.id) : ssrLooseEqual($setup.form.course_id, course.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(course.title)}</option>`);
          });
          _push2(`<!--]--></select></div>`);
          if ($setup.form.course_id) {
            _push2(`<div class="mb-4"${_scopeId}><label for="section_id" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Section (Optional)</label><select id="section_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"${_scopeId}><option value=""${ssrIncludeBooleanAttr(Array.isArray($setup.form.section_id) ? ssrLooseContain($setup.form.section_id, "") : ssrLooseEqual($setup.form.section_id, "")) ? " selected" : ""}${_scopeId}>Select a section (optional)</option><!--[-->`);
            ssrRenderList($setup.currentCourseSections, (section) => {
              _push2(`<option${ssrRenderAttr("value", section.id)}${ssrIncludeBooleanAttr(Array.isArray($setup.form.section_id) ? ssrLooseContain($setup.form.section_id, section.id) : ssrLooseEqual($setup.form.section_id, section.id)) ? " selected" : ""}${_scopeId}>${ssrInterpolate(section.title)}</option>`);
            });
            _push2(`<!--]--></select></div>`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`</div>`);
        } else {
          _push2(`<!---->`);
        }
        if ($setup.currentStep === 4) {
          _push2(`<div${_scopeId}><h3 class="text-lg font-semibold mb-4"${_scopeId}>Review</h3><div class="mb-4"${_scopeId}><p${_scopeId}><strong${_scopeId}>Title:</strong> ${ssrInterpolate($setup.form.title)}</p><p${_scopeId}><strong${_scopeId}>Description:</strong> ${ssrInterpolate($setup.form.description)}</p><p${_scopeId}><strong${_scopeId}>Time Limit:</strong> ${ssrInterpolate($setup.form.time_limit)} minutes</p><p${_scopeId}><strong${_scopeId}>Passing Score:</strong> ${ssrInterpolate($setup.form.passing_score)}%</p><p${_scopeId}><strong${_scopeId}>Active:</strong> ${ssrInterpolate($setup.form.is_active ? "Yes" : "No")}</p><p${_scopeId}><strong${_scopeId}>Course:</strong> ${ssrInterpolate($setup.getCourseTitle($setup.form.course_id))}</p><p${_scopeId}><strong${_scopeId}>Section:</strong> ${ssrInterpolate($setup.getSectionTitle($setup.form.section_id))}</p></div></div>`);
        } else {
          _push2(`<!---->`);
        }
        _push2(`<div class="flex justify-between mt-6"${_scopeId}>`);
        if ($setup.currentStep > 1) {
          _push2(`<button class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"${_scopeId}> Previous </button>`);
        } else {
          _push2(`<!---->`);
        }
        if ($setup.currentStep < $setup.steps.length) {
          _push2(`<button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"${_scopeId}> Next </button>`);
        } else {
          _push2(`<!---->`);
        }
        if ($setup.currentStep === $setup.steps.length) {
          _push2(`<button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"${_scopeId}> Create Quiz </button>`);
        } else {
          _push2(`<!---->`);
        }
        _push2(`</div></div></div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-12" }, [
            createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                  createVNode("div", { class: "mb-4" }, [
                    createVNode("div", { class: "flex justify-between mb-1" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList($setup.steps, (step, index) => {
                        return openBlock(), createBlock("span", {
                          key: index,
                          class: { "font-bold": $setup.currentStep === index + 1 }
                        }, " Step " + toDisplayString(index + 1), 3);
                      }), 128))
                    ]),
                    createVNode("div", { class: "w-full bg-gray-200 rounded-full h-2.5" }, [
                      createVNode("div", {
                        class: "bg-blue-600 h-2.5 rounded-full",
                        style: { width: `${$setup.currentStep / $setup.steps.length * 100}%` }
                      }, null, 4)
                    ])
                  ]),
                  $setup.currentStep === 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                    createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Basic Information"),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "title",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Title"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => $setup.form.title = $event,
                        type: "text",
                        id: "title",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.title]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "description",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Description"),
                      withDirectives(createVNode("textarea", {
                        "onUpdate:modelValue": ($event) => $setup.form.description = $event,
                        id: "description",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.description]
                      ])
                    ])
                  ])) : createCommentVNode("", true),
                  $setup.currentStep === 2 ? (openBlock(), createBlock("div", { key: 1 }, [
                    createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Quiz Settings"),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "time_limit",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Time Limit (minutes)"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => $setup.form.time_limit = $event,
                        type: "number",
                        id: "time_limit",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.time_limit]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "passing_score",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Passing Score (%)"),
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => $setup.form.passing_score = $event,
                        type: "number",
                        id: "passing_score",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.passing_score]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "is_active",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, [
                        withDirectives(createVNode("input", {
                          "onUpdate:modelValue": ($event) => $setup.form.is_active = $event,
                          type: "checkbox",
                          id: "is_active",
                          class: "mr-2"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelCheckbox, $setup.form.is_active]
                        ]),
                        createTextVNode(" Active Quiz ")
                      ])
                    ])
                  ])) : createCommentVNode("", true),
                  $setup.currentStep === 3 ? (openBlock(), createBlock("div", { key: 2 }, [
                    createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Course Section (Optional)"),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "course_id",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Course (Optional)"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => $setup.form.course_id = $event,
                        id: "course_id",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, [
                        createVNode("option", { value: "" }, "Select a course (optional)"),
                        (openBlock(true), createBlock(Fragment, null, renderList($setup.courses, (course) => {
                          return openBlock(), createBlock("option", {
                            key: course.id,
                            value: course.id
                          }, toDisplayString(course.title), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, $setup.form.course_id]
                      ])
                    ]),
                    $setup.form.course_id ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mb-4"
                    }, [
                      createVNode("label", {
                        for: "section_id",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Section (Optional)"),
                      withDirectives(createVNode("select", {
                        "onUpdate:modelValue": ($event) => $setup.form.section_id = $event,
                        id: "section_id",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      }, [
                        createVNode("option", { value: "" }, "Select a section (optional)"),
                        (openBlock(true), createBlock(Fragment, null, renderList($setup.currentCourseSections, (section) => {
                          return openBlock(), createBlock("option", {
                            key: section.id,
                            value: section.id
                          }, toDisplayString(section.title), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, $setup.form.section_id]
                      ])
                    ])) : createCommentVNode("", true)
                  ])) : createCommentVNode("", true),
                  $setup.currentStep === 4 ? (openBlock(), createBlock("div", { key: 3 }, [
                    createVNode("h3", { class: "text-lg font-semibold mb-4" }, "Review"),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("p", null, [
                        createVNode("strong", null, "Title:"),
                        createTextVNode(" " + toDisplayString($setup.form.title), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Description:"),
                        createTextVNode(" " + toDisplayString($setup.form.description), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Time Limit:"),
                        createTextVNode(" " + toDisplayString($setup.form.time_limit) + " minutes", 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Passing Score:"),
                        createTextVNode(" " + toDisplayString($setup.form.passing_score) + "%", 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Active:"),
                        createTextVNode(" " + toDisplayString($setup.form.is_active ? "Yes" : "No"), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Course:"),
                        createTextVNode(" " + toDisplayString($setup.getCourseTitle($setup.form.course_id)), 1)
                      ]),
                      createVNode("p", null, [
                        createVNode("strong", null, "Section:"),
                        createTextVNode(" " + toDisplayString($setup.getSectionTitle($setup.form.section_id)), 1)
                      ])
                    ])
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "flex justify-between mt-6" }, [
                    $setup.currentStep > 1 ? (openBlock(), createBlock("button", {
                      key: 0,
                      onClick: $setup.previousStep,
                      class: "bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                    }, " Previous ", 8, ["onClick"])) : createCommentVNode("", true),
                    $setup.currentStep < $setup.steps.length ? (openBlock(), createBlock("button", {
                      key: 1,
                      onClick: $setup.nextStep,
                      class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                    }, " Next ", 8, ["onClick"])) : createCommentVNode("", true),
                    $setup.currentStep === $setup.steps.length ? (openBlock(), createBlock("button", {
                      key: 2,
                      onClick: $setup.submit,
                      class: "bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
                    }, " Create Quiz ", 8, ["onClick"])) : createCommentVNode("", true)
                  ])
                ])
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Quizzes/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
