import { mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Lecture",
  __ssrInlineRender: true,
  props: {
    lecture: {
      type: Object,
      required: true,
      validator: (lecture) => {
        return lecture.id && lecture.title;
      }
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lecture-card" }, _attrs))}><div class="lecture bg-gray-50 dark:bg-slate-600 p-4 rounded-lg"><div class="flex justify-between items-center"><h4 class="text-lg font-semibold text-gray-900 dark:text-white">${ssrInterpolate(__props.lecture.title)}</h4><span class="text-sm text-gray-500 dark:text-gray-300">${ssrInterpolate(__props.lecture.duration)} minutes</span></div><p class="text-gray-600 dark:text-gray-300 mt-2">${ssrInterpolate(__props.lecture.description)}</p>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("courses.watch", { courseId: __props.lecture.course_id, courseSlug: __props.lecture.course_slug, lectureID: __props.lecture.id }),
        class: "mt-3 inline-block bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition-colors duration-200"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Watch Video `);
          } else {
            return [
              createTextVNode(" Watch Video ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Lecture.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
