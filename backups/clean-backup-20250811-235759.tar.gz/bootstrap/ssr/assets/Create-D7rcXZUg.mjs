import { resolveComponent, withCtx, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, createBlock, openBlock, Fragment, renderList, vModelCheckbox, toDisplayString, useSSRContext } from "vue";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-B5MGtmE1.mjs";
import { ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "@heroicons/vue/24/outline";
import "./SwitchLangNavbar-DZvQeubw.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  components: {
    AuthenticatedLayout: _sfc_main$1
  },
  props: {
    quiz: Object
  },
  setup(props) {
    const form = useForm({
      quiz_id: props.quiz.id,
      question_title_en: "",
      question_title_ar: "",
      question_type_id: 1,
      correct_answers_required: 1,
      answers: [
        { answer_en: "", answer_ar: "", is_correct: false },
        { answer_en: "", answer_ar: "", is_correct: false }
      ]
    });
    const addAnswer = () => {
      form.answers.push({ answer_en: "", answer_ar: "", is_correct: false });
    };
    const removeAnswer = (index) => {
      form.answers.splice(index, 1);
    };
    const submitForm = () => {
      form.post(route("quizzes.questions.store", props.quiz.id), {
        preserveState: true,
        preserveScroll: true
      });
    };
    return {
      form,
      addAnswer,
      removeAnswer,
      submitForm
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AuthenticatedLayout = resolveComponent("AuthenticatedLayout");
  _push(ssrRenderComponent(_component_AuthenticatedLayout, _attrs, {
    header: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}> Add New Question to ${ssrInterpolate($props.quiz.title)}</h2>`);
      } else {
        return [
          createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, " Add New Question to " + toDisplayString($props.quiz.title), 1)
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 bg-white border-b border-gray-200"${_scopeId}><form${_scopeId}><div class="mb-4"${_scopeId}><label for="question_title_en" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Question Title (English):</label><input id="question_title_en"${ssrRenderAttr("value", $setup.form.question_title_en)} type="text" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required${_scopeId}></div><div class="mb-4"${_scopeId}><label for="question_title_ar" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Question Title (Arabic):</label><input id="question_title_ar"${ssrRenderAttr("value", $setup.form.question_title_ar)} type="text" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required dir="rtl"${_scopeId}></div><div class="mb-4"${_scopeId}><label for="question_type" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Question Type:</label><select id="question_type" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required${_scopeId}><option value="1"${ssrIncludeBooleanAttr(Array.isArray($setup.form.question_type_id) ? ssrLooseContain($setup.form.question_type_id, "1") : ssrLooseEqual($setup.form.question_type_id, "1")) ? " selected" : ""}${_scopeId}>Single Choice</option><option value="2"${ssrIncludeBooleanAttr(Array.isArray($setup.form.question_type_id) ? ssrLooseContain($setup.form.question_type_id, "2") : ssrLooseEqual($setup.form.question_type_id, "2")) ? " selected" : ""}${_scopeId}>Multiple Choice</option><option value="3"${ssrIncludeBooleanAttr(Array.isArray($setup.form.question_type_id) ? ssrLooseContain($setup.form.question_type_id, "3") : ssrLooseEqual($setup.form.question_type_id, "3")) ? " selected" : ""}${_scopeId}>True/False</option></select></div><div class="mb-4"${_scopeId}><label for="correct_answers_required" class="block text-gray-700 text-sm font-bold mb-2"${_scopeId}>Correct Answers Required:</label><input id="correct_answers_required"${ssrRenderAttr("value", $setup.form.correct_answers_required)} type="number" min="1" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required${_scopeId}></div><div class="mb-4"${_scopeId}><h3 class="text-gray-700 text-sm font-bold mb-2"${_scopeId}>Answers:</h3><!--[-->`);
        ssrRenderList($setup.form.answers, (answer, index) => {
          _push2(`<div class="mb-2"${_scopeId}><div class="flex items-center"${_scopeId}><input${ssrRenderAttr("value", answer.answer_en)} type="text" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-2"${ssrRenderAttr("placeholder", `Answer ${index + 1} (English)`)} required${_scopeId}><input${ssrRenderAttr("value", answer.answer_ar)} type="text" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-2"${ssrRenderAttr("placeholder", `Answer ${index + 1} (Arabic)`)} required dir="rtl"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(answer.is_correct) ? ssrLooseContain(answer.is_correct, null) : answer.is_correct) ? " checked" : ""} type="checkbox" class="mr-2"${_scopeId}><label class="text-sm"${_scopeId}>Correct</label><button type="button" class="ml-2 text-red-500"${_scopeId}>Remove</button></div></div>`);
        });
        _push2(`<!--]--><button type="button" class="mt-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"${_scopeId}> Add Answer </button></div><div class="flex items-center justify-between"${_scopeId}><button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"${_scopeId}> Add Question </button></div></form></div></div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-12" }, [
            createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 bg-white border-b border-gray-200" }, [
                  createVNode("form", {
                    onSubmit: withModifiers($setup.submitForm, ["prevent"])
                  }, [
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "question_title_en",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Question Title (English):"),
                      withDirectives(createVNode("input", {
                        id: "question_title_en",
                        "onUpdate:modelValue": ($event) => $setup.form.question_title_en = $event,
                        type: "text",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.question_title_en]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "question_title_ar",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Question Title (Arabic):"),
                      withDirectives(createVNode("input", {
                        id: "question_title_ar",
                        "onUpdate:modelValue": ($event) => $setup.form.question_title_ar = $event,
                        type: "text",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        required: "",
                        dir: "rtl"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.question_title_ar]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "question_type",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Question Type:"),
                      withDirectives(createVNode("select", {
                        id: "question_type",
                        "onUpdate:modelValue": ($event) => $setup.form.question_type_id = $event,
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        required: ""
                      }, [
                        createVNode("option", { value: "1" }, "Single Choice"),
                        createVNode("option", { value: "2" }, "Multiple Choice"),
                        createVNode("option", { value: "3" }, "True/False")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, $setup.form.question_type_id]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("label", {
                        for: "correct_answers_required",
                        class: "block text-gray-700 text-sm font-bold mb-2"
                      }, "Correct Answers Required:"),
                      withDirectives(createVNode("input", {
                        id: "correct_answers_required",
                        "onUpdate:modelValue": ($event) => $setup.form.correct_answers_required = $event,
                        type: "number",
                        min: "1",
                        class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        required: ""
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $setup.form.correct_answers_required]
                      ])
                    ]),
                    createVNode("div", { class: "mb-4" }, [
                      createVNode("h3", { class: "text-gray-700 text-sm font-bold mb-2" }, "Answers:"),
                      (openBlock(true), createBlock(Fragment, null, renderList($setup.form.answers, (answer, index) => {
                        return openBlock(), createBlock("div", {
                          key: index,
                          class: "mb-2"
                        }, [
                          createVNode("div", { class: "flex items-center" }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => answer.answer_en = $event,
                              type: "text",
                              class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-2",
                              placeholder: `Answer ${index + 1} (English)`,
                              required: ""
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, answer.answer_en]
                            ]),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => answer.answer_ar = $event,
                              type: "text",
                              class: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-2",
                              placeholder: `Answer ${index + 1} (Arabic)`,
                              required: "",
                              dir: "rtl"
                            }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                              [vModelText, answer.answer_ar]
                            ]),
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => answer.is_correct = $event,
                              type: "checkbox",
                              class: "mr-2"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelCheckbox, answer.is_correct]
                            ]),
                            createVNode("label", { class: "text-sm" }, "Correct"),
                            createVNode("button", {
                              onClick: ($event) => $setup.removeAnswer(index),
                              type: "button",
                              class: "ml-2 text-red-500"
                            }, "Remove", 8, ["onClick"])
                          ])
                        ]);
                      }), 128)),
                      createVNode("button", {
                        onClick: $setup.addAnswer,
                        type: "button",
                        class: "mt-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                      }, " Add Answer ", 8, ["onClick"])
                    ]),
                    createVNode("div", { class: "flex items-center justify-between" }, [
                      createVNode("button", {
                        type: "submit",
                        class: "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                      }, " Add Question ")
                    ])
                  ], 40, ["onSubmit"])
                ])
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Questions/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Create = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Create as default
};
