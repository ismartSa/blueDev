import { unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    section: Object
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      title: props.section.title,
      order: props.section.order
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h1>Edit Section</h1><form><div><label for="title">Title</label><input${ssrRenderAttr("value", unref(form).title)} id="title" type="text"></div><div><label for="order">Order</label><input${ssrRenderAttr("value", unref(form).order)} id="order" type="number"></div><button type="submit">Save</button></form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Sections/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
