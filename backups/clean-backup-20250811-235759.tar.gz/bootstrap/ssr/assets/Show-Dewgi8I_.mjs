import _sfc_main$3 from "./Footer-BdEBRyFq.mjs";
import { _ as _sfc_main$1, A as ApplicationLogo } from "./SwitchLangNavbar-DZvQeubw.mjs";
import { _ as _sfc_main$2 } from "./SwitchDarkMode-qMtWjm8v.mjs";
import "@inertiajs/vue3";
import { resolveComponent, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main = {
  components: {
    Footer: _sfc_main$3,
    ApplicationLogo,
    SwitchDarkMode: _sfc_main$2,
    SwitchLangNavbar: _sfc_main$1
  },
  props: {
    course: {
      type: Object,
      required: true
    },
    statistics: {
      type: Object,
      required: true
    },
    enrollmentStatus: {
      type: Object,
      required: true
    },
    progress: {
      type: Object,
      default: null
    },
    meta: {
      type: Object,
      required: true
    }
  },
  methods: {
    formatDuration(minutes) {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      return hours > 0 ? `${hours} hour${hours > 1 ? "s" : ""} ${remainingMinutes} minute${remainingMinutes !== 1 ? "s" : ""}` : `${remainingMinutes} minute${remainingMinutes !== 1 ? "s" : ""}`;
    },
    enrollInCourse() {
      this.$inertia.post(route("course.enroll", this.course.id));
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Footer = resolveComponent("Footer");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "course-details" }, _attrs))}><div class="course-header bg-gradient-to-r from-indigo-600 to-indigo-800 text-white p-8 rounded-lg shadow-lg"><div class="container mx-auto px-4"><div class="flex flex-col md:flex-row items-center justify-between gap-8"><div class="md:w-1/2"><h1 class="course-title text-4xl font-bold mb-4">${ssrInterpolate($props.course.title)}</h1><p class="course-description text-lg opacity-90 mb-6">${ssrInterpolate($props.course.description)}</p><div class="flex items-center space-x-4 mb-6"><div class="flex items-center"><i class="far fa-clock mr-2"></i><span>${ssrInterpolate($props.statistics.durationFormatted)}</span></div><div class="flex items-center"><i class="far fa-user mr-2"></i><span>${ssrInterpolate($props.statistics.enrollmentsCount)} طالب</span></div><div class="flex items-center"><i class="far fa-play-circle mr-2"></i><span>${ssrInterpolate($props.statistics.lecturesCount)} درس</span></div></div>`);
  if (!$props.enrollmentStatus.enrolled) {
    _push(`<div class="enrollment-section"><button class="bg-white text-indigo-600 px-6 py-3 rounded-lg font-bold hover:bg-indigo-50 transition duration-300 shadow-lg"> سجل الآن </button></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="md:w-1/2"><div class="relative"><img${ssrRenderAttr("src", $props.course.image)}${ssrRenderAttr("alt", $props.course.title)} class="w-full h-auto rounded-xl shadow-2xl"><div class="absolute -bottom-4 -left-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-lg font-bold shadow-lg">${ssrInterpolate($props.course.category || "كورس احترافي")}</div></div></div></div></div></div><div class="container mx-auto px-4 py-12"><div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center"><div class="p-6 rounded-lg border border-gray-200 bg-white shadow-md"><div class="text-4xl font-bold text-indigo-600 mb-2">${ssrInterpolate($props.statistics.lecturesCount)}+</div><div class="text-gray-600">درس تعليمي</div></div><div class="p-6 rounded-lg border border-gray-200 bg-white shadow-md"><div class="text-4xl font-bold text-indigo-600 mb-2">${ssrInterpolate($props.statistics.enrollmentsCount)}+</div><div class="text-gray-600">طالب مسجل</div></div><div class="p-6 rounded-lg border border-gray-200 bg-white shadow-md"><div class="text-4xl font-bold text-indigo-600 mb-2">${ssrInterpolate($props.statistics.completionRate)}%</div><div class="text-gray-600">نسبة الإكمال</div></div><div class="p-6 rounded-lg border border-gray-200 bg-white shadow-md"><div class="text-4xl font-bold text-indigo-600 mb-2">${ssrInterpolate($props.statistics.durationFormatted)}</div><div class="text-gray-600">مدة الدورة</div></div></div></div>`);
  if (!$props.enrollmentStatus.enrolled) {
    _push(`<div class="enrollment-section"><button class="enroll-button"> Enroll in Course </button></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.enrollmentStatus.enrolled && $props.progress) {
    _push(`<div class="progress-section"><h3>Your Progress</h3><div class="progress-stats"><p>Completed Lectures: ${ssrInterpolate($props.progress.completedLectures)}</p>`);
    if ($props.progress.certificateEligible) {
      _push(`<p class="certificate-eligible"> Eligible for Certificate! 🎉 </p>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="course-content"><h2>Course Content</h2><!--[-->`);
  ssrRenderList($props.course.sections, (section) => {
    _push(`<div class="course-section"><h3>${ssrInterpolate(section.title)}</h3><p>${ssrInterpolate(section.description)}</p><ul class="lectures-list"><!--[-->`);
    ssrRenderList(section.lectures, (lecture) => {
      _push(`<li class="lecture-item"><span class="lecture-title">${ssrInterpolate(lecture.title)}</span><span class="lecture-duration">${ssrInterpolate($options.formatDuration(lecture.duration))}</span></li>`);
    });
    _push(`<!--]--></ul></div>`);
  });
  _push(`<!--]--></div>`);
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Course/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Show = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Show as default
};
